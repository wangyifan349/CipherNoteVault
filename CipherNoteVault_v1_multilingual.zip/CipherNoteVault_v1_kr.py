"""CipherNote Vault는 로컬에서 실행되는 암호화 비밀번호 관리자 겸 보안 메모장입니다. Argon2id로 키를 파생하고 ChaCha20-Poly1305로 데이터베이스 내용을 인증 암호화하며, 데이터는 기본적으로 사용자가 선택한 로컬 데이터베이스 파일에만 저장됩니다."""
# SPDX-License-Identifier: GPL-3.0-only
# CipherNote Vault
# Copyright (C) 2026 Wang Yifan
#
# 이 프로그램은 자유 소프트웨어입니다. 다음 라이선스 조건에 따라 재배포하거나 수정할 수 있습니다:
# 자유 소프트웨어 재단이 공표한 GNU 일반 공중 사용 허가서
# 버전 3을 적용합니다.
import base64
import copy
import ctypes
import hashlib
import json
import os
import platform
import re
import secrets
import string
import sys
import uuid
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Pattern, Tuple
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from bip_utils import (
    Bip32Secp256k1,
    Bip39MnemonicGenerator,
    Bip39SeedGenerator,
    Bip39WordsNum,
    EthAddrEncoder,
    P2WPKHAddrEncoder,
    WifEncoder,
)
try:
    from charset_normalizer import from_bytes
except ImportError:  # 텍스트 가져오기에서 명확한 안내를 표시하며, 다른 기능은 계속 사용할 수 있습니다.
    from_bytes = None
from PyQt6.QtCore import QEvent, QPoint, QThread, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QKeySequence, QShortcut, QTextCursor, QTextOption
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QRadioButton,
    QPushButton,
    QPlainTextEdit,
    QProgressDialog,
    QSplitter,
    QSlider,
    QSizePolicy,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)
#------ 프로그램 설정 ------
APP_NAME = "CipherNote Vault"
APP_VERSION = "1.0.0"
VAULT_FORMAT = "CipherNote Vault Database"
VAULT_VERSION = 1
DEFAULT_VAULT_DIR = Path.home() / ".ciphernote_vault"
DEFAULT_VAULT = DEFAULT_VAULT_DIR / "vault.cnvault"
ARGON2ID_PARAMS = {
    "name": "Argon2id",
    "length": 32,
    "iterations": 3,
    "lanes": 4,
    "memory_cost": 64 * 1024,
}
# 신뢰할 수 없는 데이터베이스 메타데이터가 무제한 작업을 요구하지 못하게 합니다.
MAX_VAULT_FILE_SIZE = 256 * 1024 * 1024
MAX_ARGON2_ITERATIONS = 8
MAX_ARGON2_LANES = 16
MAX_ARGON2_MEMORY_KIB = 512 * 1024
MIN_SALT_LENGTH = 16
MAX_SALT_LENGTH = 64
CHACHA20_POLY1305_NONCE_LENGTH = 12
POLY1305_TAG_LENGTH = 16
DEFAULT_GENERATED_PASSWORD_LENGTH = 32
MAX_GENERATED_PASSWORD_LENGTH = 4096
PASSWORD_SYMBOLS = "!@#$%^&*()-_=+[]{}:,.?"
CRYPTO_ADDRESS_COUNT = 5
CRYPTO_BIP39_PASSPHRASE = ""
AUTO_LOCK_TIMEOUT_MS = 5 * 60 * 1000
MAX_SEARCH_TEXT_LENGTH = 200_000
MAX_REGEX_PATTERN_LENGTH = 256
MAX_TEXT_IMPORT_SIZE = 16 * 1024 * 1024
MAX_ITEM_COUNT = 100_000
MAX_COMMENT_COUNT = 10_000
MAX_TEXT_FIELD_LENGTH = 32 * 1024 * 1024
DONATION_BTC = "bc1qxqfhumpqtnxrznkx9r4xsp8m6zsedtgusjns7p"
DONATION_ETH = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
DONATION_BNB = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
WINDOWS_DISPLAY_AFFINITY_NONE = 0x00000000
WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE = 0x00000011
WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY = 0x00000001
#------ 공용 유틸리티 ------
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
def readable_time(value: str) -> str:
    if not value:
        return ""
    return value.replace("T", " ").replace("+00:00", " UTC")

def table_text_preview(value: Any, maximum_length: int = 120) -> str:
    # 표에는 짧은 미리보기만 두고 검색과 상세 화면은 전체 내용을 사용합니다.
    preview = " ".join(str(value or "").split())
    if len(preview) <= maximum_length:
        return preview
    return preview[: maximum_length - 1].rstrip() + "…"

def remove_extra_blank_lines(text: str) -> str:
    """줄바꿈을 통일하고 줄 끝 공백을 제거한 뒤 연속된 빈 줄을 한 줄로 줄입니다."""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned_lines: List[str] = []
    previous_was_blank = True
    for raw_line in normalized.split("\n"):
        line = raw_line.rstrip()
        is_blank = not line.strip()
        if is_blank:
            if cleaned_lines and not previous_was_blank:
                cleaned_lines.append("")
        else:
            cleaned_lines.append(line)
        previous_was_blank = is_blank
    while cleaned_lines and cleaned_lines[-1] == "":
        cleaned_lines.pop()
    return "\n".join(cleaned_lines)

def python_index_to_qt_position(text: str, index: int) -> int:
    """Python 유니코드 인덱스를 QTextCursor가 사용하는 UTF-16 위치로 변환합니다."""
    safe_index = min(max(index, 0), len(text))
    return len(text[:safe_index].encode("utf-16-le")) // 2

def qt_position_to_python_index(text: str, position: int) -> int:
    safe_position = max(position, 0) * 2
    prefix = text.encode("utf-16-le")[:safe_position]
    return len(prefix.decode("utf-16-le", errors="ignore"))

def text_readability_score(text: str) -> float:
    common_cjk = set(
        "\u7684\u4e00\u662f\u4e0d\u4e86\u4eba\u6211\u5728\u6709\u4ed6\u8fd9\u70ba\u4e3a\u4e4b\u5927\u6765\u4f86\u4ee5\u4e2a\u500b\u4e2d\u4e0a\u5011\u4eec\u5230\u8aaa\u8bf4\u570b\u56fd\u548c\u5730\u4e5f\u5b50\u6642\u65f6\u9053\u51fa"
        "\u800c\u8981\u65bc\u4e8e\u5c31\u4e0b\u5f97\u53ef\u4f60\u5e74\u751f\u81ea\u6703\u4f1a\u90a3\u5f8c\u540e\u80fd\u5c0d\u5bf9\u8457\u7740\u4e8b\u5176\u88e1\u91cc\u6240\u53bb\u884c\u904e\u8fc7\u5bb6\u5341\u7528\u767c\u53d1"
        "\u5929\u5982\u7136\u4f5c\u65b9\u6210\u8005\u591a\u65e5\u90fd\u4e09\u5c0f\u4e8c\u7121\u65e0\u540c\u7d93\u7ecf\u6cd5\u7576\u5f53\u8d77\u8207\u4e0e\u597d\u770b\u5b78\u5b66\u9032\u8fdb\u7a2e\u79cd\u5c07\u5c06\u9084\u8fd8"
        "\u5206\u6b64\u5fc3\u524d\u9762\u53c8\u5b9a\u898b\u89c1\u53ea\u4e3b\u6c92\u6ca1\u516c\u5f9e\u4ece\u660e\u554f\u95ee\u529b\u9593\u95f4\u610f\u5916\u6b63\u628a\u60c5\u6700\u91cd\u6587\u672c\u6e2c\u6d4b\u8bd5\u8a66"
        "\u4e2d\u6587\u7b46\u7b14\u8a18\u8bb0\u5bc6\u78bc\u5bc6\u7801\u5e33\u8d26\u53f7\u865f\u5c0e\u5bfc\u5165\u7de8\u7f16\u7801\u78bc\u5b89\u5168\u4fdd\u5b58\u641c\u7d22\u641c\u5c0b\u65e5\u672c\u8a9e"
    )
    score = 0.0
    for character in text:
        codepoint = ord(character)
        if character == "\ufffd" or (codepoint < 32 and character not in "\n\r\t"):
            score -= 12.0
        elif character in common_cjk:
            score += 2.0
        elif 0x3040 <= codepoint <= 0x30FF:
            score += 2.0
        elif 0x4E00 <= codepoint <= 0x9FFF:
            score += 0.15
        elif 0xFF61 <= codepoint <= 0xFF9F:
            score -= 0.8
        elif character.isprintable():
            score += 0.05
    return score

def decode_imported_text(data: bytes) -> Tuple[str, str, float]:
    """charset_normalizer.from_bytes로 외부 텍스트의 인코딩을 자동 감지합니다."""
    if not data:
        return "", "utf-8", 100.0
    if from_bytes is None:
        raise RuntimeError("charset-normalizer가 없습니다. 먼저 다음을 실행하세요: pip install charset-normalizer")
    matches = from_bytes(data)
    best_match = matches.best()
    if best_match is None:
        raise ValueError("텍스트 파일의 인코딩을 감지할 수 없습니다.")
    encoding = best_match.encoding or "unknown"
    coherence = float(getattr(best_match, "percent_coherence", 0.0) or 0.0)
    best_text = str(best_match)
    if coherence >= 10.0:
        return best_text, encoding, coherence

    # 매우 짧은 중국어, 일본어, 한국어 텍스트에는 여러 유효한 디코딩이 있을 수 있습니다.
    # from_bytes를 우선 사용하고, 신뢰도가 낮으면 몇 가지 일반 후보를 비교하여 짧은 GB18030 중국어 텍스트를 Big5로 오인하지 않게 합니다.
    candidates = {encoding: best_text}
    for candidate_encoding in ("utf-8-sig", "gb18030", "big5", "shift_jis"):
        with suppress(UnicodeDecodeError, LookupError):
            candidates[candidate_encoding] = data.decode(candidate_encoding)
    selected_encoding, selected_text = max(
        candidates.items(),
        key=lambda pair: (
            text_readability_score(pair[1]),
            pair[0] == encoding,
        ),
    )
    return selected_text, selected_encoding, coherence

def read_imported_text_file(path: Path) -> Tuple[str, str, float]:
    if path.stat().st_size > MAX_TEXT_IMPORT_SIZE:
        raise ValueError(
            f"텍스트 파일은 다음 크기를 초과할 수 없습니다: {MAX_TEXT_IMPORT_SIZE // (1024 * 1024)} MiB."
        )
    return decode_imported_text(path.read_bytes())

def longest_common_subsequence_score(first_text: str, second_text: Any) -> int:
    """비트 병렬 알고리즘으로 대소문자를 구분하지 않는 최장 공통 부분 수열 길이를 계산합니다."""
    first = str(first_text or "").casefold()
    second = str(second_text or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    if not first or not second:
        return 0
    character_masks: Dict[str, int] = {}
    for index, character in enumerate(first):
        character_masks[character] = (
            character_masks.get(character, 0) | (1 << index)
        )
    lcs_row = 0
    for character in second:
        matches = character_masks.get(character, 0)
        combined = matches | lcs_row
        lcs_row = combined & ~(combined - ((lcs_row << 1) | 1))
    return lcs_row.bit_count()

def longest_common_subsequence_match(keyword: str, text_value: Any) -> bool:
    """keyword의 모든 문자가 LCS에 포함되면 일치한 것으로 봅니다."""
    folded_keyword = str(keyword or "").casefold()
    if not folded_keyword:
        return True
    return (
        longest_common_subsequence_score(folded_keyword, text_value)
        == len(folded_keyword)
    )

def wildcard_search_match(pattern: str, text_value: Any) -> bool:
    """별표는 길이에 제한이 없는 내용을 나타내며, 각 텍스트 조각은 입력 순서대로 나타나야 합니다."""
    folded_pattern = str(pattern or "").casefold()
    text = str(text_value or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    fragments = [fragment for fragment in folded_pattern.split("*") if fragment]
    if not fragments:
        return True
    search_position = 0
    for fragment in fragments:
        fragment_position = text.find(fragment, search_position)
        if fragment_position < 0:
            return False
        search_position = fragment_position + len(fragment)
    return True

def lcs_or_wildcard_item_match(keyword: str, values: List[Any]) -> bool:
    searchable_text = "\n".join(str(value or "") for value in values)
    if "*" in keyword:
        return wildcard_search_match(keyword, searchable_text)
    return longest_common_subsequence_match(keyword, searchable_text)

def compile_search_regex(pattern_text: str) -> Pattern[str]:
    if len(pattern_text) > MAX_REGEX_PATTERN_LENGTH:
        raise ValueError(f"정규식은 다음 길이를 초과할 수 없습니다: {MAX_REGEX_PATTERN_LENGTH}자입니다.")
    try:
        return re.compile(pattern_text, re.IGNORECASE | re.UNICODE)
    except re.error as error:
        raise ValueError(f"잘못된 정규식: {error}") from error

def protect_widget_from_capture(widget: QWidget) -> None:
    if platform.system() != "Windows":
        return
    with suppress(Exception):
        window_handle = int(widget.winId())
        result = ctypes.windll.user32.SetWindowDisplayAffinity(
            window_handle,
            WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE,
        )
        if result == 0:
            ctypes.windll.user32.SetWindowDisplayAffinity(
                window_handle,
                WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY,
            )

def generate_secure_password(length: int, include_lowercase: bool = True, include_uppercase: bool = True, include_digits: bool = True, include_symbols: bool = True) -> str:
    if length < 1:
        raise ValueError("비밀번호 길이는 0보다 커야 합니다.")
    character_groups = []
    if include_lowercase:
        character_groups.append(string.ascii_lowercase)
    if include_uppercase:
        character_groups.append(string.ascii_uppercase)
    if include_digits:
        character_groups.append(string.digits)
    if include_symbols:
        character_groups.append(PASSWORD_SYMBOLS)
    if not character_groups:
        raise ValueError("문자 유형을 하나 이상 선택하세요.")
    character_pool = "".join(character_groups)
    if length < len(character_groups):
        raise ValueError(f"비밀번호 길이는 선택한 문자 유형 수보다 짧을 수 없습니다({len(character_groups)}).")
    password_characters = [secrets.choice(character_group) for character_group in character_groups]
    password_characters.extend(secrets.choice(character_pool) for _ in range(length - len(password_characters)))
    secrets.SystemRandom().shuffle(password_characters)
    return "".join(password_characters)

def generate_crypto_wallet_bundle(
    address_count: int = CRYPTO_ADDRESS_COUNT,
) -> Dict[str, Any]:
    if address_count < 1:
        raise ValueError("주소 수는 0보다 커야 합니다.")

    mnemonic_object = Bip39MnemonicGenerator().FromWordsNumber(
        Bip39WordsNum.WORDS_NUM_24
    )
    mnemonic = str(mnemonic_object)
    seed = Bip39SeedGenerator(mnemonic_object).Generate(CRYPTO_BIP39_PASSPHRASE)
    root = Bip32Secp256k1.FromSeed(seed)
    bitcoin_wallets: List[Dict[str, Any]] = []
    ethereum_wallets: List[Dict[str, Any]] = []

    # BTC는 주소 인덱스가 하드닝된 BIP84 방식 경로를 사용합니다.
    for index in range(address_count):
        path = f"m/84'/0'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        private_key_bytes = private_key.Raw().ToBytes()
        bitcoin_wallets.append({
            "index": index,
            "path": path,
            "address": P2WPKHAddrEncoder.EncodeKey(
                public_key.RawCompressed().ToBytes(),
                hrp="bc",
            ),
            "private_key_decimal": int.from_bytes(private_key_bytes, "big"),
            "private_key_wif": WifEncoder.Encode(private_key_bytes),
            "public_key": public_key.RawCompressed().ToHex(),
        })

    # ETH는 주소 인덱스가 하드닝된 BIP44 방식 경로를 사용합니다.
    for index in range(address_count):
        path = f"m/44'/60'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        ethereum_wallets.append({
            "index": index,
            "path": path,
            "address": EthAddrEncoder.EncodeKey(
                public_key.RawUncompressed().ToBytes()
            ),
            "private_key_decimal": int.from_bytes(
                private_key.Raw().ToBytes(),
                "big",
            ),
            "public_key": "0x" + public_key.RawUncompressed().ToHex(),
        })

    return {
        "generated_at": now_iso(),
        "mnemonic": mnemonic,
        "seed_hex": seed.hex(),
        "bitcoin": bitcoin_wallets,
        "ethereum": ethereum_wallets,
    }

def format_crypto_wallet_bundle(wallet_bundle: Dict[str, Any]) -> str:
    generated_at = readable_time(str(wallet_bundle.get("generated_at", "")))
    lines = [
        "=" * 80,
        "BIP39 24단어 니모닉",
        "=" * 80,
        f"생성 시간        : {generated_at}",
        f"니모닉 MNEMONIC  : {wallet_bundle.get('mnemonic', '')}",
        f"시드 HEX         : {wallet_bundle.get('seed_hex', '')}",
        "BIP39 추가 암호  : 설정 안 함",
        "복구 안내       : 아래와 완전히 동일한 하드닝 파생 경로를 사용해야 합니다",
        "",
        "=" * 80,
        "BITCOIN - BIP84 방식, 주소 인덱스 하드닝",
        "=" * 80,
    ]
    for wallet in wallet_bundle.get("bitcoin", []):
        lines.extend([
            "",
            f"BTC #{wallet.get('index', '')}",
            f"파생 경로       : {wallet.get('path', '')}",
            f"주소            : {wallet.get('address', '')}",
            f"개인 키(10진수) : {wallet.get('private_key_decimal', '')}",
            f"개인 키(WIF)    : {wallet.get('private_key_wif', '')}",
            f"공개 키         : {wallet.get('public_key', '')}",
        ])
    lines.extend([
        "",
        "=" * 80,
        "ETHEREUM - BIP44 방식, 주소 인덱스 하드닝",
        "=" * 80,
    ])
    for wallet in wallet_bundle.get("ethereum", []):
        lines.extend([
            "",
            f"ETH #{wallet.get('index', '')}",
            f"파생 경로       : {wallet.get('path', '')}",
            f"주소            : {wallet.get('address', '')}",
            f"개인 키(10진수) : {wallet.get('private_key_decimal', '')}",
            f"공개 키         : {wallet.get('public_key', '')}",
        ])
    return "\n".join(lines)

def build_crypto_password_item(wallet_bundle: Dict[str, Any]) -> Dict[str, Any]:
    generated_at = str(wallet_bundle.get("generated_at") or now_iso())
    bitcoin_wallets = wallet_bundle.get("bitcoin", [])
    ethereum_wallets = wallet_bundle.get("ethereum", [])
    first_bitcoin_address = (
        str(bitcoin_wallets[0].get("address", "")) if bitcoin_wallets else ""
    )
    first_ethereum_address = (
        str(ethereum_wallets[0].get("address", "")) if ethereum_wallets else ""
    )
    return {
        "id": str(uuid.uuid4()),
        "type": "password",
        "title": f"암호화폐 지갑 {readable_time(generated_at)}",
        "username": (
            f"BTC {first_bitcoin_address} | ETH {first_ethereum_address}"
        ),
        "password": str(wallet_bundle.get("mnemonic", "")),
        "notes": format_crypto_wallet_bundle(wallet_bundle),
        "created_at": generated_at,
        "updated_at": generated_at,
    }
#------ 암호화 및 데이터베이스 파일 ------
def encode_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")
def decode_base64(data: str) -> bytes:
    if not isinstance(data, str):
        raise ValueError("Base64 필드는 문자열이어야 합니다.")
    try:
        return base64.b64decode(data.encode("ascii"), validate=True)
    except ValueError as error:
        raise ValueError("Base64 데이터가 잘못되었습니다.") from error
def secure_wipe(buffer: Optional[bytearray]) -> None:
    # 가능한 범위에서만 지웁니다. Python은 인터프리터 내부의 모든 사본 삭제를 보장할 수 없습니다.
    if buffer is None:
        return
    for index in range(len(buffer)):
        buffer[index] = 0
def validate_kdf(kdf_params: Any) -> Dict[str, Any]:
    if not isinstance(kdf_params, dict) or kdf_params.get("name") != "Argon2id":
        raise VaultError("데이터베이스 KDF 매개변수가 잘못되었습니다.")
    required = ("length", "iterations", "lanes", "memory_cost")
    for parameter_name in required:
        parameter_value = kdf_params.get(parameter_name)
        if isinstance(parameter_value, bool) or not isinstance(parameter_value, int):
            raise VaultError(f"데이터베이스 KDF 매개변수 {parameter_name}이(가) 잘못되었습니다.")
    length = kdf_params["length"]
    iterations = kdf_params["iterations"]
    lanes = kdf_params["lanes"]
    memory_cost = kdf_params["memory_cost"]
    if length != 32:
        raise VaultError("데이터베이스 KDF 출력 길이가 잘못되었습니다.")
    if not 1 <= iterations <= MAX_ARGON2_ITERATIONS:
        raise VaultError("데이터베이스 Argon2id iterations가 허용 범위를 벗어났습니다.")
    if not 1 <= lanes <= MAX_ARGON2_LANES:
        raise VaultError("데이터베이스 Argon2id lanes가 허용 범위를 벗어났습니다.")
    if memory_cost < 8 * lanes or memory_cost > MAX_ARGON2_MEMORY_KIB:
        raise VaultError("데이터베이스 Argon2id memory_cost가 허용 범위를 벗어났습니다.")
    return dict(kdf_params)
def build_associated_data(kdf_params: Dict[str, Any], salt_base64: str) -> bytes:
    metadata = {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
    }
    return json.dumps(metadata, ensure_ascii=False, sort_keys=True).encode("utf-8")
def derive_key(master_password: str, salt: bytes, kdf_params: Dict[str, Any]) -> bytes:
    if not master_password:
        raise ValueError("마스터 비밀번호는 비워 둘 수 없습니다.")
    if kdf_params.get("name") != "Argon2id":
        raise ValueError("지원하지 않는 키 파생 알고리즘입니다.")
    return Argon2id(
        salt=salt,
        length=kdf_params["length"],
        iterations=kdf_params["iterations"],
        lanes=kdf_params["lanes"],
        memory_cost=kdf_params["memory_cost"],
        ad=None,
        secret=None,
    ).derive(master_password.encode("utf-8"))
def decode_vault_envelope(vault_envelope: Any):
    if not isinstance(vault_envelope, dict):
        raise VaultError("데이터베이스 파일 형식이 잘못되었습니다.")
    if vault_envelope.get("format") != VAULT_FORMAT:
        raise VaultError("CipherNote Vault 데이터베이스 파일이 아닙니다.")
    if vault_envelope.get("version") != VAULT_VERSION:
        raise VaultError("지원하지 않는 데이터베이스 버전입니다.")
    if vault_envelope.get("cipher") != "ChaCha20-Poly1305":
        raise VaultError("지원하지 않는 암호화 알고리즘입니다.")
    kdf_params = validate_kdf(vault_envelope.get("kdf"))
    try:
        salt_base64 = vault_envelope["salt"]
        salt = decode_base64(salt_base64)
        nonce = decode_base64(vault_envelope["nonce"])
        ciphertext = decode_base64(vault_envelope["ciphertext"])
    except (KeyError, TypeError, ValueError) as error:
        raise VaultError("데이터베이스 파일이 손상되었거나 형식이 올바르지 않습니다.") from error
    if not MIN_SALT_LENGTH <= len(salt) <= MAX_SALT_LENGTH:
        raise VaultError("데이터베이스 salt 길이가 잘못되었습니다.")
    if len(nonce) != CHACHA20_POLY1305_NONCE_LENGTH:
        raise VaultError("데이터베이스 nonce 길이가 잘못되었습니다.")
    if len(ciphertext) < POLY1305_TAG_LENGTH:
        raise VaultError("데이터베이스 암호문 길이가 잘못되었습니다.")
    return kdf_params, salt_base64, salt, nonce, ciphertext
def encrypt_payload(payload: Dict[str, Any], key: bytearray, salt: bytes, kdf_params: Dict[str, Any]) -> Dict[str, Any]:
    plaintext_json = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    plaintext_buffer = bytearray(plaintext_json.encode("utf-8"))
    plaintext_json = ""
    try:
        nonce = os.urandom(CHACHA20_POLY1305_NONCE_LENGTH)
        salt_base64 = encode_base64(salt)
        associated_data = build_associated_data(kdf_params, salt_base64)
        ciphertext = ChaCha20Poly1305(key).encrypt(nonce, plaintext_buffer, associated_data)
    finally:
        secure_wipe(plaintext_buffer)
    return {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
        "nonce": encode_base64(nonce),
        "ciphertext": encode_base64(ciphertext),
    }

def normalize_payload(payload: Any) -> Dict[str, Any]:
    """복호화한 데이터를 검증하고 이전 버전에 없는 평면 주석 필드를 보완합니다."""
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise VaultError("데이터베이스 내용 형식이 잘못되었습니다.")
    raw_items = payload["items"]
    if len(raw_items) > MAX_ITEM_COUNT:
        raise VaultError("데이터베이스 항목 수가 허용 범위를 벗어났습니다.")
    normalized_payload = dict(payload)
    normalized_items: List[Dict[str, Any]] = []
    seen_item_ids = set()
    for raw_item in raw_items:
        if not isinstance(raw_item, dict):
            raise VaultError("데이터베이스 항목 형식이 잘못되었습니다.")
        item_type = raw_item.get("type")
        if item_type not in ("password", "note"):
            raise VaultError("데이터베이스에 지원하지 않는 항목 유형이 있습니다.")
        item = dict(raw_item)
        item_id = item.get("id")
        # 이전 항목이 서로 덮어쓰지 않도록 없거나 중복된 ID를 복구합니다.
        if not isinstance(item_id, str) or not item_id or item_id in seen_item_ids:
            item_id = str(uuid.uuid4())
        item["id"] = item_id
        seen_item_ids.add(item_id)
        for timestamp_field in ("created_at", "updated_at"):
            timestamp_value = item.get(timestamp_field, "")
            item[timestamp_field] = (
                timestamp_value if isinstance(timestamp_value, str) else ""
            )
        text_fields = (
            ("title", "username", "password", "notes")
            if item_type == "password"
            else ("title", "content")
        )
        for field_name in text_fields:
            field_value = item.get(field_name, "")
            if not isinstance(field_value, str):
                raise VaultError(f"데이터베이스 필드 {field_name}의 유형이 잘못되었습니다.")
            if len(field_value) > MAX_TEXT_FIELD_LENGTH:
                raise VaultError(f"데이터베이스 필드 {field_name}이 너무 큽니다.")
            item[field_name] = field_value
        if item_type == "note":
            font_size = item.get("font_size", 20)
            if isinstance(font_size, bool) or not isinstance(font_size, int):
                font_size = 20
            item["font_size"] = min(max(font_size, 12), 36)
            raw_comments = item.get("comments", [])
            if not isinstance(raw_comments, list) or len(raw_comments) > MAX_COMMENT_COUNT:
                raise VaultError("메모 주석 형식이 잘못되었거나 수가 너무 많습니다.")
            normalized_comments = []
            seen_comment_ids = set()
            for raw_comment in raw_comments:
                if not isinstance(raw_comment, dict):
                    raise VaultError("메모 주석 형식이 잘못되었습니다.")
                comment_text = raw_comment.get("text", "")
                quote_text = raw_comment.get("quote", "")
                if not isinstance(comment_text, str) or not isinstance(quote_text, str):
                    raise VaultError("메모 주석 텍스트 형식이 잘못되었습니다.")
                if len(comment_text) > MAX_TEXT_FIELD_LENGTH or len(quote_text) > MAX_TEXT_FIELD_LENGTH:
                    raise VaultError("메모 주석 내용이 너무 큽니다.")
                comment_id = str(raw_comment.get("id") or uuid.uuid4())
                if comment_id in seen_comment_ids:
                    comment_id = str(uuid.uuid4())
                seen_comment_ids.add(comment_id)
                normalized_comments.append({
                    "id": comment_id,
                    "quote": quote_text,
                    "text": comment_text,
                    "created_at": str(raw_comment.get("created_at") or now_iso()),
                    "updated_at": str(raw_comment.get("updated_at") or now_iso()),
                })
            item["comments"] = normalized_comments
        normalized_items.append(item)
    normalized_payload["items"] = normalized_items
    return normalized_payload

def decrypt_payload(vault_envelope: Any, master_password: str):
    kdf_params, salt_base64, salt, nonce, ciphertext = decode_vault_envelope(vault_envelope)
    key_buffer: Optional[bytearray] = None
    plaintext_buffer: Optional[bytearray] = None
    decryption_succeeded = False
    try:
        try:
            key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        except MemoryError as error:
            raise VaultError("Argon2id 메모리 할당에 실패했습니다.") from error
        except (TypeError, ValueError) as error:
            raise VaultError("데이터베이스 KDF 매개변수를 처리할 수 없습니다.") from error
        associated_data = build_associated_data(kdf_params, salt_base64)
        try:
            plaintext_buffer = bytearray(ChaCha20Poly1305(key_buffer).decrypt(nonce, ciphertext, associated_data))
        except InvalidTag as error:
            raise VaultError("마스터 비밀번호가 올바르지 않거나 데이터베이스 파일이 변조되었습니다.") from error
        try:
            payload = json.loads(plaintext_buffer.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
            raise VaultError("복호화된 데이터베이스 내용이 손상되었습니다.") from error
        payload = normalize_payload(payload)
        decryption_succeeded = True
        return payload, key_buffer, salt, kdf_params
    finally:
        secure_wipe(plaintext_buffer)
        if not decryption_succeeded:
            secure_wipe(key_buffer)
class VaultFileLock:
    """여러 인스턴스가 서로 덮어쓰지 않도록 요약값 검사와 함께 사용하는 크로스 플랫폼 단기 파일 잠금입니다."""

    def __init__(self, vault_path: Path):
        self.lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        self.handle = None

    def __enter__(self):
        try:
            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            self.handle = self.lock_path.open("a+b")
            if self.lock_path.stat().st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                os.chmod(self.lock_path, 0o600)
        except OSError as error:
            if self.handle is not None:
                with suppress(OSError):
                    self.handle.close()
            self.handle = None
            raise VaultError(
                "데이터베이스 파일 잠금을 얻을 수 없습니다. 다른 인스턴스가 사용 중이거나 현재 디렉터리에 쓰기 권한이 없을 수 있습니다."
            ) from error
        return self

    def __exit__(self, _exception_type, _exception, _traceback):
        if self.handle is None:
            return
        try:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None

def read_vault_file_snapshot(path: Path) -> Tuple[Dict[str, Any], str]:
    if not path.exists():
        raise VaultError("데이터베이스 파일이 없습니다.")
    try:
        if path.stat().st_size > MAX_VAULT_FILE_SIZE:
            raise VaultError("데이터베이스 파일이 너무 커서 불러오지 않습니다.")
        with VaultFileLock(path):
            file_bytes = path.read_bytes()
        if len(file_bytes) > MAX_VAULT_FILE_SIZE:
            raise VaultError("데이터베이스 파일이 너무 커서 불러오지 않습니다.")
        vault_envelope = json.loads(file_bytes.decode("utf-8"))
        disk_digest = hashlib.sha256(file_bytes).hexdigest()
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
        raise VaultError("데이터베이스 파일이 손상되었거나 형식이 올바르지 않습니다.") from error
    if not isinstance(vault_envelope, dict):
        raise VaultError("데이터베이스 파일 형식이 잘못되었습니다.")
    return vault_envelope, disk_digest

def read_vault_file(path: Path) -> Dict[str, Any]:
    vault_envelope, _disk_digest = read_vault_file_snapshot(path)
    return vault_envelope

def current_vault_digest(path: Path) -> str:
    if not path.exists():
        return ""
    if path.stat().st_size > MAX_VAULT_FILE_SIZE:
        raise VaultError("데이터베이스 파일이 너무 커서 처리하지 않습니다.")
    return hashlib.sha256(path.read_bytes()).hexdigest()

def move_existing_vault_to_backup(path: Path) -> Optional[Path]:
    """기존 데이터베이스를 날짜가 포함된 .bak 파일로 이름을 바꿉니다."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with VaultFileLock(path):
        if not os.path.lexists(path):
            return None
        if not path.is_file():
            raise VaultError("기존 데이터베이스 경로가 일반 파일이 아니어서 자동으로 백업할 수 없습니다.")

        date_text = datetime.now().strftime("%Y%m%d")
        stem, suffix = path.stem, path.suffix
        backup_path = path.with_name(f"{stem}_{date_text}.bak{suffix}")
        sequence = 1
        while os.path.lexists(backup_path):
            backup_path = path.with_name(
                f"{stem}_{date_text}_{sequence}.bak{suffix}"
            )
            sequence += 1
        try:
            path.rename(backup_path)
        except OSError as error:
            raise VaultError("기존 데이터베이스의 이름 변경 및 백업에 실패하여 새 데이터베이스를 만들지 않았습니다.") from error
        return backup_path

def fsync_directory(directory: Path) -> None:
    """디렉터리 메타데이터 동기화를 가능한 범위에서 시도하며, 이미 성공적으로 기록된 데이터베이스에는 영향을 주지 않습니다."""
    if os.name == "nt":
        return
    directory_descriptor = None
    with suppress(OSError):
        directory_descriptor = os.open(directory, os.O_RDONLY)
        os.fsync(directory_descriptor)
    if directory_descriptor is not None:
        with suppress(OSError):
            os.close(directory_descriptor)

def write_vault_file_atomic(
    path: Path,
    vault_envelope: Dict[str, Any],
    expected_disk_digest: Optional[str] = None,
) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized_envelope = json.dumps(vault_envelope, ensure_ascii=False, indent=2)
    serialized_bytes = serialized_envelope.encode("utf-8")
    temporary_path = path.with_name(
        f".{path.name}.{os.getpid()}.{secrets.token_hex(6)}.tmp"
    )
    # 별도 임시 파일을 기록하고 동기화한 뒤 데이터베이스를 원자적으로 교체합니다.
    try:
        with VaultFileLock(path):
            current_digest = current_vault_digest(path)
            if (
                expected_disk_digest is not None
                and current_digest != expected_disk_digest
            ):
                raise VaultError(
                    "다른 프로그램이 데이터베이스 파일을 수정했습니다. 새 데이터를 덮어쓰지 않도록 저장을 취소했습니다. 데이터베이스를 다시 여세요."
                )
            with temporary_path.open("xb") as file_handle:
                file_handle.write(serialized_bytes)
                file_handle.flush()
                os.fsync(file_handle.fileno())
            if os.name != "nt":
                os.chmod(temporary_path, 0o600)
            os.replace(temporary_path, path)
            fsync_directory(path.parent)
    finally:
        with suppress(OSError):
            temporary_path.unlink(missing_ok=True)
    return hashlib.sha256(serialized_bytes).hexdigest()
def empty_payload() -> Dict[str, Any]:
    timestamp = now_iso()
    return {"app": APP_NAME, "version": VAULT_VERSION, "created_at": timestamp, "updated_at": timestamp, "items": []}
def password_strength_label(password: str) -> str:
    score = 0
    if len(password) >= 12:
        score += 1
    if len(password) >= 18:
        score += 1
    if len(password) >= 24:
        score += 1
    if any(character.islower() for character in password):
        score += 1
    if any(character.isupper() for character in password):
        score += 1
    if any(character.isdigit() for character in password):
        score += 1
    if any(character in string.punctuation for character in password):
        score += 1
    if score <= 3:
        return "약함"
    if score <= 5:
        return "보통"
    return "강함"
#------ 데이터베이스 핵심 ------
class VaultError(Exception):
    pass
class Vault:
    def __init__(self, path: Path):
        self.path = path
        self.key: Optional[bytearray] = None
        self.salt: Optional[bytes] = None
        self.kdf_params: Dict[str, Any] = dict(ARGON2ID_PARAMS)
        self.payload: Dict[str, Any] = empty_payload()
        self.disk_digest = ""
    def _require_unlocked(self) -> None:
        if self.key is None or self.salt is None:
            raise VaultError("데이터베이스가 잠겨 있습니다.")
    def _set_unlocked_state(
        self,
        *,
        key_buffer: bytearray,
        salt: bytes,
        kdf_params: Dict[str, Any],
        payload: Dict[str, Any],
    ) -> None:
        self.key = key_buffer
        self.salt = salt
        self.kdf_params = kdf_params
        self.payload = payload

    def _commit_payload(self, candidate_payload: Dict[str, Any]) -> None:
        self._require_unlocked()
        normalized_candidate = normalize_payload(candidate_payload)
        normalized_candidate["updated_at"] = now_iso()
        vault_envelope = encrypt_payload(
            normalized_candidate,
            self.key,
            self.salt,
            self.kdf_params,
        )
        new_digest = write_vault_file_atomic(
            self.path,
            vault_envelope,
            expected_disk_digest=self.disk_digest,
        )
        self.payload = normalized_candidate
        self.disk_digest = new_digest

    def create(self, master_password: str) -> None:
        if not master_password:
            raise VaultError("새 마스터 비밀번호는 비워 둘 수 없습니다.")
        salt = os.urandom(16)
        kdf_params = dict(ARGON2ID_PARAMS)
        key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=empty_payload(),
        )
        backup_path: Optional[Path] = None
        try:
            # 대상이 있으면 먼저 백업 이름으로 바꾸며 직접 덮어쓰지 않습니다.
            backup_path = move_existing_vault_to_backup(self.path)
            self.disk_digest = ""
            self.save()
        except Exception as error:
            self.lock()
            if backup_path is not None:
                raise VaultError(
                    f"새 데이터베이스 생성에 실패했습니다. 원본 파일은 다음 이름으로 안전하게 보존되었습니다: {backup_path.name}."
                ) from error
            raise
    def unlock(self, master_password: str) -> None:
        if self.key is not None:
            self.lock()
        vault_envelope, disk_digest = read_vault_file_snapshot(self.path)
        payload, key_buffer, salt, kdf_params = decrypt_payload(vault_envelope, master_password)
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=payload,
        )
        self.disk_digest = disk_digest
    def save(self) -> None:
        self._commit_payload(copy.deepcopy(self.payload))
    def change_master_password(self, new_master_password: str) -> None:
        self._require_unlocked()
        if not new_master_password:
            raise VaultError("새 마스터 비밀번호는 비워 둘 수 없습니다.")
        old_key = self.key
        new_salt = os.urandom(16)
        new_kdf_params = dict(ARGON2ID_PARAMS)
        new_key = bytearray(derive_key(new_master_password, new_salt, new_kdf_params))
        candidate_payload = normalize_payload(copy.deepcopy(self.payload))
        candidate_payload["updated_at"] = now_iso()
        try:
            vault_envelope = encrypt_payload(
                candidate_payload,
                new_key,
                new_salt,
                new_kdf_params,
            )
            new_digest = write_vault_file_atomic(
                self.path,
                vault_envelope,
                expected_disk_digest=self.disk_digest,
            )
        except Exception:
            secure_wipe(new_key)
            raise
        # 새 암호문이 디스크에 안전하게 기록된 뒤에만 메모리의 키를 교체합니다.
        self._set_unlocked_state(
            key_buffer=new_key,
            salt=new_salt,
            kdf_params=new_kdf_params,
            payload=candidate_payload,
        )
        self.disk_digest = new_digest
        secure_wipe(old_key)
    def lock(self) -> None:
        secure_wipe(self.key)
        self.key = None
        self.salt = None
        items = self.payload.get("items")
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    item.clear()
            items.clear()
        self.payload.clear()
        self.payload = empty_payload()
        self.disk_digest = ""
    def all_items(self, item_type: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self.payload.get("items", [])
        if item_type is None:
            return list(items)
        return [item for item in items if item.get("type") == item_type]
    def upsert_item(self, item: Dict[str, Any]) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        item_copy = copy.deepcopy(item)
        item_copy["updated_at"] = now_iso()
        for index, existing in enumerate(items):
            if existing.get("id") == item_copy.get("id"):
                items[index] = item_copy
                self._commit_payload(candidate_payload)
                return
        item_copy.setdefault("id", str(uuid.uuid4()))
        item_copy.setdefault("created_at", now_iso())
        items.append(item_copy)
        self._commit_payload(candidate_payload)
    def delete_item(self, item_id: str) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        candidate_payload["items"] = [
            item for item in items if item.get("id") != item_id
        ]
        if len(candidate_payload["items"]) == len(items):
            raise VaultError("삭제할 항목이 더 이상 존재하지 않습니다.")
        self._commit_payload(candidate_payload)
#------ 대화 상자 ------
class ProtectedDialog(QDialog):
    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, lambda: protect_widget_from_capture(self))

class FunctionThread(QThread):
    succeeded = pyqtSignal(object)
    failed = pyqtSignal(object)

    def __init__(self, operation: Callable[[], Any], parent=None):
        super().__init__(parent)
        self.operation = operation

    def run(self):
        try:
            result = self.operation()
        except Exception as error:
            self.failed.emit(error)
            return
        self.succeeded.emit(result)

class BlockingProgressDialog(QProgressDialog):
    def reject(self):
        # 키 파생은 안전하게 중단할 수 없으므로 작업 스레드가 완료 후 창을 닫습니다.
        return

def run_with_progress(
    parent,
    title: str,
    message: str,
    operation: Callable[[], Any],
) -> Any:
    dialog = BlockingProgressDialog(message, "", 0, 0, parent)
    dialog.setWindowTitle(title)
    dialog.setMinimumDuration(0)
    dialog.setAutoClose(False)
    dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
    dialog.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
    dialog.setMinimumWidth(480)
    result_holder: Dict[str, Any] = {}
    worker = FunctionThread(operation, dialog)

    def handle_success(result):
        result_holder["result"] = result
        dialog.done(QDialog.DialogCode.Accepted)

    def handle_failure(error):
        result_holder["error"] = error
        dialog.done(QDialog.DialogCode.Rejected)

    worker.succeeded.connect(handle_success)
    worker.failed.connect(handle_failure)
    worker.start()
    protect_widget_from_capture(dialog)
    dialog.exec()
    worker.wait()
    if "error" in result_holder:
        raise result_holder["error"]
    return result_holder.get("result")

def run_ui_operation(
    parent,
    error_title: str,
    operation: Callable[[], Any],
) -> Tuple[bool, Any]:
    """각 버튼마다 try/except를 반복하지 않도록 UI 작업 오류를 한곳에서 처리합니다."""
    try:
        return True, operation()
    except Exception as error:
        QMessageBox.critical(parent, error_title, str(error))
        return False, None

class StartupDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "open"
        self.setWindowTitle(APP_NAME)
        self.resize(900, 460)
        self.setMinimumWidth(860)
        self.setStyleSheet("QWidget { font-size: 16px; } QLabel#DialogTitle { font-size: 34px; }")
        title_label = QLabel("CipherNote Vault")
        title_label.setObjectName("DialogTitle")
        subtitle_label = QLabel("로컬 암호화 비밀번호 관리자 겸 보안 메모장입니다. 모든 데이터베이스 내용은 Argon2id + ChaCha20-Poly1305로 암호화되어 저장됩니다.")
        subtitle_label.setObjectName("SubtleLabel")
        subtitle_label.setWordWrap(True)
        self.open_database_radio = QRadioButton("기존 데이터베이스 열기")
        self.create_database_radio = QRadioButton("새 데이터베이스 만들기")
        self.open_database_radio.setObjectName("ModeRadio")
        self.create_database_radio.setObjectName("ModeRadio")
        self.open_database_radio.setChecked(True)
        self.mode_button_group = QButtonGroup(self)
        self.mode_button_group.addButton(self.open_database_radio)
        self.mode_button_group.addButton(self.create_database_radio)
        self.mode_button_group.setExclusive(True)
        self.open_database_radio.toggled.connect(self.update_startup_mode)
        self.create_database_radio.toggled.connect(self.update_startup_mode)
        mode_frame = QFrame()
        mode_frame.setObjectName("ModeFrame")
        mode_layout = QHBoxLayout(mode_frame)
        mode_layout.setContentsMargins(12, 10, 12, 10)
        mode_layout.setSpacing(18)
        mode_layout.addWidget(self.open_database_radio)
        mode_layout.addWidget(self.create_database_radio)
        mode_layout.addStretch(1)
        self.path_edit = QLineEdit(str(DEFAULT_VAULT))
        self.path_edit.setPlaceholderText(".cnvault 데이터베이스 파일 선택")
        browse_button = QPushButton("찾아보기")
        browse_button.clicked.connect(self.browse)
        path_layout = QHBoxLayout()
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(browse_button)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.generate_master_password_button = QPushButton("무작위 생성")
        self.generate_master_password_button.clicked.connect(self.generate_master_password)
        password_layout = QHBoxLayout()
        password_layout.addWidget(self.password_edit, 1)
        password_layout.addWidget(self.generate_master_password_button)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        self.status_label.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("작업:", mode_frame)
        form_layout.addRow("데이터베이스 파일:", path_layout)
        form_layout.addRow("마스터 비밀번호:", password_layout)
        form_layout.addRow("마스터 비밀번호 확인:", self.confirm_edit)
        form_layout.addRow("", self.status_label)
        self.ok_button = QPushButton("데이터베이스 열기")
        self.cancel_button = QPushButton("취소")
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(title_label)
        dialog_layout.addWidget(subtitle_label)
        dialog_layout.addSpacing(10)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
        self.update_startup_mode()
    def update_startup_mode(self):
        if self.create_database_radio.isChecked():
            self.mode = "create"
            self.setWindowTitle("새 데이터베이스 만들기 - CipherNote Vault")
            self.ok_button.setText("데이터베이스 만들기")
            self.confirm_edit.setEnabled(True)
            self.generate_master_password_button.setEnabled(True)
            self.status_label.setText("현재 작업: 새 데이터베이스 만들기. 강력한 암호화 매개변수로 로컬 데이터베이스를 만듭니다.")
        else:
            self.mode = "open"
            self.setWindowTitle("데이터베이스 열기 - CipherNote Vault")
            self.ok_button.setText("데이터베이스 열기")
            self.confirm_edit.setEnabled(False)
            self.generate_master_password_button.setEnabled(False)
            self.status_label.setText("현재 작업: 기존 데이터베이스 열기. 기존 .cnvault 데이터베이스를 선택하고 마스터 비밀번호를 입력하세요.")
    def generate_master_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def browse(self):
        if self.mode == "create":
            selected_filename, _selected_filter = QFileDialog.getSaveFileName(
                self,
                "CipherNote Vault 데이터베이스 만들기",
                self.path_edit.text() or str(DEFAULT_VAULT),
                "CipherNote Vault (*.cnvault);;JSON 파일 (*.json);;모든 파일 (*)",
            )
        else:
            selected_filename, _selected_filter = QFileDialog.getOpenFileName(
                self,
                "CipherNote Vault 데이터베이스 열기",
                self.path_edit.text() or str(DEFAULT_VAULT_DIR),
                "CipherNote Vault (*.cnvault);;JSON 파일 (*.json);;모든 파일 (*)",
            )
        if selected_filename:
            self.path_edit.setText(selected_filename)
    def get_result(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            raw_path = self.path_edit.text().strip()
            master_password = self.password_edit.text()
            if not raw_path:
                QMessageBox.warning(self, "경로 없음", "데이터베이스 파일 경로를 선택하세요.")
                continue
            database_path = Path(raw_path).expanduser()
            if not master_password:
                QMessageBox.warning(self, "마스터 비밀번호 없음", "마스터 비밀번호를 입력하세요.")
                continue
            if self.mode == "create":
                if master_password != self.confirm_edit.text():
                    QMessageBox.warning(self, "비밀번호 불일치", "입력한 마스터 비밀번호가 일치하지 않습니다.")
                    continue
                if database_path.exists():
                    if database_path.is_dir():
                        QMessageBox.warning(self, "잘못된 경로", "데이터베이스 경로로 폴더를 지정할 수 없습니다.")
                        continue
                    answer = QMessageBox.question(
                        self,
                        "파일이 이미 있음",
                        "이 파일은 이미 존재합니다. 계속하면 원본 파일을 덮어쓰지 않고 날짜와 .bak 표시가 포함된 백업 이름으로 자동 변경합니다.\n\n새 데이터베이스를 만드시겠습니까?",
                    )
                    if answer != QMessageBox.StandardButton.Yes:
                        continue
                result = {"mode": "create", "path": database_path, "password": master_password}
                self.password_edit.clear()
                self.confirm_edit.clear()
                return result
            if not database_path.is_file():
                QMessageBox.warning(self, "파일 없음", "이미 존재하는 데이터베이스 파일을 선택하세요.")
                continue
            result = {"mode": "open", "path": database_path, "password": master_password}
            self.password_edit.clear()
            self.confirm_edit.clear()
            return result
class PasswordGeneratorDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.generated_password = ""
        self.setWindowTitle("무작위 비밀번호 생성")
        self.resize(720, 520)
        self.setMinimumSize(680, 500)
        self.setModal(True)
        self.setStyleSheet("""
            QDialog {
                background-color: #241000;
            }
            QLabel {
                color: #F7D000;
                font-size: 17px;
            }
            QLabel#GeneratorTitle {
                color: #FFF000;
                font-size: 30px;
                font-weight: 700;
            }
            QLabel#GeneratorSubtitle {
                color: #D9A400;
                font-size: 15px;
            }
            QLabel#SectionTitle {
                color: #FFF000;
                font-size: 18px;
                font-weight: 700;
            }
            QLabel#StatusLabel {
                color: #D9A400;
                font-size: 14px;
            }
            QFrame#PasswordPreviewCard,
            QFrame#OptionsCard {
                background-color: #351100;
                border: 1px solid #7C1D00;
                border-radius: 12px;
            }
            QLineEdit#PasswordPreview {
                background-color: #170800;
                color: #FFF000;
                border: 2px solid #E9C400;
                border-radius: 9px;
                padding: 12px 14px;
                font-size: 21px;
                font-family: Consolas, "Courier New", monospace;
                selection-background-color: #FFD700;
                selection-color: #FF0000;
            }
            QSpinBox {
                min-height: 38px;
                min-width: 120px;
                padding: 0 10px;
                color: #FFF000;
                background-color: #170800;
                border: 1px solid #8A1F00;
                border-radius: 7px;
                font-size: 18px;
            }
            QCheckBox {
                color: #F7D000;
                font-size: 17px;
                spacing: 10px;
                min-height: 34px;
            }
            QPushButton {
                min-height: 42px;
                padding: 0 18px;
                color: #241000;
                background-color: #E9C400;
                border: 1px solid #F1C900;
                border-radius: 8px;
                font-size: 17px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #F3D500;
            }
            QPushButton:pressed {
                background-color: #D89C00;
            }
            QPushButton#SecondaryButton {
                color: #F7D000;
                background-color: #5F1700;
                border-color: #9A3400;
            }
            QPushButton#SecondaryButton:hover {
                background-color: #7C1D00;
            }
            QPushButton#CancelButton {
                color: #F7D000;
                background-color: #351100;
                border-color: #7C1D00;
            }
            QPushButton#CancelButton:hover {
                background-color: #5F1700;
            }
        """)
        self.build_interface()
        self.connect_signals()
        self.refresh_password()

    def build_interface(self):
        title_label = QLabel("무작위 비밀번호 생성기")
        title_label.setObjectName("GeneratorTitle")
        subtitle_label = QLabel("비밀번호 길이와 문자 유형을 선택하세요. 시스템의 안전한 난수로 비밀번호를 생성합니다.")
        subtitle_label.setObjectName("GeneratorSubtitle")
        subtitle_label.setWordWrap(True)

        self.password_preview = QLineEdit()
        self.password_preview.setObjectName("PasswordPreview")
        self.password_preview.setReadOnly(True)
        self.password_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.password_preview.setMinimumHeight(58)

        preview_title = QLabel("생성 결과")
        preview_title.setObjectName("SectionTitle")
        preview_card = QFrame()
        preview_card.setObjectName("PasswordPreviewCard")
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(18, 16, 18, 18)
        preview_layout.setSpacing(10)
        preview_layout.addWidget(preview_title)
        preview_layout.addWidget(self.password_preview)

        length_label = QLabel("비밀번호 길이")
        length_label.setObjectName("SectionTitle")
        self.password_length_spinbox = QSpinBox()
        self.password_length_spinbox.setRange(1, MAX_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setValue(DEFAULT_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setSuffix("자")
        length_row = QHBoxLayout()
        length_row.setSpacing(14)
        length_row.addWidget(length_label)
        length_row.addStretch(1)
        length_row.addWidget(self.password_length_spinbox)

        character_label = QLabel("포함할 문자")
        character_label.setObjectName("SectionTitle")
        self.include_lowercase_checkbox = QCheckBox("소문자  a-z")
        self.include_uppercase_checkbox = QCheckBox("대문자  A-Z")
        self.include_digits_checkbox = QCheckBox("숫자  0-9")
        self.include_symbols_checkbox = QCheckBox("특수 기호  !@#$...")
        for checkbox in (
            self.include_lowercase_checkbox,
            self.include_uppercase_checkbox,
            self.include_digits_checkbox,
            self.include_symbols_checkbox,
        ):
            checkbox.setChecked(True)

        checkbox_row_1 = QHBoxLayout()
        checkbox_row_1.setSpacing(24)
        checkbox_row_1.addWidget(self.include_lowercase_checkbox, 1)
        checkbox_row_1.addWidget(self.include_uppercase_checkbox, 1)
        checkbox_row_2 = QHBoxLayout()
        checkbox_row_2.setSpacing(24)
        checkbox_row_2.addWidget(self.include_digits_checkbox, 1)
        checkbox_row_2.addWidget(self.include_symbols_checkbox, 1)

        self.status_label = QLabel("기본적으로 32자 비밀번호를 생성합니다.")
        self.status_label.setObjectName("StatusLabel")
        self.status_label.setWordWrap(True)

        options_card = QFrame()
        options_card.setObjectName("OptionsCard")
        options_layout = QVBoxLayout(options_card)
        options_layout.setContentsMargins(18, 16, 18, 16)
        options_layout.setSpacing(12)
        options_layout.addLayout(length_row)
        options_layout.addSpacing(4)
        options_layout.addWidget(character_label)
        options_layout.addLayout(checkbox_row_1)
        options_layout.addLayout(checkbox_row_2)
        options_layout.addWidget(self.status_label)

        self.regenerate_button = QPushButton("다시 생성")
        self.regenerate_button.setObjectName("SecondaryButton")
        self.use_password_button = QPushButton("이 비밀번호 사용")
        self.cancel_button = QPushButton("취소")
        self.cancel_button.setObjectName("CancelButton")

        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)
        button_layout.addWidget(self.regenerate_button)
        button_layout.addStretch(1)
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.use_password_button)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(16)
        main_layout.addWidget(title_label)
        main_layout.addWidget(subtitle_label)
        main_layout.addWidget(preview_card)
        main_layout.addWidget(options_card)
        main_layout.addStretch(1)
        main_layout.addLayout(button_layout)

    def connect_signals(self):
        self.regenerate_button.clicked.connect(self.refresh_password)
        self.use_password_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        self.password_length_spinbox.valueChanged.connect(self.refresh_password)
        self.include_lowercase_checkbox.toggled.connect(self.refresh_password)
        self.include_uppercase_checkbox.toggled.connect(self.refresh_password)
        self.include_digits_checkbox.toggled.connect(self.refresh_password)
        self.include_symbols_checkbox.toggled.connect(self.refresh_password)

    def refresh_password(self):
        try:
            self.generated_password = generate_secure_password(
                length=self.password_length_spinbox.value(),
                include_lowercase=self.include_lowercase_checkbox.isChecked(),
                include_uppercase=self.include_uppercase_checkbox.isChecked(),
                include_digits=self.include_digits_checkbox.isChecked(),
                include_symbols=self.include_symbols_checkbox.isChecked(),
            )
        except ValueError as error:
            self.generated_password = ""
            self.password_preview.clear()
            self.status_label.setText(str(error))
            self.use_password_button.setEnabled(False)
            return
        self.password_preview.setText(self.generated_password)
        self.password_preview.setCursorPosition(0)
        enabled_types = sum((
            self.include_lowercase_checkbox.isChecked(),
            self.include_uppercase_checkbox.isChecked(),
            self.include_digits_checkbox.isChecked(),
            self.include_symbols_checkbox.isChecked(),
        ))
        self.status_label.setText(
            f"길이: {self.password_length_spinbox.value()}자    "
            f"문자 유형: {enabled_types}종"
        )
        self.use_password_button.setEnabled(True)

    def generate(self) -> Optional[str]:
        if self.exec() != QDialog.DialogCode.Accepted:
            self.generated_password = ""
            self.password_preview.clear()
            return None
        password = self.generated_password
        self.generated_password = ""
        self.password_preview.clear()
        return password
class PasswordDialog(ProtectedDialog):
    def __init__(self, item: Optional[Dict[str, Any]] = None, parent=None):
        super().__init__(parent)
        self.item = item or {}
        self.setWindowTitle("비밀번호 항목")
        self.resize(940, 680)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.username_edit = QLineEdit(self.item.get("username", ""))
        self.password_edit = QLineEdit(self.item.get("password", ""))
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.notes_edit = QPlainTextEdit(self.item.get("notes", ""))
        self.strength_label = QLabel("")
        self.strength_label.setObjectName("SubtleLabel")
        self.password_edit.textChanged.connect(self.update_strength)
        self.update_strength()
        show_password_button = QPushButton("표시/숨기기")
        generate_password_button = QPushButton("무작위 생성")
        show_password_button.clicked.connect(self.toggle_password_visibility)
        generate_password_button.clicked.connect(self.generate_password)
        password_row = QHBoxLayout()
        password_row.addWidget(self.password_edit, 1)
        password_row.addWidget(show_password_button)
        password_row.addWidget(generate_password_button)
        form_layout = QFormLayout()
        form_layout.addRow("제목:", self.title_edit)
        form_layout.addRow("사용자 이름: ", self.username_edit)
        form_layout.addRow("비밀번호: ", password_row)
        form_layout.addRow("", self.strength_label)
        form_layout.addRow("메모: ", self.notes_edit)
        save_button = QPushButton("저장")
        cancel_button = QPushButton("취소")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def update_strength(self):
        password_value = self.password_edit.text()
        self.strength_label.setText(
            "비밀번호 강도: 입력 안 함"
            if not password_value
            else f"비밀번호 강도: {password_strength_label(password_value)}"
        )
    def toggle_password_visibility(self):
        if self.password_edit.echoMode() == QLineEdit.EchoMode.Password:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
        else:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def clear_sensitive_fields(self) -> None:
        self.password_edit.clear()
        self.notes_edit.clear()
        self.username_edit.clear()
        self.title_edit.clear()
        self.item = {}
    def build_password_item(self) -> Optional[Dict[str, Any]]:
        title_value = self.title_edit.text().strip()
        if not title_value:
            QMessageBox.warning(self, "제목 없음", "제목은 비워 둘 수 없습니다.")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "password",
            "title": title_value,
            "username": self.username_edit.text().strip(),
            "password": self.password_edit.text(),
            "notes": self.notes_edit.toPlainText(),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }
    def get_item(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.clear_sensitive_fields()
                return None
            result = self.build_password_item()
            if result is None:
                continue
            self.clear_sensitive_fields()
            return result
class NoteDialog(ProtectedDialog):
    def __init__(
        self,
        item: Optional[Dict[str, Any]] = None,
        parent=None,
        on_save: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        super().__init__(parent)
        self.item = copy.deepcopy(item or {})
        self.comments: List[Dict[str, Any]] = copy.deepcopy(
            self.item.get("comments", [])
        )
        self.on_save = on_save
        self.saved_item: Optional[Dict[str, Any]] = None
        self.is_dirty = False
        self._suppress_dirty = True
        self._last_note_match = None
        self.setWindowTitle("보안 메모")
        self.resize(1320, 860)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.title_edit.setPlaceholderText("메모 제목")
        self.content_edit = QPlainTextEdit(self.item.get("content", ""))
        self.content_edit.setObjectName("NoteContentEditor")
        self.content_edit.setPlaceholderText("중요한 메모를 여기에 작성하세요...")
        self.note_font_slider = QSlider(Qt.Orientation.Horizontal)
        self.note_font_slider.setRange(12, 36)
        self.note_font_slider.setValue(int(self.item.get("font_size", 20) or 20))
        self.note_font_slider.setFixedWidth(180)
        self.note_font_slider.valueChanged.connect(self.apply_note_font_size)
        self.note_font_size_label = QLabel(f"글꼴 {self.note_font_slider.value()}")
        self.note_font_size_label.setObjectName("SubtleLabel")
        self.save_status_label = QLabel("Ctrl+S로 창을 닫지 않고 저장")
        self.save_status_label.setObjectName("SubtleLabel")
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(8)
        title_label = QLabel("제목")
        title_label.setObjectName("SearchLabel")
        title_label.setFixedWidth(44)
        title_layout.addWidget(title_label)
        title_layout.addWidget(self.title_edit, 1)
        import_button = QPushButton("텍스트 가져오기")
        cleanup_button = QPushButton("빈 줄 정리")
        import_button.clicked.connect(self.import_text_file)
        cleanup_button.clicked.connect(self.cleanup_blank_lines)
        title_layout.addWidget(import_button)
        title_layout.addWidget(cleanup_button)

        self.note_find_edit = QLineEdit()
        self.note_find_edit.setPlaceholderText("찾을 내용")
        self.note_replace_edit = QLineEdit()
        self.note_replace_edit.setPlaceholderText("바꿀 내용")
        self.note_regex_checkbox = QCheckBox("정규식")
        self.note_search_status = QLabel("")
        self.note_search_status.setObjectName("SubtleLabel")
        find_next_button = QPushButton("다음 찾기")
        replace_button = QPushButton("현재 항목 바꾸기")
        replace_all_button = QPushButton("모두 바꾸기")
        find_next_button.clicked.connect(self.find_next_in_note)
        replace_button.clicked.connect(self.replace_current_match)
        replace_all_button.clicked.connect(self.replace_all_matches)
        self.note_find_edit.returnPressed.connect(self.find_next_in_note)
        find_shortcut = QShortcut(QKeySequence.StandardKey.Find, self)
        find_shortcut.activated.connect(self.focus_note_search)
        search_frame = QFrame()
        search_frame.setObjectName("InlineSearch")
        search_layout = QHBoxLayout(search_frame)
        search_layout.setContentsMargins(8, 6, 8, 6)
        search_layout.setSpacing(6)
        search_layout.addWidget(QLabel("찾기"))
        search_layout.addWidget(self.note_find_edit, 2)
        search_layout.addWidget(QLabel("바꾸기"))
        search_layout.addWidget(self.note_replace_edit, 2)
        search_layout.addWidget(self.note_regex_checkbox)
        search_layout.addWidget(find_next_button)
        search_layout.addWidget(replace_button)
        search_layout.addWidget(replace_all_button)
        search_layout.addWidget(self.note_search_status, 1)

        self.comment_list = QListWidget()
        self.comment_list.setObjectName("CommentList")
        self.comment_list.setAlternatingRowColors(True)
        self.comment_list.currentItemChanged.connect(self.show_selected_comment)
        self.comment_preview = QPlainTextEdit()
        self.comment_preview.setObjectName("CommentPreview")
        self.comment_preview.setReadOnly(True)
        self.comment_preview.setPlaceholderText("내용을 보려면 주석을 선택하세요")
        self.comment_preview.setMaximumHeight(180)
        add_comment_button = QPushButton("주석 추가")
        edit_comment_button = QPushButton("편집")
        delete_comment_button = QPushButton("삭제")
        add_comment_button.clicked.connect(self.add_comment)
        edit_comment_button.clicked.connect(self.edit_comment)
        delete_comment_button.clicked.connect(self.delete_comment)
        comment_button_layout = QHBoxLayout()
        comment_button_layout.setSpacing(6)
        comment_button_layout.addWidget(add_comment_button)
        comment_button_layout.addWidget(edit_comment_button)
        comment_button_layout.addWidget(delete_comment_button)
        comments_title = QLabel("오른쪽 주석(중첩 없는 평면 목록)")
        comments_title.setObjectName("SectionTitle")
        comments_panel = QFrame()
        comments_panel.setObjectName("CommentsPanel")
        comments_layout = QVBoxLayout(comments_panel)
        comments_layout.setContentsMargins(10, 10, 10, 10)
        comments_layout.setSpacing(8)
        comments_layout.addWidget(comments_title)
        comments_layout.addWidget(self.comment_list, 1)
        comments_layout.addWidget(self.comment_preview)
        comments_layout.addLayout(comment_button_layout)

        editor_splitter = QSplitter(Qt.Orientation.Horizontal)
        editor_splitter.addWidget(self.content_edit)
        editor_splitter.addWidget(comments_panel)
        editor_splitter.setStretchFactor(0, 4)
        editor_splitter.setStretchFactor(1, 1)
        editor_splitter.setSizes([980, 320])

        save_button = QPushButton("저장")
        close_button = QPushButton("닫기")
        save_button.clicked.connect(self.save_without_closing)
        close_button.clicked.connect(self.close)
        save_shortcut = QShortcut(QKeySequence.StandardKey.Save, self)
        save_shortcut.activated.connect(self.save_without_closing)
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 6, 0, 0)
        bottom_layout.setSpacing(8)
        bottom_layout.addWidget(QLabel("글꼴"))
        bottom_layout.addWidget(self.note_font_slider)
        bottom_layout.addWidget(self.note_font_size_label)
        bottom_layout.addSpacing(14)
        bottom_layout.addWidget(self.save_status_label)
        bottom_layout.addStretch(1)
        bottom_layout.addWidget(save_button)
        bottom_layout.addWidget(close_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.setContentsMargins(10, 10, 10, 10)
        dialog_layout.setSpacing(6)
        dialog_layout.addLayout(title_layout)
        dialog_layout.addWidget(search_frame)
        dialog_layout.addWidget(editor_splitter, 1)
        dialog_layout.addLayout(bottom_layout)
        self.apply_note_font_size()
        self.refresh_comment_list()
        self.title_edit.textChanged.connect(self.mark_dirty)
        self.content_edit.textChanged.connect(self.mark_dirty)
        self.note_font_slider.valueChanged.connect(self.mark_dirty)
        self._suppress_dirty = False

    def mark_dirty(self, *_args):
        if self._suppress_dirty:
            return
        self._last_note_match = None
        self.is_dirty = True
        self.save_status_label.setText("저장 안 됨 · Ctrl+S로 저장")

    def apply_note_font_size(self):
        note_font = QFont("Malgun Gothic")
        note_font.setPointSize(self.note_font_slider.value())
        self.content_edit.setFont(note_font)
        self.note_font_size_label.setText(f"글꼴 {self.note_font_slider.value()}")

    def focus_note_search(self):
        self.note_find_edit.setFocus()
        self.note_find_edit.selectAll()

    def build_note_search_pattern(self) -> Optional[Pattern[str]]:
        pattern_text = self.note_find_edit.text()
        if not pattern_text:
            self.note_search_status.setText("찾을 내용을 입력하세요")
            return None
        try:
            if self.note_regex_checkbox.isChecked():
                return compile_search_regex(pattern_text)
            return re.compile(re.escape(pattern_text), re.IGNORECASE | re.UNICODE)
        except ValueError as error:
            self.note_search_status.setText(str(error))
            return None

    def find_next_in_note(self) -> bool:
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return False
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        start_position = qt_position_to_python_index(
            source_text,
            cursor.selectionEnd() if cursor.hasSelection() else cursor.position(),
        )
        if self._last_note_match is not None:
            previous_match = self._last_note_match[0]
            if previous_match.start() == previous_match.end():
                start_position = min(len(source_text), start_position + 1)
        match = compiled_pattern.search(source_text, start_position)
        wrapped = False
        if match is None and start_position > 0:
            match = compiled_pattern.search(source_text, 0, start_position)
            wrapped = match is not None
        if match is None:
            self._last_note_match = None
            self.note_search_status.setText("찾지 못함")
            return False
        selection_cursor = self.content_edit.textCursor()
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.start())
        )
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.end()),
            QTextCursor.MoveMode.KeepAnchor,
        )
        self.content_edit.setTextCursor(selection_cursor)
        self.content_edit.ensureCursorVisible()
        self.content_edit.setFocus()
        self._last_note_match = (
            match,
            self.note_regex_checkbox.isChecked(),
        )
        self.note_search_status.setText("처음부터 계속 검색함" if wrapped else "찾음")
        return True

    def replace_current_match(self):
        if self._last_note_match is None and not self.find_next_in_note():
            return
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        match, regex_mode = self._last_note_match
        selected_start = qt_position_to_python_index(
            source_text, cursor.selectionStart()
        )
        selected_end = qt_position_to_python_index(
            source_text, cursor.selectionEnd()
        )
        if (selected_start, selected_end) != (match.start(), match.end()):
            self._last_note_match = None
            if not self.find_next_in_note():
                return
            cursor = self.content_edit.textCursor()
            match, regex_mode = self._last_note_match
        replacement_text = self.note_replace_edit.text()
        try:
            replacement_value = (
                match.expand(replacement_text) if regex_mode else replacement_text
            )
        except re.error as error:
            self.note_search_status.setText(f"잘못된 바꾸기 식: {error}")
            return
        cursor.insertText(replacement_value)
        self.content_edit.setTextCursor(cursor)
        self.note_search_status.setText("1곳을 바꿈")

    def replace_all_matches(self):
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return
        source_text = self.content_edit.toPlainText()
        replacement_text = self.note_replace_edit.text()
        try:
            if self.note_regex_checkbox.isChecked():
                replaced_text, replacement_count = compiled_pattern.subn(
                    replacement_text,
                    source_text,
                )
            else:
                replaced_text, replacement_count = compiled_pattern.subn(
                    lambda _match: replacement_text,
                    source_text,
                )
        except re.error as error:
            self.note_search_status.setText(f"잘못된 바꾸기 식: {error}")
            return
        if replacement_count == 0:
            self.note_search_status.setText("바꿀 내용을 찾지 못함")
            return
        self.replace_editor_text(replaced_text)
        self.mark_dirty()
        self.note_search_status.setText(f"바꿈: {replacement_count}곳 · 실행 취소 가능")

    def replace_editor_text(self, new_text: str):
        cursor = self.content_edit.textCursor()
        cursor.beginEditBlock()
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.insertText(new_text)
        cursor.endEditBlock()
        self.content_edit.setTextCursor(cursor)

    def import_text_file(self):
        selected_filename, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "텍스트 파일 가져오기",
            "",
            "텍스트 파일 (*.txt *.md *.log *.csv *.json *.xml *.html);;모든 파일 (*)",
        )
        if not selected_filename:
            return
        source_path = Path(selected_filename)
        succeeded, import_result = run_ui_operation(
            self,
            "가져오기 실패",
            lambda: read_imported_text_file(source_path),
        )
        if not succeeded:
            return
        imported_text, encoding, coherence = import_result

        choice_box = QMessageBox(self)
        choice_box.setWindowTitle("가져오기 방식")
        choice_box.setText(
            f"감지한 인코딩: {encoding} (신뢰도 {coherence:.1f}%)\n\n"
            "현재 본문을 바꾸거나 본문 끝에 추가할지 선택하세요."
        )
        replace_button = choice_box.addButton(
            "본문 바꾸기", QMessageBox.ButtonRole.AcceptRole
        )
        append_button = choice_box.addButton(
            "본문에 추가", QMessageBox.ButtonRole.ActionRole
        )
        choice_box.addButton("취소", QMessageBox.ButtonRole.RejectRole)
        choice_box.exec()
        clicked_button = choice_box.clickedButton()
        if clicked_button == replace_button:
            self.replace_editor_text(imported_text)
        elif clicked_button == append_button:
            current_text = self.content_edit.toPlainText()
            separator = "\n" if current_text and not current_text.endswith("\n") else ""
            self.replace_editor_text(current_text + separator + imported_text)
        else:
            return
        self.mark_dirty()
        self.save_status_label.setText(
            f"가져옴: {source_path.name} · 인코딩 {encoding} · 저장 안 됨"
        )

    def cleanup_blank_lines(self):
        original_text = self.content_edit.toPlainText()
        cleaned_text = remove_extra_blank_lines(original_text)
        if cleaned_text == original_text:
            self.save_status_label.setText("불필요한 빈 줄이 없습니다")
            return
        self.replace_editor_text(cleaned_text)
        self.mark_dirty()
        self.save_status_label.setText("불필요한 빈 줄 정리 완료 · 저장 안 됨 · 실행 취소 가능")

    def refresh_comment_list(self, select_id: Optional[str] = None):
        self.comment_list.clear()
        selected_row = -1
        for index, comment in enumerate(self.comments):
            quote = str(comment.get("quote", "")).strip().replace("\n", " ")
            body = str(comment.get("text", "")).strip().replace("\n", " ")
            anchor_label = f"“{quote[:34]}”" if quote else "전체 메모"
            display_text = f"{anchor_label}\n{body[:72]}"
            list_item = QListWidgetItem(display_text)
            list_item.setData(Qt.ItemDataRole.UserRole, comment.get("id"))
            list_item.setToolTip(body)
            self.comment_list.addItem(list_item)
            if select_id and comment.get("id") == select_id:
                selected_row = index
        if selected_row >= 0:
            self.comment_list.setCurrentRow(selected_row)
        elif self.comments:
            self.comment_list.setCurrentRow(0)
        else:
            self.comment_preview.clear()

    def selected_comment(self) -> Optional[Dict[str, Any]]:
        list_item = self.comment_list.currentItem()
        if list_item is None:
            return None
        comment_id = list_item.data(Qt.ItemDataRole.UserRole)
        return next(
            (comment for comment in self.comments if comment.get("id") == comment_id),
            None,
        )

    def show_selected_comment(self, *_args):
        comment = self.selected_comment()
        if comment is None:
            self.comment_preview.clear()
            return
        quote = str(comment.get("quote", ""))
        body = str(comment.get("text", ""))
        preview = f"인용:\n{quote}\n\n주석:\n{body}" if quote else f"주석:\n{body}"
        self.comment_preview.setPlainText(preview)
        if quote:
            found_cursor = self.content_edit.document().find(quote)
            if not found_cursor.isNull():
                self.content_edit.setTextCursor(found_cursor)
                self.content_edit.ensureCursorVisible()

    def add_comment(self):
        selected_quote = self.content_edit.textCursor().selectedText()
        selected_quote = selected_quote.replace("\u2029", "\n").strip()
        comment_text, accepted = QInputDialog.getMultiLineText(
            self,
            "주석 추가",
            "주석 내용:",
        )
        comment_text = comment_text.strip()
        if not accepted or not comment_text:
            return
        timestamp = now_iso()
        comment = {
            "id": str(uuid.uuid4()),
            "quote": selected_quote,
            "text": comment_text,
            "created_at": timestamp,
            "updated_at": timestamp,
        }
        self.comments.append(comment)
        self.refresh_comment_list(comment["id"])
        self.mark_dirty()

    def edit_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "주석 선택", "먼저 주석을 선택하세요.")
            return
        updated_text, accepted = QInputDialog.getMultiLineText(
            self,
            "주석 편집",
            "주석 내용:",
            str(comment.get("text", "")),
        )
        updated_text = updated_text.strip()
        if not accepted or not updated_text:
            return
        comment["text"] = updated_text
        comment["updated_at"] = now_iso()
        self.refresh_comment_list(str(comment.get("id", "")))
        self.mark_dirty()

    def delete_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "주석 선택", "먼저 주석을 선택하세요.")
            return
        answer = QMessageBox.question(self, "삭제 확인", "이 주석을 삭제하시겠습니까?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        comment_id = comment.get("id")
        self.comments = [
            existing for existing in self.comments
            if existing.get("id") != comment_id
        ]
        self.refresh_comment_list()
        self.mark_dirty()

    def build_note_item(self) -> Optional[Dict[str, Any]]:
        note_title = self.title_edit.text().strip()
        if not note_title:
            QMessageBox.warning(self, "제목 없음", "제목은 비워 둘 수 없습니다.")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "note",
            "title": note_title,
            "content": self.content_edit.toPlainText(),
            "font_size": self.note_font_slider.value(),
            "comments": copy.deepcopy(self.comments),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }

    def save_without_closing(self) -> bool:
        note_item = self.build_note_item()
        if note_item is None:
            return False
        if self.on_save is not None:
            succeeded, _result = run_ui_operation(
                self,
                "저장 실패",
                lambda: self.on_save(copy.deepcopy(note_item)),
            )
            if not succeeded:
                self.save_status_label.setText("저장에 실패했습니다. 내용은 편집 창에 그대로 남아 있습니다")
                return False
        self.item = copy.deepcopy(note_item)
        self.saved_item = copy.deepcopy(note_item)
        self.is_dirty = False
        self.save_status_label.setText(f"저장됨: {readable_time(note_item.get('updated_at', ''))}")
        return True

    def get_item(self) -> Optional[Dict[str, Any]]:
        self.exec()
        return copy.deepcopy(self.saved_item)

    def clear_sensitive_fields(self):
        self._suppress_dirty = True
        self.title_edit.clear()
        self.content_edit.clear()
        self.note_find_edit.clear()
        self.note_replace_edit.clear()
        self.comment_preview.clear()
        self.comment_list.clear()
        self.comments.clear()
        self.item.clear()
        self._last_note_match = None

    def closeEvent(self, event):
        if self.is_dirty:
            message_box = QMessageBox(self)
            message_box.setWindowTitle("저장 안 됨")
            message_box.setText("메모에 저장하지 않은 변경 사항이 있습니다.")
            save_button = message_box.addButton(
                "저장하고 닫기", QMessageBox.ButtonRole.AcceptRole
            )
            discard_button = message_box.addButton(
                "변경 사항 버리기", QMessageBox.ButtonRole.DestructiveRole
            )
            message_box.addButton("취소", QMessageBox.ButtonRole.RejectRole)
            message_box.exec()
            clicked_button = message_box.clickedButton()
            if clicked_button == save_button:
                if not self.save_without_closing():
                    event.ignore()
                    return
            elif clicked_button != discard_button:
                event.ignore()
                return
        self.clear_sensitive_fields()
        event.accept()

class MasterPasswordDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("마스터 비밀번호 변경")
        self.resize(650, 320)
        self.setMinimumWidth(620)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        hint = QLabel("마스터 비밀번호를 변경하면 새 salt를 생성하고 새 Argon2id 파생 키로 데이터베이스를 다시 암호화합니다.")
        hint.setObjectName("SubtleLabel")
        hint.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("새 마스터 비밀번호:", self.password_edit)
        form_layout.addRow("마스터 비밀번호 확인:", self.confirm_edit)
        generate_password_button = QPushButton("무작위 생성")
        generate_password_button.clicked.connect(self.generate_password)
        save_button = QPushButton("변경")
        cancel_button = QPushButton("취소")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addWidget(generate_password_button)
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(hint)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def get_password(self) -> Optional[str]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            master_password = self.password_edit.text()
            if not master_password:
                QMessageBox.warning(self, "마스터 비밀번호 없음", "새 마스터 비밀번호를 입력하세요.")
                continue
            if master_password != self.confirm_edit.text():
                QMessageBox.warning(self, "비밀번호 불일치", "입력한 마스터 비밀번호가 일치하지 않습니다.")
                continue
            self.password_edit.clear()
            self.confirm_edit.clear()
            return master_password
#------ 기본 화면 구성 요소 ------
class DetailCard(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self.title = QLabel("항목을 선택하세요")
        self.title.setObjectName("CardTitle")
        self.title.setWordWrap(True)
        self.meta = QLabel("")
        self.meta.setObjectName("SubtleLabel")
        self.meta.setWordWrap(True)
        self.body = QPlainTextEdit("")
        self.body.setObjectName("BodyLabel")
        self.body.setReadOnly(True)
        self.body.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.body.setWordWrapMode(
            QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere
        )
        self.body.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.body.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.addWidget(self.title)
        layout.addWidget(self.meta)
        layout.addSpacing(10)
        layout.addWidget(self.body, 1)
    def show_password_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("비밀번호 항목을 선택하세요")
            self.meta.setText("")
            self.body.setPlainText("왼쪽 목록에서 검색할 수 있으며, 항목을 두 번 클릭하면 편집할 수 있습니다.")
            return
        masked = "•" * min(max(len(item.get("password", "")), 8), 24)
        self.title.setText(item.get("title", ""))
        self.meta.setText(f"업데이트 시간: {readable_time(item.get('updated_at', ''))}")
        self.body.setPlainText(
            f"사용자 이름: {item.get('username', '')}\n"
            f"비밀번호: {masked}\n\n"
            f"메모: \n{item.get('notes', '')}"
        )
    def show_note_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("보안 메모를 선택하세요")
            self.meta.setText("")
            self.body.setPlainText("왼쪽 목록에서 검색할 수 있으며, 항목을 두 번 클릭하면 편집기를 열 수 있습니다.")
            return
        self.title.setText(item.get("title", ""))
        comment_count = len(item.get("comments", []))
        self.meta.setText(
            f"업데이트 시간: {readable_time(item.get('updated_at', ''))} · "
            f"주석:{comment_count}개"
        )
        self.body.setPlainText(item.get("content", ""))
#------ 기본 창 ------
class MainWindow(QMainWindow):
    def __init__(self, vault: Vault):
        super().__init__()
        self.vault = vault
        self.setWindowTitle(f"{APP_NAME} - {vault.path}")
        self.resize(1240, 790)
        self.password_items_all: List[Dict[str, Any]] = []
        self.password_items_view: List[Dict[str, Any]] = []
        self.note_items_all: List[Dict[str, Any]] = []
        self.note_items_view: List[Dict[str, Any]] = []
        self.crypto_wallet_result: Optional[Dict[str, Any]] = None
        self._lock_in_progress = False
        self.managed_clipboard_digest: Optional[bytes] = None
        self.search_edit = QLineEdit()
        self.search_edit.setObjectName("기본 도구 모음SearchInput")
        self.search_edit.setFixedHeight(32)
        self.search_edit.setPlaceholderText(
            "최장 공통 부분 수열 검색(대소문자 구분 안 함), *는 와일드카드입니다. 예: 시작*끝"
        )
        self.search_mode = QComboBox()
        self.search_mode.addItems(["LCS / 와일드카드", "정규식"])
        self.search_mode.setMinimumWidth(130)
        self.search_mode.setFixedHeight(32)
        self.search_edit.textChanged.connect(self.apply_filter)
        self.search_edit.returnPressed.connect(self.apply_filter)
        self.search_mode.currentIndexChanged.connect(self.search_mode_changed)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.password_table = self.make_table(["제목", "사용자 이름", "메모", "업데이트 시간"])
        self.note_table = self.make_table(["제목", "주석", "업데이트 시간"])
        self.password_detail = DetailCard()
        self.note_detail = DetailCard()
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.note_splitter = QSplitter(Qt.Orientation.Horizontal)
        # 긴 메모가 분할 막대의 이동 범위를 제한하지 않도록 내용 너비 힌트를 무시합니다.
        for splitter, table, detail in (
            (self.password_splitter, self.password_table, self.password_detail),
            (self.note_splitter, self.note_table, self.note_detail),
        ):
            splitter.setHandleWidth(10)
            splitter.setOpaqueResize(True)
            splitter.setStretchFactor(0, 3)
            splitter.setStretchFactor(1, 2)
            splitter.setCollapsible(0, False)
            splitter.setCollapsible(1, True)
            table.setMinimumWidth(320)
            table.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
            detail.setMinimumWidth(0)
            detail.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
        self.tabs.addTab(self.make_password_tab(), "비밀번호 관리자")
        self.tabs.addTab(self.make_note_tab(), "보안 메모")
        self.tabs.addTab(self.make_crypto_tab(), "암호화폐")
        self.make_toolbar()
        self.setup_context_menus()
        main = QWidget()
        layout = QVBoxLayout(main)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        top_card = QFrame()
        top_card.setObjectName("TopCard")
        top_layout = QHBoxLayout(top_card)
        top_layout.setContentsMargins(10, 8, 10, 8)
        top_layout.setSpacing(8)
        search_label = QLabel("검색")
        search_label.setObjectName("SearchLabel")
        search_label.setMinimumWidth(86)
        search_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        top_layout.addWidget(search_label)
        top_layout.addWidget(self.search_mode)
        top_layout.addWidget(self.search_edit, 1)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        top_layout.addWidget(self.status_label)
        layout.addWidget(top_card)
        layout.addWidget(self.tabs, 1)
        self.setCentralWidget(main)
        self.password_table.itemClicked.connect(self.show_clicked_password_detail)
        self.note_table.itemClicked.connect(self.show_clicked_note_detail)
        self.password_table.doubleClicked.connect(self.edit_password)
        self.note_table.doubleClicked.connect(self.edit_note)
        self.auto_lock_timer = QTimer(self)
        self.auto_lock_timer.setSingleShot(True)
        self.auto_lock_timer.setInterval(AUTO_LOCK_TIMEOUT_MS)
        self.auto_lock_timer.timeout.connect(self.handle_auto_lock)
        application = QApplication.instance()
        if application is not None:
            application.installEventFilter(self)
        self.auto_lock_timer.start()
        self.refresh_all()

    def eventFilter(self, watched, event):
        activity_events = {
            QEvent.Type.KeyPress,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonDblClick,
            QEvent.Type.Wheel,
            QEvent.Type.TouchBegin,
        }
        if (
            event.type() in activity_events
            and self.isVisible()
            and not self._lock_in_progress
        ):
            self.auto_lock_timer.start()
        return super().eventFilter(watched, event)

    def search_mode_changed(self, *_args):
        if self.search_mode.currentIndex() == 1:
            self.search_edit.setPlaceholderText("정규식 검색, 예: 계정|이메일")
        else:
            self.search_edit.setPlaceholderText(
                "최장 공통 부분 수열 검색(대소문자 구분 안 함), *는 와일드카드입니다. 예: 시작*끝"
            )
        self.apply_filter()

    def handle_auto_lock(self):
        active_modal = QApplication.activeModalWidget()
        if active_modal is not None:
            # 저장하지 않은 모달 편집 창 위에서 강제로 잠그지 않고 1분 뒤 다시 시도합니다.
            self.auto_lock_timer.start(60_000)
            return
        self.lock_and_exit(auto_locked=True)

    def enable_windows_screen_capture_protection(self):
        protect_widget_from_capture(self)
    def make_toolbar(self):
        toolbar = QToolBar("기본 도구 모음")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        save_action = QAction("저장", self)
        save_action.triggered.connect(self.force_save)
        toolbar.addAction(save_action)
        change_master_action = QAction("마스터 비밀번호 변경", self)
        change_master_action.triggered.connect(self.change_master_password)
        toolbar.addAction(change_master_action)
        lock_action = QAction("잠그고 종료", self)
        lock_action.triggered.connect(self.lock_and_exit)
        toolbar.addAction(lock_action)
        toolbar.addSeparator()
        info_action = QAction("정보", self)
        info_action.triggered.connect(self.show_database_info)
        toolbar.addAction(info_action)
        donate_action = QAction("후원", self)
        donate_action.triggered.connect(self.show_donation)
        toolbar.addAction(donate_action)
        security_action = QAction("보안", self)
        security_action.triggered.connect(self.show_security_notes)
        toolbar.addAction(security_action)
    def make_table(self, headers: List[str]) -> QTableWidget:
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.setAlternatingRowColors(True)
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        return table
    def make_password_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.password_splitter.addWidget(self.password_table)
        self.password_splitter.addWidget(self.password_detail)
        self.password_splitter.setSizes([1240, 0])
        layout.addWidget(self.password_splitter, 1)
        return page
    def make_note_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.note_splitter.addWidget(self.note_table)
        self.note_splitter.addWidget(self.note_detail)
        self.note_splitter.setSizes([1240, 0])
        layout.addWidget(self.note_splitter, 1)
        return page
    def make_crypto_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        title_label = QLabel("암호화폐 지갑 생성 및 저장")
        title_label.setObjectName("CardTitle")
        description_label = QLabel(
            "BIP39 24단어 니모닉과 BTC BIP84 주소 5개, 그리고 "
            "ETH BIP44 주소 5개를 첨부 규칙에 따라 생성합니다. 모든 주소 인덱스는 하드닝됩니다."
        )
        description_label.setObjectName("SubtleLabel")
        description_label.setWordWrap(True)

        warning_label = QLabel(
            "니모닉, seed, 개인 키는 모두 민감한 정보입니다. 저장을 누르면 현재 암호화 데이터베이스에 비밀번호 항목으로 기록됩니다. "
            "하드닝 주소 인덱스를 사용하므로 지갑을 복구할 때 결과에 기록된 경로를 정확히 사용해야 합니다."
        )
        warning_label.setWordWrap(True)

        self.crypto_generate_button = QPushButton("새 지갑 생성")
        self.crypto_generate_button.setObjectName("PrimaryButton")
        self.crypto_save_button = QPushButton("비밀번호 관리자에 저장")
        self.crypto_save_button.setObjectName("SecondaryButton")
        self.crypto_save_button.setEnabled(False)
        self.crypto_clear_button = QPushButton("결과 지우기")
        self.crypto_generate_button.clicked.connect(self.generate_crypto_wallet)
        self.crypto_save_button.clicked.connect(
            self.save_crypto_wallet_to_password_manager
        )
        self.crypto_clear_button.clicked.connect(self.clear_crypto_wallet_result)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        button_layout.addWidget(self.crypto_generate_button)
        button_layout.addWidget(self.crypto_save_button)
        button_layout.addWidget(self.crypto_clear_button)
        button_layout.addStretch(1)

        self.crypto_status_label = QLabel("아직 지갑을 생성하지 않았습니다.")
        self.crypto_status_label.setObjectName("SubtleLabel")
        button_layout.addWidget(self.crypto_status_label)

        self.crypto_output = QPlainTextEdit()
        self.crypto_output.setReadOnly(True)
        self.crypto_output.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.crypto_output.setPlaceholderText("생성 결과가 여기에 표시됩니다.")
        crypto_font = QFont("Consolas")
        crypto_font.setStyleHint(QFont.StyleHint.Monospace)
        self.crypto_output.setFont(crypto_font)

        layout.addWidget(title_label)
        layout.addWidget(description_label)
        layout.addWidget(warning_label)
        layout.addLayout(button_layout)
        layout.addWidget(self.crypto_output, 1)
        return page
    def run_vault_operation(
        self,
        error_title: str,
        operation: Callable[[], Any],
    ) -> bool:
        succeeded, _result = run_ui_operation(self, error_title, operation)
        if succeeded:
            self.refresh_all()
        return succeeded
    def generate_crypto_wallet(self, *_args):
        self.clear_crypto_wallet_result()
        succeeded, wallet_bundle = run_ui_operation(
            self,
            "생성 실패",
            lambda: run_with_progress(
                self,
                "암호화폐 지갑 생성 중",
                "니모닉, seed, BTC 키, ETH 키를 생성하고 있습니다. 잠시 기다려 주세요...",
                lambda: generate_crypto_wallet_bundle(CRYPTO_ADDRESS_COUNT),
            ),
        )
        if not succeeded:
            return

        self.crypto_wallet_result = wallet_bundle
        self.crypto_output.setPlainText(format_crypto_wallet_bundle(wallet_bundle))
        self.crypto_save_button.setEnabled(True)
        self.crypto_status_label.setText(
            f"생성 시간: {readable_time(wallet_bundle.get('generated_at', ''))}"
        )

    def save_crypto_wallet_to_password_manager(self, *_args):
        if not self.crypto_wallet_result:
            QMessageBox.information(self, "아직 생성 안 됨", "먼저 암호화폐 지갑을 생성하세요.")
            return
        # 니모닉은 비밀번호 필드에, 전체 파생 정보와 생성 시간은 메모 필드에 저장합니다.
        item = build_crypto_password_item(self.crypto_wallet_result)
        saved = self.run_vault_operation(
            "저장 실패",
            lambda: self.vault.upsert_item(item),
        )
        item.clear()
        if not saved:
            return
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText(
            self.crypto_status_label.text() + " · 비밀번호 관리자에 저장됨"
        )
        QMessageBox.information(
            self,
            "저장됨",
            "지갑을 비밀번호 관리자에 저장했습니다. 니모닉은 비밀번호 필드에 있고, 전체 정보와 생성 시간은 메모 필드에 있습니다.",
        )

    def clear_crypto_wallet_result(self, *_args):
        self.crypto_output.clear()
        if isinstance(self.crypto_wallet_result, dict):
            for value in self.crypto_wallet_result.values():
                if isinstance(value, list):
                    for entry in value:
                        if isinstance(entry, dict):
                            entry.clear()
                    value.clear()
            self.crypto_wallet_result.clear()
        self.crypto_wallet_result = None
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText("아직 지갑을 생성하지 않았습니다.")
    def setup_context_menus(self):
        self.password_table.customContextMenuRequested.connect(self.show_password_context_menu)
        self.note_table.customContextMenuRequested.connect(self.show_note_context_menu)
    def show_password_context_menu(self, position: QPoint):
        item = self.password_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("비밀번호 추가")
            action = menu.exec(self.password_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_password()
            return
        self.password_table.selectRow(item.row())
        add_action = menu.addAction("비밀번호 추가")
        edit_action = menu.addAction("편집")
        delete_action = menu.addAction("삭제")
        menu.addSeparator()
        copy_user_action = menu.addAction("사용자 이름 복사")
        copy_pass_action = menu.addAction("비밀번호 복사")
        action = menu.exec(self.password_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_password()
        elif action == edit_action:
            self.edit_password()
        elif action == delete_action:
            self.delete_password()
        elif action == copy_user_action:
            self.copy_username()
        elif action == copy_pass_action:
            self.copy_password()
    def show_note_context_menu(self, position: QPoint):
        item = self.note_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("메모 추가")
            action = menu.exec(self.note_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_note()
            return
        self.note_table.selectRow(item.row())
        add_action = menu.addAction("메모 추가")
        edit_action = menu.addAction("열기/편집")
        delete_action = menu.addAction("삭제")
        action = menu.exec(self.note_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_note()
        elif action == edit_action:
            self.edit_note()
        elif action == delete_action:
            self.delete_note()
    def refresh_all(self):
        self.password_items_all = sorted(
            self.vault.all_items("password"),
            key=self.password_sort_key,
        )
        self.note_items_all = sorted(
            self.vault.all_items("note"),
            key=self.note_sort_key,
        )
        self.apply_filter()
    def password_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        username_value = str(item.get("username", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, username_value, updated_value)
    def note_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, updated_value)
    def apply_filter(self, *_args):
        # 왼쪽 표의 축약 미리보기와 관계없이 전체 필드를 검색합니다.
        keyword = self.search_edit.text().strip()
        regex_mode = self.search_mode.currentIndex() == 1
        self.search_edit.setProperty("searchError", False)
        self.search_edit.style().unpolish(self.search_edit)
        self.search_edit.style().polish(self.search_edit)

        if not keyword:
            self.password_items_view = list(self.password_items_all)
            self.note_items_view = list(self.note_items_all)
        elif regex_mode:
            try:
                compiled_pattern = compile_search_regex(keyword)
            except ValueError as error:
                self.password_items_view = []
                self.note_items_view = []
                self.search_edit.setProperty("searchError", True)
                self.search_edit.style().unpolish(self.search_edit)
                self.search_edit.style().polish(self.search_edit)
                self.status_label.setText(str(error))
                self.refresh_password_table()
                self.refresh_note_table()
                self.hide_details()
                return

            def regex_matches(values: List[Any]) -> bool:
                searchable_text = "\n".join(
                    str(value or "") for value in values
                )[:MAX_SEARCH_TEXT_LENGTH]
                return compiled_pattern.search(searchable_text) is not None

            self.password_items_view = [
                item for item in self.password_items_all
                if regex_matches([
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if regex_matches(
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")]
                )
            ]
        else:
            self.password_items_view = [
                item for item in self.password_items_all
                if lcs_or_wildcard_item_match(keyword, [
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if lcs_or_wildcard_item_match(
                    keyword,
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")],
                )
            ]

        self.refresh_password_table()
        self.refresh_note_table()
        self.hide_details()
        mode_label = "정규식" if regex_mode else "LCS/와일드카드"
        self.status_label.setText(
            f"비밀번호 {len(self.password_items_view)}/{len(self.password_items_all)} · "
            f"메모 {len(self.note_items_view)}/{len(self.note_items_all)} · "
            f"{mode_label}검색 · 5분 후 자동 잠금"
        )
    def hide_details(self):
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter.setSizes([1240, 0])
        self.note_splitter.setSizes([1240, 0])
    def refresh_password_table(self):
        self.password_table.setRowCount(0)
        for item in self.password_items_view:
            row = self.password_table.rowCount()
            self.password_table.insertRow(row)
            # Qt가 긴 메모로 과도한 내용 너비를 계산하지 않도록 표 텍스트를 제한합니다.
            values = [
                table_text_preview(item.get("title", ""), 80),
                table_text_preview(item.get("username", ""), 80),
                table_text_preview(item.get("notes", "")),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.password_table.setItem(row, column, cell)
    def refresh_note_table(self):
        self.note_table.setRowCount(0)
        for item in self.note_items_view:
            row = self.note_table.rowCount()
            self.note_table.insertRow(row)
            values = [
                item.get("title", ""),
                str(len(item.get("comments", []))),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.note_table.setItem(row, column, cell)
    def selected_password(self) -> Optional[Dict[str, Any]]:
        row = self.password_table.currentRow()
        if row < 0 or row >= len(self.password_items_view):
            return None
        return self.password_items_view[row]
    def selected_note(self) -> Optional[Dict[str, Any]]:
        row = self.note_table.currentRow()
        if row < 0 or row >= len(self.note_items_view):
            return None
        return self.note_items_view[row]
    def show_clicked_password_detail(self, *_args):
        item = self.selected_password()
        if item:
            detail_was_hidden = self.password_detail.isHidden()
            self.password_detail.show_password_item(item)
            self.password_detail.show()
            # 처음 열 때만 기본 비율을 설정하고 이후에는 사용자가 옮긴 위치를 유지합니다.
            if detail_was_hidden:
                self.reveal_detail_panel(self.password_splitter)
    def show_clicked_note_detail(self, *_args):
        item = self.selected_note()
        if item:
            detail_was_hidden = self.note_detail.isHidden()
            self.note_detail.show_note_item(item)
            self.note_detail.show()
            if detail_was_hidden:
                self.reveal_detail_panel(self.note_splitter)
    @staticmethod
    def reveal_detail_panel(splitter: QSplitter) -> None:
        current_sizes = splitter.sizes()
        total_width = max(sum(current_sizes), splitter.width(), 800)
        detail_width = min(360, max(260, total_width // 3))
        splitter.setSizes([total_width - detail_width, detail_width])
    def require_password_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_password()
        if item is None:
            QMessageBox.information(self, "항목 선택", "먼저 비밀번호 항목을 선택하세요.")
        return item
    def require_note_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_note()
        if item is None:
            QMessageBox.information(self, "항목 선택", "먼저 메모를 선택하세요.")
        return item
    def add_password(self):
        item = PasswordDialog(parent=self).get_item()
        if item:
            self.run_vault_operation(
                "저장 실패",
                lambda: self.vault.upsert_item(item),
            )
    def edit_password(self, *_args):
        item = self.require_password_selection()
        if not item:
            return
        updated = PasswordDialog(item=item, parent=self).get_item()
        if updated:
            self.run_vault_operation(
                "저장 실패",
                lambda: self.vault.upsert_item(updated),
            )
    def delete_password(self):
        item = self.require_password_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "삭제 확인", f"삭제: “{item.get('title', '')}”?")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "삭제 실패",
                lambda: self.vault.delete_item(item["id"]),
            )
    def copy_username(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("username", ""), "사용자 이름을 복사했습니다.")
    def copy_password(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("password", ""), "비밀번호를 복사했습니다. 30초 후 클립보드를 자동으로 비웁니다.", auto_clear=True)
    def copy_to_clipboard(self, text: str, message: str, auto_clear: bool = False):
        QApplication.clipboard().setText(text)
        expected_digest = hashlib.sha256(text.encode("utf-8")).digest()
        self.managed_clipboard_digest = expected_digest
        QMessageBox.information(self, "복사됨", message)
        if auto_clear:
            # 타이머 클로저에는 평문 비밀번호가 아닌 요약값만 보관합니다.
            def clear_clipboard(digest=expected_digest):
                current_text = QApplication.clipboard().text()
                current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
                if secrets.compare_digest(current_digest, digest):
                    QApplication.clipboard().clear()
                    if self.managed_clipboard_digest == digest:
                        self.managed_clipboard_digest = None
                current_text = ""
            QTimer.singleShot(30_000, clear_clipboard)

    def clear_managed_clipboard(self):
        digest = self.managed_clipboard_digest
        if digest is None:
            return
        current_text = QApplication.clipboard().text()
        current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
        if secrets.compare_digest(current_digest, digest):
            QApplication.clipboard().clear()
        current_text = ""
        self.managed_clipboard_digest = None

    def save_note_from_dialog(self, item: Dict[str, Any]):
        self.vault.upsert_item(item)
        self.refresh_all()

    def add_note(self):
        NoteDialog(
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()

    def edit_note(self, *_args):
        item = self.require_note_selection()
        if not item:
            return
        NoteDialog(
            item=item,
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()
    def delete_note(self):
        item = self.require_note_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "삭제 확인", f"삭제: “{item.get('title', '')}”?")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "삭제 실패",
                lambda: self.vault.delete_item(item["id"]),
            )
    def force_save(self):
        if self.run_vault_operation("저장 실패", self.vault.save):
            QMessageBox.information(self, "저장됨", "데이터베이스를 저장했습니다.")
    def change_master_password(self):
        new_password = MasterPasswordDialog(parent=self).get_password()
        if new_password:
            succeeded, _result = run_ui_operation(
                self,
                "변경 실패",
                lambda: run_with_progress(
                    self,
                    "마스터 비밀번호 변경 중",
                    "새 키를 파생하고 데이터베이스를 암호화하고 있습니다. 잠시 기다려 주세요...",
                    lambda: self.vault.change_master_password(new_password),
                ),
            )
            new_password = ""
            if succeeded:
                QMessageBox.information(self, "변경됨", "마스터 비밀번호를 변경했으며 데이터베이스를 새 키로 다시 암호화하여 저장했습니다.")
    def clear_sensitive_ui(self):
        self.clear_crypto_wallet_result()
        self.password_items_all.clear()
        self.password_items_view.clear()
        self.note_items_all.clear()
        self.note_items_view.clear()
        self.password_table.clearContents()
        self.password_table.setRowCount(0)
        self.note_table.clearContents()
        self.note_table.setRowCount(0)
        self.password_detail.show_password_item(None)
        self.note_detail.show_note_item(None)
        self.password_detail.hide()
        self.note_detail.hide()
        self.search_edit.clear()
        self.clear_managed_clipboard()
    def closeEvent(self, event):
        try:
            self.auto_lock_timer.stop()
            application = QApplication.instance()
            if application is not None:
                application.removeEventFilter(self)
            self.clear_sensitive_ui()
            self.vault.lock()
        finally:
            super().closeEvent(event)
    def lock_and_exit(self, auto_locked: bool = False):
        if self._lock_in_progress:
            return
        self._lock_in_progress = True
        self.auto_lock_timer.stop()
        try:
            self.clear_sensitive_ui()
            self.vault.lock()
            self.hide()
            reopened_vault = bootstrap_vault(parent=None)
            if reopened_vault is None:
                self.close()
                return
            self.vault = reopened_vault
            self.setWindowTitle(f"{APP_NAME} - {self.vault.path}")
            self.refresh_all()
            if auto_locked:
                self.status_label.setText(
                    self.status_label.text() + " · 자동 잠금 재인증 완료"
                )
            self.show()
            self.enable_windows_screen_capture_protection()
            self.auto_lock_timer.start()
        finally:
            self._lock_in_progress = False
    def show_database_info(self):
        message = (
            f"프로그램: {APP_NAME} {APP_VERSION}\n"
            f"파일: {self.vault.path}\n"
            f"알고리즘: Argon2id + ChaCha20-Poly1305\n"
            f"Argon2id:iterations={self.vault.kdf_params.get('iterations')},lanes={self.vault.kdf_params.get('lanes')},memory={self.vault.kdf_params.get('memory_cost')} KiB\n"
            f"자동 잠금: 5분 동안 작업이 없을 때\n"
            f"비밀번호 항목: {len(self.password_items_all)}\n"
            f"보안 메모: {len(self.note_items_all)}"
        )
        QMessageBox.information(self, "데이터베이스 정보", message)
    def show_donation(self):
        message = (
            f"이 프로젝트가 도움이 되었다면 개발자를 후원할 수 있습니다.\n\n"
            f"Bitcoin:{DONATION_BTC}\n"
            f"Ethereum:{DONATION_ETH}\n"
            f"BNB Smart Chain:{DONATION_BNB}"
        )
        QMessageBox.information(self, "개발자 후원", message)
    def show_security_notes(self):
        message = (
            "CipherNote Vault는 Argon2id로 마스터 비밀번호에서 256-bit 키를 파생하고 ChaCha20-Poly1305로 전체 데이터베이스를 인증 암호화합니다.\n\n"
            "비밀번호 항목과 보안 메모는 하나의 암호화 payload에 있으며, 디스크의 데이터베이스 파일에는 salt, nonce, KDF 매개변수, 암호문만 저장됩니다.\n\n"
            "저장할 때 별도의 임시 파일, 파일 동기화, 원자적 교체를 사용합니다. 다른 인스턴스가 데이터베이스를 수정한 것이 감지되면 덮어쓰지 않도록 저장을 취소합니다.\n\n"
            "5분 동안 작업이 없으면 자동으로 잠깁니다. 처리하지 않은 모달 편집 창이 열려 있으면 잠금을 미루고 다시 시도합니다.\n\n"
            "Windows에서는 일반 스크린샷 및 화면 녹화 캡처를 막기 위해 기본 창과 민감한 대화 상자에서 SetWindowDisplayAffinity 활성화를 시도합니다.\n\n"
            "가져온 외부 텍스트는 저장이 성공한 뒤에만 암호화 데이터베이스에 들어갑니다.\n\n"
            "보안 경계: 이 프로그램은 이미 컴퓨터를 장악한 악성 코드, 휴대전화 촬영, 관리자 권한 스크린샷, 키 입력 기록, 클립보드 감시, 메모리 덤프를 방어할 수 없습니다. 시스템 디스크 암호화를 함께 사용하는 것이 좋습니다."
        )
        QMessageBox.information(self, "보안 안내", message)
#------ 앱 스타일 및 시작 ------
def set_app_style(application: QApplication):
    application.setStyleSheet("""
        QWidget {
            font-family: "Malgun Gothic", "Noto Sans CJK KR", "Segoe UI", sans-serif;
            font-size: 16px;
            color: #FFF700;
            background-color: #8A1F00;
        }
        Q기본 도구 모음Window, QDialog {
            background-color: #8A1F00;
        }
        QLineEdit, QPlainTextEdit, QTableWidget {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 10px;
            padding: 9px;
            selection-background-color: #FFD700;
            selection-color: #FF0000;
        }
        QLineEdit#기본 도구 모음SearchInput {
            padding: 2px 8px;
            border-radius: 6px;
        }
        QLineEdit[searchError="true"] { border: 2px solid #FF0000; }
        QPlainTextEdit { line-height: 1.5em; }
        QTableWidget {
            gridline-color: #9A3400;
            alternate-background-color: #7C1D00;
            border-radius: 12px;
        }
        QTableWidget::item { padding: 8px; }
        QTableWidget::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QSplitter::handle:horizontal {
            background-color: #C86F00;
            margin: 3px 2px;
            border-radius: 3px;
        }
        QSplitter::handle:horizontal:hover,
        QSplitter::handle:horizontal:pressed {
            background-color: #FFD700;
        }
        QHeaderView::section {
            background-color: #5F1700;
            color: #FDE600;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #C86F00;
            font-weight: 700;
        }
        QRadioButton#ModeRadio:checked {
            background-color: rgb(0, 200, 0);
        }
        QPushButton {
            background-color: #E9C400;
            color: #4A1200;
            border: 1px solid #F6D900;
            border-radius: 10px;
            padding: 9px 14px;
            font-weight: 800;
        }
        QPushButton:hover { background-color: #F3D500; }
        QPushButton:pressed { background-color: #D9A400; }
        QPushButton:disabled {
            background-color: #9CA300;
            color: #5F1700;
        }
        QPushButton#PrimaryButton {
            background-color: #F1C900;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton {
            background-color: #D89C00;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton:hover { background-color: #E8B900; }
        QTabWidget::pane {
            border: 1px solid #C86F00;
            border-radius: 12px;
            top: -1px;
            background-color: #8A1F00;
        }
        QTabBar::tab {
            background-color: #6F1A00;
            color: #FDE600;
            padding: 7px 14px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-right: 1px;
            font-weight: 700;
        }
        QTabBar::tab:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QToolBar {
            background-color: #5A1500;
            border: none;
            spacing: 6px;
            padding: 6px;
        }
        QToolButton {
            color: #FDE600;
            background-color: #6F1A00;
            border-radius: 8px;
            padding: 7px 9px;
        }
        QToolButton:hover { background-color: #9A3400; }
        QMenu {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #E9C400;
            padding: 6px;
        }
        QMenu::item {
            padding: 8px 28px;
            border-radius: 6px;
        }
        QMenu::item:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QSlider::groove:horizontal {
            height: 6px;
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 3px;
        }
        QSlider::handle:horizontal {
            width: 16px;
            margin: -6px 0;
            border-radius: 8px;
            background-color: #E9C400;
            border: 1px solid #F6D900;
        }
        QSlider::sub-page:horizontal {
            background-color: #E9C400;
            border-radius: 3px;
        }
        QSpinBox, QCheckBox {
            color: #FFF700;
            background-color: #6F1A00;
        }
        QLabel#DialogTitle {
            font-size: 30px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#CardTitle {
            font-size: 22px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#SectionTitle {
            font-size: 18px;
            font-weight: 800;
            color: #FFF700;
        }
        QLabel#SubtleLabel { color: #FDE600; }
        QPlainTextEdit#BodyLabel {
            color: #FFF700;
            background-color: #6F1A00;
            border: none;
            border-radius: 10px;
            padding: 12px;
        }
        QLabel#SearchLabel {
            font-weight: 800;
            color: #FDE600;
        }
        QFrame#Card {
            background-color: #6F1A00;
            border: 1px solid #C86F00;
            border-radius: 16px;
            padding: 12px;
        }
        QFrame#TopCard {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 14px;
            padding: 8px;
        }
        QFrame#InlineSearch {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 10px;
        }
        QFrame#CommentsPanel {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 12px;
        }
        QListWidget#CommentList {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 8px;
            padding: 4px;
        }
        QListWidget#CommentList::item {
            padding: 8px;
            border-bottom: 1px solid #9A3400;
        }
        QListWidget#CommentList::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QMessageBox QLabel { color: #FFF700; }
    """)
def bootstrap_vault(parent=None) -> Optional[Vault]:
    for _ in range(3):
        dialog = StartupDialog(parent=parent)
        result = dialog.get_result()
        if result is None:
            return None
        vault = Vault(result["path"])
        master_password = result.pop("password")
        try:
            if result["mode"] == "create":
                operation = lambda: run_with_progress(
                    parent,
                    "데이터베이스 만드는 중",
                    "암호화 키를 파생하고 데이터베이스를 만들고 있습니다. 잠시 기다려 주세요...",
                    lambda: vault.create(master_password),
                )
            else:
                operation = lambda: run_with_progress(
                    parent,
                    "데이터베이스 여는 중",
                    "마스터 비밀번호를 확인하고 데이터베이스를 복호화하고 있습니다. 잠시 기다려 주세요...",
                    lambda: vault.unlock(master_password),
                )
            succeeded, _result = run_ui_operation(
                parent,
                "데이터베이스 열기 실패",
                operation,
            )
        finally:
            master_password = ""
            result.clear()
        if succeeded:
            return vault
    return None
def main():
    application = QApplication(sys.argv)
    application.setApplicationName(APP_NAME)
    set_app_style(application)
    vault = bootstrap_vault()
    if vault is None:
        return 1
    window = MainWindow(vault)
    window.show()
    window.enable_windows_screen_capture_protection()
    return application.exec()
if __name__ == "__main__":
    raise SystemExit(main())
