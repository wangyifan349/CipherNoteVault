"""CipherNote Vault 是一个本地运行的加密密码管理器与安全记事本，使用 Argon2id 派生密钥并通过 ChaCha20-Poly1305 对数据库内容进行认证加密，数据默认仅保存在用户选择的本地数据库文件中。"""
# SPDX-License-Identifier: GPL-3.0-only
# CipherNote Vault
# Copyright (C) 2026 Wang Yifan
#
# 本程序是自由软件；您可以重新发布和/或修改本程序，但须遵守
# 自由软件基金会发布的 GNU 通用公共许可证；
# 适用该许可证的第 3 版。
import base64
import copy
import ctypes
import hashlib
import json
import os
import platform
import re
import secrets
import string
import sys
import uuid
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Pattern, Tuple
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from bip_utils import (
    Bip32Secp256k1,
    Bip39MnemonicGenerator,
    Bip39SeedGenerator,
    Bip39WordsNum,
    EthAddrEncoder,
    P2WPKHAddrEncoder,
    WifEncoder,
)
try:
    from charset_normalizer import from_bytes
except ImportError:  # 文本导入功能会给出明确提示，其余功能仍可使用。
    from_bytes = None
from PyQt6.QtCore import QEvent, QPoint, QThread, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QKeySequence, QShortcut, QTextCursor, QTextOption
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QRadioButton,
    QPushButton,
    QPlainTextEdit,
    QProgressDialog,
    QSplitter,
    QSlider,
    QSizePolicy,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)
#------ 程序配置 ------
APP_NAME = "CipherNote Vault"
APP_VERSION = "1.0.0"
VAULT_FORMAT = "CipherNote Vault Database"
VAULT_VERSION = 1
DEFAULT_VAULT_DIR = Path.home() / ".ciphernote_vault"
DEFAULT_VAULT = DEFAULT_VAULT_DIR / "vault.cnvault"
ARGON2ID_PARAMS = {
    "name": "Argon2id",
    "length": 32,
    "iterations": 3,
    "lanes": 4,
    "memory_cost": 64 * 1024,
}
# 不可信的数据库元数据不得触发无限制的工作量。
MAX_VAULT_FILE_SIZE = 256 * 1024 * 1024
MAX_ARGON2_ITERATIONS = 8
MAX_ARGON2_LANES = 16
MAX_ARGON2_MEMORY_KIB = 512 * 1024
MIN_SALT_LENGTH = 16
MAX_SALT_LENGTH = 64
CHACHA20_POLY1305_NONCE_LENGTH = 12
POLY1305_TAG_LENGTH = 16
DEFAULT_GENERATED_PASSWORD_LENGTH = 32
MAX_GENERATED_PASSWORD_LENGTH = 4096
PASSWORD_SYMBOLS = "!@#$%^&*()-_=+[]{}:,.?"
CRYPTO_ADDRESS_COUNT = 5
CRYPTO_BIP39_PASSPHRASE = ""
AUTO_LOCK_TIMEOUT_MS = 5 * 60 * 1000
MAX_SEARCH_TEXT_LENGTH = 200_000
MAX_REGEX_PATTERN_LENGTH = 256
MAX_TEXT_IMPORT_SIZE = 16 * 1024 * 1024
MAX_ITEM_COUNT = 100_000
MAX_COMMENT_COUNT = 10_000
MAX_TEXT_FIELD_LENGTH = 32 * 1024 * 1024
DONATION_BTC = "bc1qxqfhumpqtnxrznkx9r4xsp8m6zsedtgusjns7p"
DONATION_ETH = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
DONATION_BNB = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
WINDOWS_DISPLAY_AFFINITY_NONE = 0x00000000
WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE = 0x00000011
WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY = 0x00000001
#------ 通用工具 ------
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
def readable_time(value: str) -> str:
    if not value:
        return ""
    return value.replace("T", " ").replace("+00:00", " UTC")

def table_text_preview(value: Any, maximum_length: int = 120) -> str:
    # 表格只保留短预览；完整内容仍用于搜索和右侧详情。
    preview = " ".join(str(value or "").split())
    if len(preview) <= maximum_length:
        return preview
    return preview[: maximum_length - 1].rstrip() + "…"

def remove_extra_blank_lines(text: str) -> str:
    """统一换行、移除行尾空白，并把连续空行压缩为一行。"""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned_lines: List[str] = []
    previous_was_blank = True
    for raw_line in normalized.split("\n"):
        line = raw_line.rstrip()
        is_blank = not line.strip()
        if is_blank:
            if cleaned_lines and not previous_was_blank:
                cleaned_lines.append("")
        else:
            cleaned_lines.append(line)
        previous_was_blank = is_blank
    while cleaned_lines and cleaned_lines[-1] == "":
        cleaned_lines.pop()
    return "\n".join(cleaned_lines)

def python_index_to_qt_position(text: str, index: int) -> int:
    """把 Python Unicode 索引换算为 QTextCursor 使用的 UTF-16 位置。"""
    safe_index = min(max(index, 0), len(text))
    return len(text[:safe_index].encode("utf-16-le")) // 2

def qt_position_to_python_index(text: str, position: int) -> int:
    safe_position = max(position, 0) * 2
    prefix = text.encode("utf-16-le")[:safe_position]
    return len(prefix.decode("utf-16-le", errors="ignore"))

def text_readability_score(text: str) -> float:
    common_cjk = set(
        "的一是不了人我在有他这為为之大来來以个個中上們们到說说國国和地也子時时道出"
        "而要於于就下得可你年生自會会那後后能對对著着事其裡里所去行過过家十用發发"
        "天如然作方成者多日都三小二無无同經经法當当起與与好看學学進进種种將将還还"
        "分此心前面又定見见只主沒没公從从明問问力間间意外正把情最重文本測测试試"
        "中文筆笔記记密碼密码帳账号號導导入編编码碼安全保存搜索搜尋日本語"
    )
    score = 0.0
    for character in text:
        codepoint = ord(character)
        if character == "\ufffd" or (codepoint < 32 and character not in "\n\r\t"):
            score -= 12.0
        elif character in common_cjk:
            score += 2.0
        elif 0x3040 <= codepoint <= 0x30FF:
            score += 2.0
        elif 0x4E00 <= codepoint <= 0x9FFF:
            score += 0.15
        elif 0xFF61 <= codepoint <= 0xFF9F:
            score -= 0.8
        elif character.isprintable():
            score += 0.05
    return score

def decode_imported_text(data: bytes) -> Tuple[str, str, float]:
    """使用 charset_normalizer.from_bytes 自动识别外部文本编码。"""
    if not data:
        return "", "utf-8", 100.0
    if from_bytes is None:
        raise RuntimeError("缺少 charset-normalizer，请先运行：pip install charset-normalizer")
    matches = from_bytes(data)
    best_match = matches.best()
    if best_match is None:
        raise ValueError("无法识别该文本文件的编码。")
    encoding = best_match.encoding or "unknown"
    coherence = float(getattr(best_match, "percent_coherence", 0.0) or 0.0)
    best_text = str(best_match)
    if coherence >= 10.0:
        return best_text, encoding, coherence

    # 很短的中日韩文本常有多种合法解码。仍以 from_bytes 为入口，
    # 在低可信度时比较少量常见候选，避免把简短 GB18030 中文误判为 Big5。
    candidates = {encoding: best_text}
    for candidate_encoding in ("utf-8-sig", "gb18030", "big5", "shift_jis"):
        with suppress(UnicodeDecodeError, LookupError):
            candidates[candidate_encoding] = data.decode(candidate_encoding)
    selected_encoding, selected_text = max(
        candidates.items(),
        key=lambda pair: (
            text_readability_score(pair[1]),
            pair[0] == encoding,
        ),
    )
    return selected_text, selected_encoding, coherence

def read_imported_text_file(path: Path) -> Tuple[str, str, float]:
    if path.stat().st_size > MAX_TEXT_IMPORT_SIZE:
        raise ValueError(
            f"文本文件不能超过 {MAX_TEXT_IMPORT_SIZE // (1024 * 1024)} MiB。"
        )
    return decode_imported_text(path.read_bytes())

def longest_common_subsequence_score(first_text: str, second_text: Any) -> int:
    """使用位并行算法计算不区分大小写的最长公共子序列长度。"""
    first = str(first_text or "").casefold()
    second = str(second_text or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    if not first or not second:
        return 0
    character_masks: Dict[str, int] = {}
    for index, character in enumerate(first):
        character_masks[character] = (
            character_masks.get(character, 0) | (1 << index)
        )
    lcs_row = 0
    for character in second:
        matches = character_masks.get(character, 0)
        combined = matches | lcs_row
        lcs_row = combined & ~(combined - ((lcs_row << 1) | 1))
    return lcs_row.bit_count()

def longest_common_subsequence_match(keyword: str, text_value: Any) -> bool:
    """keyword 的全部字符均进入 LCS 时视为匹配。"""
    folded_keyword = str(keyword or "").casefold()
    if not folded_keyword:
        return True
    return (
        longest_common_subsequence_score(folded_keyword, text_value)
        == len(folded_keyword)
    )

def wildcard_search_match(pattern: str, text_value: Any) -> bool:
    """星号代表任意长度内容；各文字片段必须按输入顺序出现。"""
    folded_pattern = str(pattern or "").casefold()
    text = str(text_value or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    fragments = [fragment for fragment in folded_pattern.split("*") if fragment]
    if not fragments:
        return True
    search_position = 0
    for fragment in fragments:
        fragment_position = text.find(fragment, search_position)
        if fragment_position < 0:
            return False
        search_position = fragment_position + len(fragment)
    return True

def lcs_or_wildcard_item_match(keyword: str, values: List[Any]) -> bool:
    searchable_text = "\n".join(str(value or "") for value in values)
    if "*" in keyword:
        return wildcard_search_match(keyword, searchable_text)
    return longest_common_subsequence_match(keyword, searchable_text)

def compile_search_regex(pattern_text: str) -> Pattern[str]:
    if len(pattern_text) > MAX_REGEX_PATTERN_LENGTH:
        raise ValueError(f"正则表达式不能超过 {MAX_REGEX_PATTERN_LENGTH} 个字符。")
    try:
        return re.compile(pattern_text, re.IGNORECASE | re.UNICODE)
    except re.error as error:
        raise ValueError(f"正则表达式无效：{error}") from error

def protect_widget_from_capture(widget: QWidget) -> None:
    if platform.system() != "Windows":
        return
    with suppress(Exception):
        window_handle = int(widget.winId())
        result = ctypes.windll.user32.SetWindowDisplayAffinity(
            window_handle,
            WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE,
        )
        if result == 0:
            ctypes.windll.user32.SetWindowDisplayAffinity(
                window_handle,
                WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY,
            )

def generate_secure_password(length: int, include_lowercase: bool = True, include_uppercase: bool = True, include_digits: bool = True, include_symbols: bool = True) -> str:
    if length < 1:
        raise ValueError("密码长度必须大于 0。")
    character_groups = []
    if include_lowercase:
        character_groups.append(string.ascii_lowercase)
    if include_uppercase:
        character_groups.append(string.ascii_uppercase)
    if include_digits:
        character_groups.append(string.digits)
    if include_symbols:
        character_groups.append(PASSWORD_SYMBOLS)
    if not character_groups:
        raise ValueError("至少选择一种字符类型。")
    character_pool = "".join(character_groups)
    if length < len(character_groups):
        raise ValueError(f"密码长度不能小于已选择的字符类型数量（{len(character_groups)}）。")
    password_characters = [secrets.choice(character_group) for character_group in character_groups]
    password_characters.extend(secrets.choice(character_pool) for _ in range(length - len(password_characters)))
    secrets.SystemRandom().shuffle(password_characters)
    return "".join(password_characters)

def generate_crypto_wallet_bundle(
    address_count: int = CRYPTO_ADDRESS_COUNT,
) -> Dict[str, Any]:
    if address_count < 1:
        raise ValueError("地址数量必须大于 0。")

    mnemonic_object = Bip39MnemonicGenerator().FromWordsNumber(
        Bip39WordsNum.WORDS_NUM_24
    )
    mnemonic = str(mnemonic_object)
    seed = Bip39SeedGenerator(mnemonic_object).Generate(CRYPTO_BIP39_PASSPHRASE)
    root = Bip32Secp256k1.FromSeed(seed)
    bitcoin_wallets: List[Dict[str, Any]] = []
    ethereum_wallets: List[Dict[str, Any]] = []

    # BTC 使用 BIP84 风格路径，地址索引也按要求硬化。
    for index in range(address_count):
        path = f"m/84'/0'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        private_key_bytes = private_key.Raw().ToBytes()
        bitcoin_wallets.append({
            "index": index,
            "path": path,
            "address": P2WPKHAddrEncoder.EncodeKey(
                public_key.RawCompressed().ToBytes(),
                hrp="bc",
            ),
            "private_key_decimal": int.from_bytes(private_key_bytes, "big"),
            "private_key_wif": WifEncoder.Encode(private_key_bytes),
            "public_key": public_key.RawCompressed().ToHex(),
        })

    # ETH 使用 BIP44 风格路径，地址索引同样硬化。
    for index in range(address_count):
        path = f"m/44'/60'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        ethereum_wallets.append({
            "index": index,
            "path": path,
            "address": EthAddrEncoder.EncodeKey(
                public_key.RawUncompressed().ToBytes()
            ),
            "private_key_decimal": int.from_bytes(
                private_key.Raw().ToBytes(),
                "big",
            ),
            "public_key": "0x" + public_key.RawUncompressed().ToHex(),
        })

    return {
        "generated_at": now_iso(),
        "mnemonic": mnemonic,
        "seed_hex": seed.hex(),
        "bitcoin": bitcoin_wallets,
        "ethereum": ethereum_wallets,
    }

def format_crypto_wallet_bundle(wallet_bundle: Dict[str, Any]) -> str:
    generated_at = readable_time(str(wallet_bundle.get("generated_at", "")))
    lines = [
        "=" * 80,
        "BIP39 24词助记词",
        "=" * 80,
        f"生成时间        : {generated_at}",
        f"助记词 MNEMONIC : {wallet_bundle.get('mnemonic', '')}",
        f"SEED HEX        : {wallet_bundle.get('seed_hex', '')}",
        "BIP39 附加口令  : 未设置",
        "恢复提示        : 必须使用下方完全相同的硬化派生路径",
        "",
        "=" * 80,
        "BITCOIN - BIP84风格，地址索引硬化",
        "=" * 80,
    ]
    for wallet in wallet_bundle.get("bitcoin", []):
        lines.extend([
            "",
            f"BTC #{wallet.get('index', '')}",
            f"派生路径        : {wallet.get('path', '')}",
            f"地址            : {wallet.get('address', '')}",
            f"私钥（十进制）  : {wallet.get('private_key_decimal', '')}",
            f"私钥（WIF）     : {wallet.get('private_key_wif', '')}",
            f"公钥            : {wallet.get('public_key', '')}",
        ])
    lines.extend([
        "",
        "=" * 80,
        "ETHEREUM - BIP44风格，地址索引硬化",
        "=" * 80,
    ])
    for wallet in wallet_bundle.get("ethereum", []):
        lines.extend([
            "",
            f"ETH #{wallet.get('index', '')}",
            f"派生路径        : {wallet.get('path', '')}",
            f"地址            : {wallet.get('address', '')}",
            f"私钥（十进制）  : {wallet.get('private_key_decimal', '')}",
            f"公钥            : {wallet.get('public_key', '')}",
        ])
    return "\n".join(lines)

def build_crypto_password_item(wallet_bundle: Dict[str, Any]) -> Dict[str, Any]:
    generated_at = str(wallet_bundle.get("generated_at") or now_iso())
    bitcoin_wallets = wallet_bundle.get("bitcoin", [])
    ethereum_wallets = wallet_bundle.get("ethereum", [])
    first_bitcoin_address = (
        str(bitcoin_wallets[0].get("address", "")) if bitcoin_wallets else ""
    )
    first_ethereum_address = (
        str(ethereum_wallets[0].get("address", "")) if ethereum_wallets else ""
    )
    return {
        "id": str(uuid.uuid4()),
        "type": "password",
        "title": f"加密货币钱包 {readable_time(generated_at)}",
        "username": (
            f"BTC {first_bitcoin_address} | ETH {first_ethereum_address}"
        ),
        "password": str(wallet_bundle.get("mnemonic", "")),
        "notes": format_crypto_wallet_bundle(wallet_bundle),
        "created_at": generated_at,
        "updated_at": generated_at,
    }
#------ 加密与数据库文件 ------
def encode_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")
def decode_base64(data: str) -> bytes:
    if not isinstance(data, str):
        raise ValueError("Base64 字段必须是字符串。")
    try:
        return base64.b64decode(data.encode("ascii"), validate=True)
    except ValueError as error:
        raise ValueError("Base64 数据无效。") from error
def secure_wipe(buffer: Optional[bytearray]) -> None:
    # 仅尽力清除：Python 无法保证抹除解释器中的每一份副本。
    if buffer is None:
        return
    for index in range(len(buffer)):
        buffer[index] = 0
def validate_kdf(kdf_params: Any) -> Dict[str, Any]:
    if not isinstance(kdf_params, dict) or kdf_params.get("name") != "Argon2id":
        raise VaultError("数据库 KDF 参数无效。")
    required = ("length", "iterations", "lanes", "memory_cost")
    for parameter_name in required:
        parameter_value = kdf_params.get(parameter_name)
        if isinstance(parameter_value, bool) or not isinstance(parameter_value, int):
            raise VaultError(f"数据库 KDF 参数 {parameter_name} 无效。")
    length = kdf_params["length"]
    iterations = kdf_params["iterations"]
    lanes = kdf_params["lanes"]
    memory_cost = kdf_params["memory_cost"]
    if length != 32:
        raise VaultError("数据库 KDF 输出长度无效。")
    if not 1 <= iterations <= MAX_ARGON2_ITERATIONS:
        raise VaultError("数据库 Argon2id iterations 超出允许范围。")
    if not 1 <= lanes <= MAX_ARGON2_LANES:
        raise VaultError("数据库 Argon2id lanes 超出允许范围。")
    if memory_cost < 8 * lanes or memory_cost > MAX_ARGON2_MEMORY_KIB:
        raise VaultError("数据库 Argon2id memory_cost 超出允许范围。")
    return dict(kdf_params)
def build_associated_data(kdf_params: Dict[str, Any], salt_base64: str) -> bytes:
    metadata = {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
    }
    return json.dumps(metadata, ensure_ascii=False, sort_keys=True).encode("utf-8")
def derive_key(master_password: str, salt: bytes, kdf_params: Dict[str, Any]) -> bytes:
    if not master_password:
        raise ValueError("主密码不能为空。")
    if kdf_params.get("name") != "Argon2id":
        raise ValueError("不支持的密钥派生算法。")
    return Argon2id(
        salt=salt,
        length=kdf_params["length"],
        iterations=kdf_params["iterations"],
        lanes=kdf_params["lanes"],
        memory_cost=kdf_params["memory_cost"],
        ad=None,
        secret=None,
    ).derive(master_password.encode("utf-8"))
def decode_vault_envelope(vault_envelope: Any):
    if not isinstance(vault_envelope, dict):
        raise VaultError("数据库文件格式无效。")
    if vault_envelope.get("format") != VAULT_FORMAT:
        raise VaultError("这不是 CipherNote Vault 数据库文件。")
    if vault_envelope.get("version") != VAULT_VERSION:
        raise VaultError("数据库版本不支持。")
    if vault_envelope.get("cipher") != "ChaCha20-Poly1305":
        raise VaultError("加密算法不支持。")
    kdf_params = validate_kdf(vault_envelope.get("kdf"))
    try:
        salt_base64 = vault_envelope["salt"]
        salt = decode_base64(salt_base64)
        nonce = decode_base64(vault_envelope["nonce"])
        ciphertext = decode_base64(vault_envelope["ciphertext"])
    except (KeyError, TypeError, ValueError) as error:
        raise VaultError("数据库文件损坏或格式不正确。") from error
    if not MIN_SALT_LENGTH <= len(salt) <= MAX_SALT_LENGTH:
        raise VaultError("数据库 salt 长度无效。")
    if len(nonce) != CHACHA20_POLY1305_NONCE_LENGTH:
        raise VaultError("数据库 nonce 长度无效。")
    if len(ciphertext) < POLY1305_TAG_LENGTH:
        raise VaultError("数据库密文长度无效。")
    return kdf_params, salt_base64, salt, nonce, ciphertext
def encrypt_payload(payload: Dict[str, Any], key: bytearray, salt: bytes, kdf_params: Dict[str, Any]) -> Dict[str, Any]:
    plaintext_json = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    plaintext_buffer = bytearray(plaintext_json.encode("utf-8"))
    plaintext_json = ""
    try:
        nonce = os.urandom(CHACHA20_POLY1305_NONCE_LENGTH)
        salt_base64 = encode_base64(salt)
        associated_data = build_associated_data(kdf_params, salt_base64)
        ciphertext = ChaCha20Poly1305(key).encrypt(nonce, plaintext_buffer, associated_data)
    finally:
        secure_wipe(plaintext_buffer)
    return {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
        "nonce": encode_base64(nonce),
        "ciphertext": encode_base64(ciphertext),
    }

def normalize_payload(payload: Any) -> Dict[str, Any]:
    """校验解密后的数据并补齐旧版本缺失的扁平批注字段。"""
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise VaultError("数据库内容格式无效。")
    raw_items = payload["items"]
    if len(raw_items) > MAX_ITEM_COUNT:
        raise VaultError("数据库条目数量超出允许范围。")
    normalized_payload = dict(payload)
    normalized_items: List[Dict[str, Any]] = []
    seen_item_ids = set()
    for raw_item in raw_items:
        if not isinstance(raw_item, dict):
            raise VaultError("数据库条目格式无效。")
        item_type = raw_item.get("type")
        if item_type not in ("password", "note"):
            raise VaultError("数据库包含不支持的条目类型。")
        item = dict(raw_item)
        item_id = item.get("id")
        # 修复缺失或重复的 ID，避免旧数据库条目相互覆盖。
        if not isinstance(item_id, str) or not item_id or item_id in seen_item_ids:
            item_id = str(uuid.uuid4())
        item["id"] = item_id
        seen_item_ids.add(item_id)
        for timestamp_field in ("created_at", "updated_at"):
            timestamp_value = item.get(timestamp_field, "")
            item[timestamp_field] = (
                timestamp_value if isinstance(timestamp_value, str) else ""
            )
        text_fields = (
            ("title", "username", "password", "notes")
            if item_type == "password"
            else ("title", "content")
        )
        for field_name in text_fields:
            field_value = item.get(field_name, "")
            if not isinstance(field_value, str):
                raise VaultError(f"数据库字段 {field_name} 类型无效。")
            if len(field_value) > MAX_TEXT_FIELD_LENGTH:
                raise VaultError(f"数据库字段 {field_name} 过大。")
            item[field_name] = field_value
        if item_type == "note":
            font_size = item.get("font_size", 20)
            if isinstance(font_size, bool) or not isinstance(font_size, int):
                font_size = 20
            item["font_size"] = min(max(font_size, 12), 36)
            raw_comments = item.get("comments", [])
            if not isinstance(raw_comments, list) or len(raw_comments) > MAX_COMMENT_COUNT:
                raise VaultError("笔记批注格式无效或数量过多。")
            normalized_comments = []
            seen_comment_ids = set()
            for raw_comment in raw_comments:
                if not isinstance(raw_comment, dict):
                    raise VaultError("笔记批注格式无效。")
                comment_text = raw_comment.get("text", "")
                quote_text = raw_comment.get("quote", "")
                if not isinstance(comment_text, str) or not isinstance(quote_text, str):
                    raise VaultError("笔记批注文字格式无效。")
                if len(comment_text) > MAX_TEXT_FIELD_LENGTH or len(quote_text) > MAX_TEXT_FIELD_LENGTH:
                    raise VaultError("笔记批注内容过大。")
                comment_id = str(raw_comment.get("id") or uuid.uuid4())
                if comment_id in seen_comment_ids:
                    comment_id = str(uuid.uuid4())
                seen_comment_ids.add(comment_id)
                normalized_comments.append({
                    "id": comment_id,
                    "quote": quote_text,
                    "text": comment_text,
                    "created_at": str(raw_comment.get("created_at") or now_iso()),
                    "updated_at": str(raw_comment.get("updated_at") or now_iso()),
                })
            item["comments"] = normalized_comments
        normalized_items.append(item)
    normalized_payload["items"] = normalized_items
    return normalized_payload

def decrypt_payload(vault_envelope: Any, master_password: str):
    kdf_params, salt_base64, salt, nonce, ciphertext = decode_vault_envelope(vault_envelope)
    key_buffer: Optional[bytearray] = None
    plaintext_buffer: Optional[bytearray] = None
    decryption_succeeded = False
    try:
        try:
            key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        except MemoryError as error:
            raise VaultError("Argon2id 内存分配失败。") from error
        except (TypeError, ValueError) as error:
            raise VaultError("数据库 KDF 参数无法处理。") from error
        associated_data = build_associated_data(kdf_params, salt_base64)
        try:
            plaintext_buffer = bytearray(ChaCha20Poly1305(key_buffer).decrypt(nonce, ciphertext, associated_data))
        except InvalidTag as error:
            raise VaultError("主密码错误，或者数据库文件被篡改。") from error
        try:
            payload = json.loads(plaintext_buffer.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
            raise VaultError("数据库明文内容损坏。") from error
        payload = normalize_payload(payload)
        decryption_succeeded = True
        return payload, key_buffer, salt, kdf_params
    finally:
        secure_wipe(plaintext_buffer)
        if not decryption_succeeded:
            secure_wipe(key_buffer)
class VaultFileLock:
    """跨平台的短时文件锁，配合摘要检查避免多个实例相互覆盖。"""

    def __init__(self, vault_path: Path):
        self.lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        self.handle = None

    def __enter__(self):
        try:
            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            self.handle = self.lock_path.open("a+b")
            if self.lock_path.stat().st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                os.chmod(self.lock_path, 0o600)
        except OSError as error:
            if self.handle is not None:
                with suppress(OSError):
                    self.handle.close()
            self.handle = None
            raise VaultError(
                "无法取得数据库文件锁。数据库可能正被其他实例使用，或当前目录不可写。"
            ) from error
        return self

    def __exit__(self, _exception_type, _exception, _traceback):
        if self.handle is None:
            return
        try:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None

def read_vault_file_snapshot(path: Path) -> Tuple[Dict[str, Any], str]:
    if not path.exists():
        raise VaultError("数据库文件不存在。")
    try:
        if path.stat().st_size > MAX_VAULT_FILE_SIZE:
            raise VaultError("数据库文件过大，拒绝加载。")
        with VaultFileLock(path):
            file_bytes = path.read_bytes()
        if len(file_bytes) > MAX_VAULT_FILE_SIZE:
            raise VaultError("数据库文件过大，拒绝加载。")
        vault_envelope = json.loads(file_bytes.decode("utf-8"))
        disk_digest = hashlib.sha256(file_bytes).hexdigest()
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
        raise VaultError("数据库文件损坏或格式不正确。") from error
    if not isinstance(vault_envelope, dict):
        raise VaultError("数据库文件格式无效。")
    return vault_envelope, disk_digest

def read_vault_file(path: Path) -> Dict[str, Any]:
    vault_envelope, _disk_digest = read_vault_file_snapshot(path)
    return vault_envelope

def current_vault_digest(path: Path) -> str:
    if not path.exists():
        return ""
    if path.stat().st_size > MAX_VAULT_FILE_SIZE:
        raise VaultError("数据库文件过大，拒绝处理。")
    return hashlib.sha256(path.read_bytes()).hexdigest()

def move_existing_vault_to_backup(path: Path) -> Optional[Path]:
    """把已有数据库改名为带日期的 .bak 文件。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with VaultFileLock(path):
        if not os.path.lexists(path):
            return None
        if not path.is_file():
            raise VaultError("已有数据库路径不是普通文件，无法自动备份。")

        date_text = datetime.now().strftime("%Y%m%d")
        stem, suffix = path.stem, path.suffix
        backup_path = path.with_name(f"{stem}_{date_text}.bak{suffix}")
        sequence = 1
        while os.path.lexists(backup_path):
            backup_path = path.with_name(
                f"{stem}_{date_text}_{sequence}.bak{suffix}"
            )
            sequence += 1
        try:
            path.rename(backup_path)
        except OSError as error:
            raise VaultError("无法改名并备份已有数据库，未创建新数据库。") from error
        return backup_path

def fsync_directory(directory: Path) -> None:
    """尽力同步目录元数据；不影响已成功写入的数据库。"""
    if os.name == "nt":
        return
    directory_descriptor = None
    with suppress(OSError):
        directory_descriptor = os.open(directory, os.O_RDONLY)
        os.fsync(directory_descriptor)
    if directory_descriptor is not None:
        with suppress(OSError):
            os.close(directory_descriptor)

def write_vault_file_atomic(
    path: Path,
    vault_envelope: Dict[str, Any],
    expected_disk_digest: Optional[str] = None,
) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized_envelope = json.dumps(vault_envelope, ensure_ascii=False, indent=2)
    serialized_bytes = serialized_envelope.encode("utf-8")
    temporary_path = path.with_name(
        f".{path.name}.{os.getpid()}.{secrets.token_hex(6)}.tmp"
    )
    # 先写入独立临时文件并同步磁盘，再原子替换正式数据库。
    try:
        with VaultFileLock(path):
            current_digest = current_vault_digest(path)
            if (
                expected_disk_digest is not None
                and current_digest != expected_disk_digest
            ):
                raise VaultError(
                    "数据库文件已被其他程序修改。为避免覆盖新数据，本次保存已取消；请重新打开数据库。"
                )
            with temporary_path.open("xb") as file_handle:
                file_handle.write(serialized_bytes)
                file_handle.flush()
                os.fsync(file_handle.fileno())
            if os.name != "nt":
                os.chmod(temporary_path, 0o600)
            os.replace(temporary_path, path)
            fsync_directory(path.parent)
    finally:
        with suppress(OSError):
            temporary_path.unlink(missing_ok=True)
    return hashlib.sha256(serialized_bytes).hexdigest()
def empty_payload() -> Dict[str, Any]:
    timestamp = now_iso()
    return {"app": APP_NAME, "version": VAULT_VERSION, "created_at": timestamp, "updated_at": timestamp, "items": []}
def password_strength_label(password: str) -> str:
    score = 0
    if len(password) >= 12:
        score += 1
    if len(password) >= 18:
        score += 1
    if len(password) >= 24:
        score += 1
    if any(character.islower() for character in password):
        score += 1
    if any(character.isupper() for character in password):
        score += 1
    if any(character.isdigit() for character in password):
        score += 1
    if any(character in string.punctuation for character in password):
        score += 1
    if score <= 3:
        return "弱"
    if score <= 5:
        return "中"
    return "强"
#------ 数据库核心 ------
class VaultError(Exception):
    pass
class Vault:
    def __init__(self, path: Path):
        self.path = path
        self.key: Optional[bytearray] = None
        self.salt: Optional[bytes] = None
        self.kdf_params: Dict[str, Any] = dict(ARGON2ID_PARAMS)
        self.payload: Dict[str, Any] = empty_payload()
        self.disk_digest = ""
    def _require_unlocked(self) -> None:
        if self.key is None or self.salt is None:
            raise VaultError("数据库处于锁定状态。")
    def _set_unlocked_state(
        self,
        *,
        key_buffer: bytearray,
        salt: bytes,
        kdf_params: Dict[str, Any],
        payload: Dict[str, Any],
    ) -> None:
        self.key = key_buffer
        self.salt = salt
        self.kdf_params = kdf_params
        self.payload = payload

    def _commit_payload(self, candidate_payload: Dict[str, Any]) -> None:
        self._require_unlocked()
        normalized_candidate = normalize_payload(candidate_payload)
        normalized_candidate["updated_at"] = now_iso()
        vault_envelope = encrypt_payload(
            normalized_candidate,
            self.key,
            self.salt,
            self.kdf_params,
        )
        new_digest = write_vault_file_atomic(
            self.path,
            vault_envelope,
            expected_disk_digest=self.disk_digest,
        )
        self.payload = normalized_candidate
        self.disk_digest = new_digest

    def create(self, master_password: str) -> None:
        if not master_password:
            raise VaultError("新主密码不能为空。")
        salt = os.urandom(16)
        kdf_params = dict(ARGON2ID_PARAMS)
        key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=empty_payload(),
        )
        backup_path: Optional[Path] = None
        try:
            # 目标文件存在时先改名备份，创建流程绝不直接覆盖原文件。
            backup_path = move_existing_vault_to_backup(self.path)
            self.disk_digest = ""
            self.save()
        except Exception as error:
            self.lock()
            if backup_path is not None:
                raise VaultError(
                    f"新数据库创建失败；原文件已安全保留为 {backup_path.name}。"
                ) from error
            raise
    def unlock(self, master_password: str) -> None:
        if self.key is not None:
            self.lock()
        vault_envelope, disk_digest = read_vault_file_snapshot(self.path)
        payload, key_buffer, salt, kdf_params = decrypt_payload(vault_envelope, master_password)
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=payload,
        )
        self.disk_digest = disk_digest
    def save(self) -> None:
        self._commit_payload(copy.deepcopy(self.payload))
    def change_master_password(self, new_master_password: str) -> None:
        self._require_unlocked()
        if not new_master_password:
            raise VaultError("新主密码不能为空。")
        old_key = self.key
        new_salt = os.urandom(16)
        new_kdf_params = dict(ARGON2ID_PARAMS)
        new_key = bytearray(derive_key(new_master_password, new_salt, new_kdf_params))
        candidate_payload = normalize_payload(copy.deepcopy(self.payload))
        candidate_payload["updated_at"] = now_iso()
        try:
            vault_envelope = encrypt_payload(
                candidate_payload,
                new_key,
                new_salt,
                new_kdf_params,
            )
            new_digest = write_vault_file_atomic(
                self.path,
                vault_envelope,
                expected_disk_digest=self.disk_digest,
            )
        except Exception:
            secure_wipe(new_key)
            raise
        # 只有新密文成功落盘后，才用新密钥替换内存状态。
        self._set_unlocked_state(
            key_buffer=new_key,
            salt=new_salt,
            kdf_params=new_kdf_params,
            payload=candidate_payload,
        )
        self.disk_digest = new_digest
        secure_wipe(old_key)
    def lock(self) -> None:
        secure_wipe(self.key)
        self.key = None
        self.salt = None
        items = self.payload.get("items")
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    item.clear()
            items.clear()
        self.payload.clear()
        self.payload = empty_payload()
        self.disk_digest = ""
    def all_items(self, item_type: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self.payload.get("items", [])
        if item_type is None:
            return list(items)
        return [item for item in items if item.get("type") == item_type]
    def upsert_item(self, item: Dict[str, Any]) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        item_copy = copy.deepcopy(item)
        item_copy["updated_at"] = now_iso()
        for index, existing in enumerate(items):
            if existing.get("id") == item_copy.get("id"):
                items[index] = item_copy
                self._commit_payload(candidate_payload)
                return
        item_copy.setdefault("id", str(uuid.uuid4()))
        item_copy.setdefault("created_at", now_iso())
        items.append(item_copy)
        self._commit_payload(candidate_payload)
    def delete_item(self, item_id: str) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        candidate_payload["items"] = [
            item for item in items if item.get("id") != item_id
        ]
        if len(candidate_payload["items"]) == len(items):
            raise VaultError("要删除的条目已经不存在。")
        self._commit_payload(candidate_payload)
#------ 对话框 ------
class ProtectedDialog(QDialog):
    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, lambda: protect_widget_from_capture(self))

class FunctionThread(QThread):
    succeeded = pyqtSignal(object)
    failed = pyqtSignal(object)

    def __init__(self, operation: Callable[[], Any], parent=None):
        super().__init__(parent)
        self.operation = operation

    def run(self):
        try:
            result = self.operation()
        except Exception as error:
            self.failed.emit(error)
            return
        self.succeeded.emit(result)

class BlockingProgressDialog(QProgressDialog):
    def reject(self):
        # 密钥派生不能安全中断，完成后由工作线程关闭窗口。
        return

def run_with_progress(
    parent,
    title: str,
    message: str,
    operation: Callable[[], Any],
) -> Any:
    dialog = BlockingProgressDialog(message, "", 0, 0, parent)
    dialog.setWindowTitle(title)
    dialog.setMinimumDuration(0)
    dialog.setAutoClose(False)
    dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
    dialog.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
    dialog.setMinimumWidth(480)
    result_holder: Dict[str, Any] = {}
    worker = FunctionThread(operation, dialog)

    def handle_success(result):
        result_holder["result"] = result
        dialog.done(QDialog.DialogCode.Accepted)

    def handle_failure(error):
        result_holder["error"] = error
        dialog.done(QDialog.DialogCode.Rejected)

    worker.succeeded.connect(handle_success)
    worker.failed.connect(handle_failure)
    worker.start()
    protect_widget_from_capture(dialog)
    dialog.exec()
    worker.wait()
    if "error" in result_holder:
        raise result_holder["error"]
    return result_holder.get("result")

def run_ui_operation(
    parent,
    error_title: str,
    operation: Callable[[], Any],
) -> Tuple[bool, Any]:
    """统一处理界面操作异常，避免每个按钮重复 try/except。"""
    try:
        return True, operation()
    except Exception as error:
        QMessageBox.critical(parent, error_title, str(error))
        return False, None

class StartupDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "open"
        self.setWindowTitle(APP_NAME)
        self.resize(900, 460)
        self.setMinimumWidth(860)
        self.setStyleSheet("QWidget { font-size: 16px; } QLabel#DialogTitle { font-size: 34px; }")
        title_label = QLabel("CipherNote Vault")
        title_label.setObjectName("DialogTitle")
        subtitle_label = QLabel("本地加密密码管理器与安全记事本。所有数据库内容均使用 Argon2id + ChaCha20-Poly1305 加密保存。")
        subtitle_label.setObjectName("SubtleLabel")
        subtitle_label.setWordWrap(True)
        self.open_database_radio = QRadioButton("打开已有数据库")
        self.create_database_radio = QRadioButton("创建新数据库")
        self.open_database_radio.setObjectName("ModeRadio")
        self.create_database_radio.setObjectName("ModeRadio")
        self.open_database_radio.setChecked(True)
        self.mode_button_group = QButtonGroup(self)
        self.mode_button_group.addButton(self.open_database_radio)
        self.mode_button_group.addButton(self.create_database_radio)
        self.mode_button_group.setExclusive(True)
        self.open_database_radio.toggled.connect(self.update_startup_mode)
        self.create_database_radio.toggled.connect(self.update_startup_mode)
        mode_frame = QFrame()
        mode_frame.setObjectName("ModeFrame")
        mode_layout = QHBoxLayout(mode_frame)
        mode_layout.setContentsMargins(12, 10, 12, 10)
        mode_layout.setSpacing(18)
        mode_layout.addWidget(self.open_database_radio)
        mode_layout.addWidget(self.create_database_radio)
        mode_layout.addStretch(1)
        self.path_edit = QLineEdit(str(DEFAULT_VAULT))
        self.path_edit.setPlaceholderText("选择 .cnvault 数据库文件")
        browse_button = QPushButton("浏览")
        browse_button.clicked.connect(self.browse)
        path_layout = QHBoxLayout()
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(browse_button)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.generate_master_password_button = QPushButton("随机生成")
        self.generate_master_password_button.clicked.connect(self.generate_master_password)
        password_layout = QHBoxLayout()
        password_layout.addWidget(self.password_edit, 1)
        password_layout.addWidget(self.generate_master_password_button)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        self.status_label.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("操作：", mode_frame)
        form_layout.addRow("数据库文件：", path_layout)
        form_layout.addRow("主密码：", password_layout)
        form_layout.addRow("确认主密码：", self.confirm_edit)
        form_layout.addRow("", self.status_label)
        self.ok_button = QPushButton("打开数据库")
        self.cancel_button = QPushButton("取消")
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(title_label)
        dialog_layout.addWidget(subtitle_label)
        dialog_layout.addSpacing(10)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
        self.update_startup_mode()
    def update_startup_mode(self):
        if self.create_database_radio.isChecked():
            self.mode = "create"
            self.setWindowTitle("创建新数据库 - CipherNote Vault")
            self.ok_button.setText("创建数据库")
            self.confirm_edit.setEnabled(True)
            self.generate_master_password_button.setEnabled(True)
            self.status_label.setText("当前操作：创建新数据库。将使用强加密参数创建本地数据库。")
        else:
            self.mode = "open"
            self.setWindowTitle("打开数据库 - CipherNote Vault")
            self.ok_button.setText("打开数据库")
            self.confirm_edit.setEnabled(False)
            self.generate_master_password_button.setEnabled(False)
            self.status_label.setText("当前操作：打开已有数据库。请选择已有 .cnvault 数据库并输入主密码。")
    def generate_master_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def browse(self):
        if self.mode == "create":
            selected_filename, _selected_filter = QFileDialog.getSaveFileName(
                self,
                "创建 CipherNote Vault 数据库",
                self.path_edit.text() or str(DEFAULT_VAULT),
                "CipherNote Vault (*.cnvault);;JSON 文件 (*.json);;所有文件 (*)",
            )
        else:
            selected_filename, _selected_filter = QFileDialog.getOpenFileName(
                self,
                "打开 CipherNote Vault 数据库",
                self.path_edit.text() or str(DEFAULT_VAULT_DIR),
                "CipherNote Vault (*.cnvault);;JSON 文件 (*.json);;所有文件 (*)",
            )
        if selected_filename:
            self.path_edit.setText(selected_filename)
    def get_result(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            raw_path = self.path_edit.text().strip()
            master_password = self.password_edit.text()
            if not raw_path:
                QMessageBox.warning(self, "缺少路径", "请选择数据库文件路径。")
                continue
            database_path = Path(raw_path).expanduser()
            if not master_password:
                QMessageBox.warning(self, "缺少主密码", "请输入主密码。")
                continue
            if self.mode == "create":
                if master_password != self.confirm_edit.text():
                    QMessageBox.warning(self, "密码不一致", "两次输入的主密码不一致。")
                    continue
                if database_path.exists():
                    if database_path.is_dir():
                        QMessageBox.warning(self, "路径无效", "数据库路径不能是文件夹。")
                        continue
                    answer = QMessageBox.question(
                        self,
                        "文件已存在",
                        "该文件已经存在。继续后，原文件会自动改名为带日期和 .bak 标识的备份，不会被覆盖。\n\n确定创建新的数据库吗？",
                    )
                    if answer != QMessageBox.StandardButton.Yes:
                        continue
                result = {"mode": "create", "path": database_path, "password": master_password}
                self.password_edit.clear()
                self.confirm_edit.clear()
                return result
            if not database_path.is_file():
                QMessageBox.warning(self, "文件不存在", "请选择一个已经存在的数据库文件。")
                continue
            result = {"mode": "open", "path": database_path, "password": master_password}
            self.password_edit.clear()
            self.confirm_edit.clear()
            return result
class PasswordGeneratorDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.generated_password = ""
        self.setWindowTitle("生成随机密码")
        self.resize(720, 520)
        self.setMinimumSize(680, 500)
        self.setModal(True)
        self.setStyleSheet("""
            QDialog {
                background-color: #241000;
            }
            QLabel {
                color: #F7D000;
                font-size: 17px;
            }
            QLabel#GeneratorTitle {
                color: #FFF000;
                font-size: 30px;
                font-weight: 700;
            }
            QLabel#GeneratorSubtitle {
                color: #D9A400;
                font-size: 15px;
            }
            QLabel#SectionTitle {
                color: #FFF000;
                font-size: 18px;
                font-weight: 700;
            }
            QLabel#StatusLabel {
                color: #D9A400;
                font-size: 14px;
            }
            QFrame#PasswordPreviewCard,
            QFrame#OptionsCard {
                background-color: #351100;
                border: 1px solid #7C1D00;
                border-radius: 12px;
            }
            QLineEdit#PasswordPreview {
                background-color: #170800;
                color: #FFF000;
                border: 2px solid #E9C400;
                border-radius: 9px;
                padding: 12px 14px;
                font-size: 21px;
                font-family: Consolas, "Courier New", monospace;
                selection-background-color: #FFD700;
                selection-color: #FF0000;
            }
            QSpinBox {
                min-height: 38px;
                min-width: 120px;
                padding: 0 10px;
                color: #FFF000;
                background-color: #170800;
                border: 1px solid #8A1F00;
                border-radius: 7px;
                font-size: 18px;
            }
            QCheckBox {
                color: #F7D000;
                font-size: 17px;
                spacing: 10px;
                min-height: 34px;
            }
            QPushButton {
                min-height: 42px;
                padding: 0 18px;
                color: #241000;
                background-color: #E9C400;
                border: 1px solid #F1C900;
                border-radius: 8px;
                font-size: 17px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #F3D500;
            }
            QPushButton:pressed {
                background-color: #D89C00;
            }
            QPushButton#SecondaryButton {
                color: #F7D000;
                background-color: #5F1700;
                border-color: #9A3400;
            }
            QPushButton#SecondaryButton:hover {
                background-color: #7C1D00;
            }
            QPushButton#CancelButton {
                color: #F7D000;
                background-color: #351100;
                border-color: #7C1D00;
            }
            QPushButton#CancelButton:hover {
                background-color: #5F1700;
            }
        """)
        self.build_interface()
        self.connect_signals()
        self.refresh_password()

    def build_interface(self):
        title_label = QLabel("随机密码生成器")
        title_label.setObjectName("GeneratorTitle")
        subtitle_label = QLabel("选择密码长度和字符类型，使用系统安全随机数生成密码。")
        subtitle_label.setObjectName("GeneratorSubtitle")
        subtitle_label.setWordWrap(True)

        self.password_preview = QLineEdit()
        self.password_preview.setObjectName("PasswordPreview")
        self.password_preview.setReadOnly(True)
        self.password_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.password_preview.setMinimumHeight(58)

        preview_title = QLabel("生成结果")
        preview_title.setObjectName("SectionTitle")
        preview_card = QFrame()
        preview_card.setObjectName("PasswordPreviewCard")
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(18, 16, 18, 18)
        preview_layout.setSpacing(10)
        preview_layout.addWidget(preview_title)
        preview_layout.addWidget(self.password_preview)

        length_label = QLabel("密码长度")
        length_label.setObjectName("SectionTitle")
        self.password_length_spinbox = QSpinBox()
        self.password_length_spinbox.setRange(1, MAX_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setValue(DEFAULT_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setSuffix(" 位")
        length_row = QHBoxLayout()
        length_row.setSpacing(14)
        length_row.addWidget(length_label)
        length_row.addStretch(1)
        length_row.addWidget(self.password_length_spinbox)

        character_label = QLabel("包含字符")
        character_label.setObjectName("SectionTitle")
        self.include_lowercase_checkbox = QCheckBox("小写字母  a-z")
        self.include_uppercase_checkbox = QCheckBox("大写字母  A-Z")
        self.include_digits_checkbox = QCheckBox("数字  0-9")
        self.include_symbols_checkbox = QCheckBox("特殊符号  !@#$...")
        for checkbox in (
            self.include_lowercase_checkbox,
            self.include_uppercase_checkbox,
            self.include_digits_checkbox,
            self.include_symbols_checkbox,
        ):
            checkbox.setChecked(True)

        checkbox_row_1 = QHBoxLayout()
        checkbox_row_1.setSpacing(24)
        checkbox_row_1.addWidget(self.include_lowercase_checkbox, 1)
        checkbox_row_1.addWidget(self.include_uppercase_checkbox, 1)
        checkbox_row_2 = QHBoxLayout()
        checkbox_row_2.setSpacing(24)
        checkbox_row_2.addWidget(self.include_digits_checkbox, 1)
        checkbox_row_2.addWidget(self.include_symbols_checkbox, 1)

        self.status_label = QLabel("默认生成 32 位密码。")
        self.status_label.setObjectName("StatusLabel")
        self.status_label.setWordWrap(True)

        options_card = QFrame()
        options_card.setObjectName("OptionsCard")
        options_layout = QVBoxLayout(options_card)
        options_layout.setContentsMargins(18, 16, 18, 16)
        options_layout.setSpacing(12)
        options_layout.addLayout(length_row)
        options_layout.addSpacing(4)
        options_layout.addWidget(character_label)
        options_layout.addLayout(checkbox_row_1)
        options_layout.addLayout(checkbox_row_2)
        options_layout.addWidget(self.status_label)

        self.regenerate_button = QPushButton("重新生成")
        self.regenerate_button.setObjectName("SecondaryButton")
        self.use_password_button = QPushButton("使用此密码")
        self.cancel_button = QPushButton("取消")
        self.cancel_button.setObjectName("CancelButton")

        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)
        button_layout.addWidget(self.regenerate_button)
        button_layout.addStretch(1)
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.use_password_button)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(16)
        main_layout.addWidget(title_label)
        main_layout.addWidget(subtitle_label)
        main_layout.addWidget(preview_card)
        main_layout.addWidget(options_card)
        main_layout.addStretch(1)
        main_layout.addLayout(button_layout)

    def connect_signals(self):
        self.regenerate_button.clicked.connect(self.refresh_password)
        self.use_password_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        self.password_length_spinbox.valueChanged.connect(self.refresh_password)
        self.include_lowercase_checkbox.toggled.connect(self.refresh_password)
        self.include_uppercase_checkbox.toggled.connect(self.refresh_password)
        self.include_digits_checkbox.toggled.connect(self.refresh_password)
        self.include_symbols_checkbox.toggled.connect(self.refresh_password)

    def refresh_password(self):
        try:
            self.generated_password = generate_secure_password(
                length=self.password_length_spinbox.value(),
                include_lowercase=self.include_lowercase_checkbox.isChecked(),
                include_uppercase=self.include_uppercase_checkbox.isChecked(),
                include_digits=self.include_digits_checkbox.isChecked(),
                include_symbols=self.include_symbols_checkbox.isChecked(),
            )
        except ValueError as error:
            self.generated_password = ""
            self.password_preview.clear()
            self.status_label.setText(str(error))
            self.use_password_button.setEnabled(False)
            return
        self.password_preview.setText(self.generated_password)
        self.password_preview.setCursorPosition(0)
        enabled_types = sum((
            self.include_lowercase_checkbox.isChecked(),
            self.include_uppercase_checkbox.isChecked(),
            self.include_digits_checkbox.isChecked(),
            self.include_symbols_checkbox.isChecked(),
        ))
        self.status_label.setText(
            f"长度：{self.password_length_spinbox.value()} 位    "
            f"字符类型：{enabled_types} 种"
        )
        self.use_password_button.setEnabled(True)

    def generate(self) -> Optional[str]:
        if self.exec() != QDialog.DialogCode.Accepted:
            self.generated_password = ""
            self.password_preview.clear()
            return None
        password = self.generated_password
        self.generated_password = ""
        self.password_preview.clear()
        return password
class PasswordDialog(ProtectedDialog):
    def __init__(self, item: Optional[Dict[str, Any]] = None, parent=None):
        super().__init__(parent)
        self.item = item or {}
        self.setWindowTitle("密码条目")
        self.resize(940, 680)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.username_edit = QLineEdit(self.item.get("username", ""))
        self.password_edit = QLineEdit(self.item.get("password", ""))
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.notes_edit = QPlainTextEdit(self.item.get("notes", ""))
        self.strength_label = QLabel("")
        self.strength_label.setObjectName("SubtleLabel")
        self.password_edit.textChanged.connect(self.update_strength)
        self.update_strength()
        show_password_button = QPushButton("显示/隐藏")
        generate_password_button = QPushButton("随机生成")
        show_password_button.clicked.connect(self.toggle_password_visibility)
        generate_password_button.clicked.connect(self.generate_password)
        password_row = QHBoxLayout()
        password_row.addWidget(self.password_edit, 1)
        password_row.addWidget(show_password_button)
        password_row.addWidget(generate_password_button)
        form_layout = QFormLayout()
        form_layout.addRow("标题：", self.title_edit)
        form_layout.addRow("用户名：", self.username_edit)
        form_layout.addRow("密码：", password_row)
        form_layout.addRow("", self.strength_label)
        form_layout.addRow("备注：", self.notes_edit)
        save_button = QPushButton("保存")
        cancel_button = QPushButton("取消")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def update_strength(self):
        password_value = self.password_edit.text()
        self.strength_label.setText(
            "密码强度：未填写"
            if not password_value
            else f"密码强度：{password_strength_label(password_value)}"
        )
    def toggle_password_visibility(self):
        if self.password_edit.echoMode() == QLineEdit.EchoMode.Password:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
        else:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def clear_sensitive_fields(self) -> None:
        self.password_edit.clear()
        self.notes_edit.clear()
        self.username_edit.clear()
        self.title_edit.clear()
        self.item = {}
    def build_password_item(self) -> Optional[Dict[str, Any]]:
        title_value = self.title_edit.text().strip()
        if not title_value:
            QMessageBox.warning(self, "缺少标题", "标题不能为空。")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "password",
            "title": title_value,
            "username": self.username_edit.text().strip(),
            "password": self.password_edit.text(),
            "notes": self.notes_edit.toPlainText(),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }
    def get_item(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.clear_sensitive_fields()
                return None
            result = self.build_password_item()
            if result is None:
                continue
            self.clear_sensitive_fields()
            return result
class NoteDialog(ProtectedDialog):
    def __init__(
        self,
        item: Optional[Dict[str, Any]] = None,
        parent=None,
        on_save: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        super().__init__(parent)
        self.item = copy.deepcopy(item or {})
        self.comments: List[Dict[str, Any]] = copy.deepcopy(
            self.item.get("comments", [])
        )
        self.on_save = on_save
        self.saved_item: Optional[Dict[str, Any]] = None
        self.is_dirty = False
        self._suppress_dirty = True
        self._last_note_match = None
        self.setWindowTitle("安全记事本")
        self.resize(1320, 860)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.title_edit.setPlaceholderText("笔记标题")
        self.content_edit = QPlainTextEdit(self.item.get("content", ""))
        self.content_edit.setObjectName("NoteContentEditor")
        self.content_edit.setPlaceholderText("在这里写你的重要笔记……")
        self.note_font_slider = QSlider(Qt.Orientation.Horizontal)
        self.note_font_slider.setRange(12, 36)
        self.note_font_slider.setValue(int(self.item.get("font_size", 20) or 20))
        self.note_font_slider.setFixedWidth(180)
        self.note_font_slider.valueChanged.connect(self.apply_note_font_size)
        self.note_font_size_label = QLabel(f"字体 {self.note_font_slider.value()}")
        self.note_font_size_label.setObjectName("SubtleLabel")
        self.save_status_label = QLabel("Ctrl+S 保存，不关闭窗口")
        self.save_status_label.setObjectName("SubtleLabel")
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(8)
        title_label = QLabel("标题")
        title_label.setObjectName("SearchLabel")
        title_label.setFixedWidth(44)
        title_layout.addWidget(title_label)
        title_layout.addWidget(self.title_edit, 1)
        import_button = QPushButton("导入文本")
        cleanup_button = QPushButton("整理空行")
        import_button.clicked.connect(self.import_text_file)
        cleanup_button.clicked.connect(self.cleanup_blank_lines)
        title_layout.addWidget(import_button)
        title_layout.addWidget(cleanup_button)

        self.note_find_edit = QLineEdit()
        self.note_find_edit.setPlaceholderText("查找内容")
        self.note_replace_edit = QLineEdit()
        self.note_replace_edit.setPlaceholderText("替换为")
        self.note_regex_checkbox = QCheckBox("正则")
        self.note_search_status = QLabel("")
        self.note_search_status.setObjectName("SubtleLabel")
        find_next_button = QPushButton("查找下一个")
        replace_button = QPushButton("替换当前")
        replace_all_button = QPushButton("全部替换")
        find_next_button.clicked.connect(self.find_next_in_note)
        replace_button.clicked.connect(self.replace_current_match)
        replace_all_button.clicked.connect(self.replace_all_matches)
        self.note_find_edit.returnPressed.connect(self.find_next_in_note)
        find_shortcut = QShortcut(QKeySequence.StandardKey.Find, self)
        find_shortcut.activated.connect(self.focus_note_search)
        search_frame = QFrame()
        search_frame.setObjectName("InlineSearch")
        search_layout = QHBoxLayout(search_frame)
        search_layout.setContentsMargins(8, 6, 8, 6)
        search_layout.setSpacing(6)
        search_layout.addWidget(QLabel("查找"))
        search_layout.addWidget(self.note_find_edit, 2)
        search_layout.addWidget(QLabel("替换"))
        search_layout.addWidget(self.note_replace_edit, 2)
        search_layout.addWidget(self.note_regex_checkbox)
        search_layout.addWidget(find_next_button)
        search_layout.addWidget(replace_button)
        search_layout.addWidget(replace_all_button)
        search_layout.addWidget(self.note_search_status, 1)

        self.comment_list = QListWidget()
        self.comment_list.setObjectName("CommentList")
        self.comment_list.setAlternatingRowColors(True)
        self.comment_list.currentItemChanged.connect(self.show_selected_comment)
        self.comment_preview = QPlainTextEdit()
        self.comment_preview.setObjectName("CommentPreview")
        self.comment_preview.setReadOnly(True)
        self.comment_preview.setPlaceholderText("选择一条批注查看内容")
        self.comment_preview.setMaximumHeight(180)
        add_comment_button = QPushButton("新增批注")
        edit_comment_button = QPushButton("编辑")
        delete_comment_button = QPushButton("删除")
        add_comment_button.clicked.connect(self.add_comment)
        edit_comment_button.clicked.connect(self.edit_comment)
        delete_comment_button.clicked.connect(self.delete_comment)
        comment_button_layout = QHBoxLayout()
        comment_button_layout.setSpacing(6)
        comment_button_layout.addWidget(add_comment_button)
        comment_button_layout.addWidget(edit_comment_button)
        comment_button_layout.addWidget(delete_comment_button)
        comments_title = QLabel("右侧批注（平铺，不嵌套）")
        comments_title.setObjectName("SectionTitle")
        comments_panel = QFrame()
        comments_panel.setObjectName("CommentsPanel")
        comments_layout = QVBoxLayout(comments_panel)
        comments_layout.setContentsMargins(10, 10, 10, 10)
        comments_layout.setSpacing(8)
        comments_layout.addWidget(comments_title)
        comments_layout.addWidget(self.comment_list, 1)
        comments_layout.addWidget(self.comment_preview)
        comments_layout.addLayout(comment_button_layout)

        editor_splitter = QSplitter(Qt.Orientation.Horizontal)
        editor_splitter.addWidget(self.content_edit)
        editor_splitter.addWidget(comments_panel)
        editor_splitter.setStretchFactor(0, 4)
        editor_splitter.setStretchFactor(1, 1)
        editor_splitter.setSizes([980, 320])

        save_button = QPushButton("保存")
        close_button = QPushButton("关闭")
        save_button.clicked.connect(self.save_without_closing)
        close_button.clicked.connect(self.close)
        save_shortcut = QShortcut(QKeySequence.StandardKey.Save, self)
        save_shortcut.activated.connect(self.save_without_closing)
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 6, 0, 0)
        bottom_layout.setSpacing(8)
        bottom_layout.addWidget(QLabel("字体"))
        bottom_layout.addWidget(self.note_font_slider)
        bottom_layout.addWidget(self.note_font_size_label)
        bottom_layout.addSpacing(14)
        bottom_layout.addWidget(self.save_status_label)
        bottom_layout.addStretch(1)
        bottom_layout.addWidget(save_button)
        bottom_layout.addWidget(close_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.setContentsMargins(10, 10, 10, 10)
        dialog_layout.setSpacing(6)
        dialog_layout.addLayout(title_layout)
        dialog_layout.addWidget(search_frame)
        dialog_layout.addWidget(editor_splitter, 1)
        dialog_layout.addLayout(bottom_layout)
        self.apply_note_font_size()
        self.refresh_comment_list()
        self.title_edit.textChanged.connect(self.mark_dirty)
        self.content_edit.textChanged.connect(self.mark_dirty)
        self.note_font_slider.valueChanged.connect(self.mark_dirty)
        self._suppress_dirty = False

    def mark_dirty(self, *_args):
        if self._suppress_dirty:
            return
        self._last_note_match = None
        self.is_dirty = True
        self.save_status_label.setText("尚未保存 · Ctrl+S 保存")

    def apply_note_font_size(self):
        note_font = QFont("Microsoft YaHei")
        note_font.setPointSize(self.note_font_slider.value())
        self.content_edit.setFont(note_font)
        self.note_font_size_label.setText(f"字体 {self.note_font_slider.value()}")

    def focus_note_search(self):
        self.note_find_edit.setFocus()
        self.note_find_edit.selectAll()

    def build_note_search_pattern(self) -> Optional[Pattern[str]]:
        pattern_text = self.note_find_edit.text()
        if not pattern_text:
            self.note_search_status.setText("请输入查找内容")
            return None
        try:
            if self.note_regex_checkbox.isChecked():
                return compile_search_regex(pattern_text)
            return re.compile(re.escape(pattern_text), re.IGNORECASE | re.UNICODE)
        except ValueError as error:
            self.note_search_status.setText(str(error))
            return None

    def find_next_in_note(self) -> bool:
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return False
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        start_position = qt_position_to_python_index(
            source_text,
            cursor.selectionEnd() if cursor.hasSelection() else cursor.position(),
        )
        if self._last_note_match is not None:
            previous_match = self._last_note_match[0]
            if previous_match.start() == previous_match.end():
                start_position = min(len(source_text), start_position + 1)
        match = compiled_pattern.search(source_text, start_position)
        wrapped = False
        if match is None and start_position > 0:
            match = compiled_pattern.search(source_text, 0, start_position)
            wrapped = match is not None
        if match is None:
            self._last_note_match = None
            self.note_search_status.setText("未找到")
            return False
        selection_cursor = self.content_edit.textCursor()
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.start())
        )
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.end()),
            QTextCursor.MoveMode.KeepAnchor,
        )
        self.content_edit.setTextCursor(selection_cursor)
        self.content_edit.ensureCursorVisible()
        self.content_edit.setFocus()
        self._last_note_match = (
            match,
            self.note_regex_checkbox.isChecked(),
        )
        self.note_search_status.setText("已从开头继续" if wrapped else "已找到")
        return True

    def replace_current_match(self):
        if self._last_note_match is None and not self.find_next_in_note():
            return
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        match, regex_mode = self._last_note_match
        selected_start = qt_position_to_python_index(
            source_text, cursor.selectionStart()
        )
        selected_end = qt_position_to_python_index(
            source_text, cursor.selectionEnd()
        )
        if (selected_start, selected_end) != (match.start(), match.end()):
            self._last_note_match = None
            if not self.find_next_in_note():
                return
            cursor = self.content_edit.textCursor()
            match, regex_mode = self._last_note_match
        replacement_text = self.note_replace_edit.text()
        try:
            replacement_value = (
                match.expand(replacement_text) if regex_mode else replacement_text
            )
        except re.error as error:
            self.note_search_status.setText(f"替换表达式无效：{error}")
            return
        cursor.insertText(replacement_value)
        self.content_edit.setTextCursor(cursor)
        self.note_search_status.setText("已替换 1 处")

    def replace_all_matches(self):
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return
        source_text = self.content_edit.toPlainText()
        replacement_text = self.note_replace_edit.text()
        try:
            if self.note_regex_checkbox.isChecked():
                replaced_text, replacement_count = compiled_pattern.subn(
                    replacement_text,
                    source_text,
                )
            else:
                replaced_text, replacement_count = compiled_pattern.subn(
                    lambda _match: replacement_text,
                    source_text,
                )
        except re.error as error:
            self.note_search_status.setText(f"替换表达式无效：{error}")
            return
        if replacement_count == 0:
            self.note_search_status.setText("未找到可替换内容")
            return
        self.replace_editor_text(replaced_text)
        self.mark_dirty()
        self.note_search_status.setText(f"已替换 {replacement_count} 处，可撤销")

    def replace_editor_text(self, new_text: str):
        cursor = self.content_edit.textCursor()
        cursor.beginEditBlock()
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.insertText(new_text)
        cursor.endEditBlock()
        self.content_edit.setTextCursor(cursor)

    def import_text_file(self):
        selected_filename, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "导入文本文件",
            "",
            "文本文件 (*.txt *.md *.log *.csv *.json *.xml *.html);;所有文件 (*)",
        )
        if not selected_filename:
            return
        source_path = Path(selected_filename)
        succeeded, import_result = run_ui_operation(
            self,
            "导入失败",
            lambda: read_imported_text_file(source_path),
        )
        if not succeeded:
            return
        imported_text, encoding, coherence = import_result

        choice_box = QMessageBox(self)
        choice_box.setWindowTitle("导入方式")
        choice_box.setText(
            f"已识别编码：{encoding}（可信度 {coherence:.1f}%）\n\n"
            "请选择替换当前正文，或追加到正文末尾。"
        )
        replace_button = choice_box.addButton(
            "替换正文", QMessageBox.ButtonRole.AcceptRole
        )
        append_button = choice_box.addButton(
            "追加正文", QMessageBox.ButtonRole.ActionRole
        )
        choice_box.addButton("取消", QMessageBox.ButtonRole.RejectRole)
        choice_box.exec()
        clicked_button = choice_box.clickedButton()
        if clicked_button == replace_button:
            self.replace_editor_text(imported_text)
        elif clicked_button == append_button:
            current_text = self.content_edit.toPlainText()
            separator = "\n" if current_text and not current_text.endswith("\n") else ""
            self.replace_editor_text(current_text + separator + imported_text)
        else:
            return
        self.mark_dirty()
        self.save_status_label.setText(
            f"已导入 {source_path.name} · 编码 {encoding} · 尚未保存"
        )

    def cleanup_blank_lines(self):
        original_text = self.content_edit.toPlainText()
        cleaned_text = remove_extra_blank_lines(original_text)
        if cleaned_text == original_text:
            self.save_status_label.setText("没有发现多余空行")
            return
        self.replace_editor_text(cleaned_text)
        self.mark_dirty()
        self.save_status_label.setText("多余空行已整理 · 尚未保存，可撤销")

    def refresh_comment_list(self, select_id: Optional[str] = None):
        self.comment_list.clear()
        selected_row = -1
        for index, comment in enumerate(self.comments):
            quote = str(comment.get("quote", "")).strip().replace("\n", " ")
            body = str(comment.get("text", "")).strip().replace("\n", " ")
            anchor_label = f"“{quote[:34]}”" if quote else "整篇笔记"
            display_text = f"{anchor_label}\n{body[:72]}"
            list_item = QListWidgetItem(display_text)
            list_item.setData(Qt.ItemDataRole.UserRole, comment.get("id"))
            list_item.setToolTip(body)
            self.comment_list.addItem(list_item)
            if select_id and comment.get("id") == select_id:
                selected_row = index
        if selected_row >= 0:
            self.comment_list.setCurrentRow(selected_row)
        elif self.comments:
            self.comment_list.setCurrentRow(0)
        else:
            self.comment_preview.clear()

    def selected_comment(self) -> Optional[Dict[str, Any]]:
        list_item = self.comment_list.currentItem()
        if list_item is None:
            return None
        comment_id = list_item.data(Qt.ItemDataRole.UserRole)
        return next(
            (comment for comment in self.comments if comment.get("id") == comment_id),
            None,
        )

    def show_selected_comment(self, *_args):
        comment = self.selected_comment()
        if comment is None:
            self.comment_preview.clear()
            return
        quote = str(comment.get("quote", ""))
        body = str(comment.get("text", ""))
        preview = f"引用：\n{quote}\n\n批注：\n{body}" if quote else f"批注：\n{body}"
        self.comment_preview.setPlainText(preview)
        if quote:
            found_cursor = self.content_edit.document().find(quote)
            if not found_cursor.isNull():
                self.content_edit.setTextCursor(found_cursor)
                self.content_edit.ensureCursorVisible()

    def add_comment(self):
        selected_quote = self.content_edit.textCursor().selectedText()
        selected_quote = selected_quote.replace("\u2029", "\n").strip()
        comment_text, accepted = QInputDialog.getMultiLineText(
            self,
            "新增批注",
            "批注内容：",
        )
        comment_text = comment_text.strip()
        if not accepted or not comment_text:
            return
        timestamp = now_iso()
        comment = {
            "id": str(uuid.uuid4()),
            "quote": selected_quote,
            "text": comment_text,
            "created_at": timestamp,
            "updated_at": timestamp,
        }
        self.comments.append(comment)
        self.refresh_comment_list(comment["id"])
        self.mark_dirty()

    def edit_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "请选择批注", "请先选择一条批注。")
            return
        updated_text, accepted = QInputDialog.getMultiLineText(
            self,
            "编辑批注",
            "批注内容：",
            str(comment.get("text", "")),
        )
        updated_text = updated_text.strip()
        if not accepted or not updated_text:
            return
        comment["text"] = updated_text
        comment["updated_at"] = now_iso()
        self.refresh_comment_list(str(comment.get("id", "")))
        self.mark_dirty()

    def delete_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "请选择批注", "请先选择一条批注。")
            return
        answer = QMessageBox.question(self, "确认删除", "确定删除这条批注吗？")
        if answer != QMessageBox.StandardButton.Yes:
            return
        comment_id = comment.get("id")
        self.comments = [
            existing for existing in self.comments
            if existing.get("id") != comment_id
        ]
        self.refresh_comment_list()
        self.mark_dirty()

    def build_note_item(self) -> Optional[Dict[str, Any]]:
        note_title = self.title_edit.text().strip()
        if not note_title:
            QMessageBox.warning(self, "缺少标题", "标题不能为空。")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "note",
            "title": note_title,
            "content": self.content_edit.toPlainText(),
            "font_size": self.note_font_slider.value(),
            "comments": copy.deepcopy(self.comments),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }

    def save_without_closing(self) -> bool:
        note_item = self.build_note_item()
        if note_item is None:
            return False
        if self.on_save is not None:
            succeeded, _result = run_ui_operation(
                self,
                "保存失败",
                lambda: self.on_save(copy.deepcopy(note_item)),
            )
            if not succeeded:
                self.save_status_label.setText("保存失败，内容仍保留在编辑窗口")
                return False
        self.item = copy.deepcopy(note_item)
        self.saved_item = copy.deepcopy(note_item)
        self.is_dirty = False
        self.save_status_label.setText(f"已保存：{readable_time(note_item.get('updated_at', ''))}")
        return True

    def get_item(self) -> Optional[Dict[str, Any]]:
        self.exec()
        return copy.deepcopy(self.saved_item)

    def clear_sensitive_fields(self):
        self._suppress_dirty = True
        self.title_edit.clear()
        self.content_edit.clear()
        self.note_find_edit.clear()
        self.note_replace_edit.clear()
        self.comment_preview.clear()
        self.comment_list.clear()
        self.comments.clear()
        self.item.clear()
        self._last_note_match = None

    def closeEvent(self, event):
        if self.is_dirty:
            message_box = QMessageBox(self)
            message_box.setWindowTitle("尚未保存")
            message_box.setText("笔记有尚未保存的修改。")
            save_button = message_box.addButton(
                "保存并关闭", QMessageBox.ButtonRole.AcceptRole
            )
            discard_button = message_box.addButton(
                "放弃修改", QMessageBox.ButtonRole.DestructiveRole
            )
            message_box.addButton("取消", QMessageBox.ButtonRole.RejectRole)
            message_box.exec()
            clicked_button = message_box.clickedButton()
            if clicked_button == save_button:
                if not self.save_without_closing():
                    event.ignore()
                    return
            elif clicked_button != discard_button:
                event.ignore()
                return
        self.clear_sensitive_fields()
        event.accept()

class MasterPasswordDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("修改主密码")
        self.resize(650, 320)
        self.setMinimumWidth(620)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        hint = QLabel("修改主密码会重新生成 salt，并用新的 Argon2id 派生密钥重新加密数据库。")
        hint.setObjectName("SubtleLabel")
        hint.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("新主密码：", self.password_edit)
        form_layout.addRow("确认主密码：", self.confirm_edit)
        generate_password_button = QPushButton("随机生成")
        generate_password_button.clicked.connect(self.generate_password)
        save_button = QPushButton("修改")
        cancel_button = QPushButton("取消")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addWidget(generate_password_button)
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(hint)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def get_password(self) -> Optional[str]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            master_password = self.password_edit.text()
            if not master_password:
                QMessageBox.warning(self, "缺少主密码", "请输入新主密码。")
                continue
            if master_password != self.confirm_edit.text():
                QMessageBox.warning(self, "密码不一致", "两次输入的主密码不一致。")
                continue
            self.password_edit.clear()
            self.confirm_edit.clear()
            return master_password
#------ 主界面组件 ------
class DetailCard(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self.title = QLabel("请选择一条记录")
        self.title.setObjectName("CardTitle")
        self.title.setWordWrap(True)
        self.meta = QLabel("")
        self.meta.setObjectName("SubtleLabel")
        self.meta.setWordWrap(True)
        self.body = QPlainTextEdit("")
        self.body.setObjectName("BodyLabel")
        self.body.setReadOnly(True)
        self.body.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.body.setWordWrapMode(
            QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere
        )
        self.body.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.body.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.addWidget(self.title)
        layout.addWidget(self.meta)
        layout.addSpacing(10)
        layout.addWidget(self.body, 1)
    def show_password_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("请选择一条密码记录")
            self.meta.setText("")
            self.body.setPlainText("左侧列表支持搜索；双击记录可以编辑。")
            return
        masked = "•" * min(max(len(item.get("password", "")), 8), 24)
        self.title.setText(item.get("title", ""))
        self.meta.setText(f"更新时间：{readable_time(item.get('updated_at', ''))}")
        self.body.setPlainText(
            f"用户名：{item.get('username', '')}\n"
            f"密码：{masked}\n\n"
            f"备注：\n{item.get('notes', '')}"
        )
    def show_note_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("请选择一条安全笔记")
            self.meta.setText("")
            self.body.setPlainText("左侧列表支持搜索；双击记录可以打开编辑。")
            return
        self.title.setText(item.get("title", ""))
        comment_count = len(item.get("comments", []))
        self.meta.setText(
            f"更新时间：{readable_time(item.get('updated_at', ''))} · "
            f"批注：{comment_count} 条"
        )
        self.body.setPlainText(item.get("content", ""))
#------ 主窗口 ------
class MainWindow(QMainWindow):
    def __init__(self, vault: Vault):
        super().__init__()
        self.vault = vault
        self.setWindowTitle(f"{APP_NAME} - {vault.path}")
        self.resize(1240, 790)
        self.password_items_all: List[Dict[str, Any]] = []
        self.password_items_view: List[Dict[str, Any]] = []
        self.note_items_all: List[Dict[str, Any]] = []
        self.note_items_view: List[Dict[str, Any]] = []
        self.crypto_wallet_result: Optional[Dict[str, Any]] = None
        self._lock_in_progress = False
        self.managed_clipboard_digest: Optional[bytes] = None
        self.search_edit = QLineEdit()
        self.search_edit.setObjectName("主工具栏SearchInput")
        self.search_edit.setFixedHeight(32)
        self.search_edit.setPlaceholderText(
            "最长公共子序列搜索（忽略大小写）；* 为通配符，例如：开头*结尾"
        )
        self.search_mode = QComboBox()
        self.search_mode.addItems(["LCS / 通配符", "正则表达式"])
        self.search_mode.setMinimumWidth(130)
        self.search_mode.setFixedHeight(32)
        self.search_edit.textChanged.connect(self.apply_filter)
        self.search_edit.returnPressed.connect(self.apply_filter)
        self.search_mode.currentIndexChanged.connect(self.search_mode_changed)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.password_table = self.make_table(["标题", "用户名", "备注", "更新时间"])
        self.note_table = self.make_table(["标题", "批注", "更新时间"])
        self.password_detail = DetailCard()
        self.note_detail = DetailCard()
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.note_splitter = QSplitter(Qt.Orientation.Horizontal)
        # 忽略内容自身的宽度提示，避免长备注限制分隔条拖动范围。
        for splitter, table, detail in (
            (self.password_splitter, self.password_table, self.password_detail),
            (self.note_splitter, self.note_table, self.note_detail),
        ):
            splitter.setHandleWidth(10)
            splitter.setOpaqueResize(True)
            splitter.setStretchFactor(0, 3)
            splitter.setStretchFactor(1, 2)
            splitter.setCollapsible(0, False)
            splitter.setCollapsible(1, True)
            table.setMinimumWidth(320)
            table.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
            detail.setMinimumWidth(0)
            detail.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
        self.tabs.addTab(self.make_password_tab(), "密码管理器")
        self.tabs.addTab(self.make_note_tab(), "安全记事本")
        self.tabs.addTab(self.make_crypto_tab(), "加密货币")
        self.make_toolbar()
        self.setup_context_menus()
        main = QWidget()
        layout = QVBoxLayout(main)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        top_card = QFrame()
        top_card.setObjectName("TopCard")
        top_layout = QHBoxLayout(top_card)
        top_layout.setContentsMargins(10, 8, 10, 8)
        top_layout.setSpacing(8)
        search_label = QLabel("查询")
        search_label.setObjectName("SearchLabel")
        search_label.setMinimumWidth(86)
        search_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        top_layout.addWidget(search_label)
        top_layout.addWidget(self.search_mode)
        top_layout.addWidget(self.search_edit, 1)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        top_layout.addWidget(self.status_label)
        layout.addWidget(top_card)
        layout.addWidget(self.tabs, 1)
        self.setCentralWidget(main)
        self.password_table.itemClicked.connect(self.show_clicked_password_detail)
        self.note_table.itemClicked.connect(self.show_clicked_note_detail)
        self.password_table.doubleClicked.connect(self.edit_password)
        self.note_table.doubleClicked.connect(self.edit_note)
        self.auto_lock_timer = QTimer(self)
        self.auto_lock_timer.setSingleShot(True)
        self.auto_lock_timer.setInterval(AUTO_LOCK_TIMEOUT_MS)
        self.auto_lock_timer.timeout.connect(self.handle_auto_lock)
        application = QApplication.instance()
        if application is not None:
            application.installEventFilter(self)
        self.auto_lock_timer.start()
        self.refresh_all()

    def eventFilter(self, watched, event):
        activity_events = {
            QEvent.Type.KeyPress,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonDblClick,
            QEvent.Type.Wheel,
            QEvent.Type.TouchBegin,
        }
        if (
            event.type() in activity_events
            and self.isVisible()
            and not self._lock_in_progress
        ):
            self.auto_lock_timer.start()
        return super().eventFilter(watched, event)

    def search_mode_changed(self, *_args):
        if self.search_mode.currentIndex() == 1:
            self.search_edit.setPlaceholderText("正则搜索，例如：账号|邮箱")
        else:
            self.search_edit.setPlaceholderText(
                "最长公共子序列搜索（忽略大小写）；* 为通配符，例如：开头*结尾"
            )
        self.apply_filter()

    def handle_auto_lock(self):
        active_modal = QApplication.activeModalWidget()
        if active_modal is not None:
            # 不在用户尚未保存的模态编辑窗口上强制锁定；一分钟后重试。
            self.auto_lock_timer.start(60_000)
            return
        self.lock_and_exit(auto_locked=True)

    def enable_windows_screen_capture_protection(self):
        protect_widget_from_capture(self)
    def make_toolbar(self):
        toolbar = QToolBar("主工具栏")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        save_action = QAction("保存", self)
        save_action.triggered.connect(self.force_save)
        toolbar.addAction(save_action)
        change_master_action = QAction("修改主密码", self)
        change_master_action.triggered.connect(self.change_master_password)
        toolbar.addAction(change_master_action)
        lock_action = QAction("锁定退出", self)
        lock_action.triggered.connect(self.lock_and_exit)
        toolbar.addAction(lock_action)
        toolbar.addSeparator()
        info_action = QAction("信息", self)
        info_action.triggered.connect(self.show_database_info)
        toolbar.addAction(info_action)
        donate_action = QAction("赞助", self)
        donate_action.triggered.connect(self.show_donation)
        toolbar.addAction(donate_action)
        security_action = QAction("安全", self)
        security_action.triggered.connect(self.show_security_notes)
        toolbar.addAction(security_action)
    def make_table(self, headers: List[str]) -> QTableWidget:
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.setAlternatingRowColors(True)
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        return table
    def make_password_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.password_splitter.addWidget(self.password_table)
        self.password_splitter.addWidget(self.password_detail)
        self.password_splitter.setSizes([1240, 0])
        layout.addWidget(self.password_splitter, 1)
        return page
    def make_note_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.note_splitter.addWidget(self.note_table)
        self.note_splitter.addWidget(self.note_detail)
        self.note_splitter.setSizes([1240, 0])
        layout.addWidget(self.note_splitter, 1)
        return page
    def make_crypto_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        title_label = QLabel("加密货币钱包生成与保存")
        title_label.setObjectName("CardTitle")
        description_label = QLabel(
            "生成 BIP39 24词助记词，并按附件规则生成 5 个 BTC BIP84 地址和 "
            "5 个 ETH BIP44 地址；地址索引均为硬化索引。"
        )
        description_label.setObjectName("SubtleLabel")
        description_label.setWordWrap(True)

        warning_label = QLabel(
            "助记词、seed 和私钥均属于敏感信息。点击保存后，会作为密码条目写入当前加密数据库。"
            "附件使用硬化地址索引，恢复钱包时必须使用结果中记录的完全相同路径。"
        )
        warning_label.setWordWrap(True)

        self.crypto_generate_button = QPushButton("生成新钱包")
        self.crypto_generate_button.setObjectName("PrimaryButton")
        self.crypto_save_button = QPushButton("保存到密码管理器")
        self.crypto_save_button.setObjectName("SecondaryButton")
        self.crypto_save_button.setEnabled(False)
        self.crypto_clear_button = QPushButton("清空结果")
        self.crypto_generate_button.clicked.connect(self.generate_crypto_wallet)
        self.crypto_save_button.clicked.connect(
            self.save_crypto_wallet_to_password_manager
        )
        self.crypto_clear_button.clicked.connect(self.clear_crypto_wallet_result)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        button_layout.addWidget(self.crypto_generate_button)
        button_layout.addWidget(self.crypto_save_button)
        button_layout.addWidget(self.crypto_clear_button)
        button_layout.addStretch(1)

        self.crypto_status_label = QLabel("尚未生成钱包。")
        self.crypto_status_label.setObjectName("SubtleLabel")
        button_layout.addWidget(self.crypto_status_label)

        self.crypto_output = QPlainTextEdit()
        self.crypto_output.setReadOnly(True)
        self.crypto_output.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.crypto_output.setPlaceholderText("生成结果会显示在这里。")
        crypto_font = QFont("Consolas")
        crypto_font.setStyleHint(QFont.StyleHint.Monospace)
        self.crypto_output.setFont(crypto_font)

        layout.addWidget(title_label)
        layout.addWidget(description_label)
        layout.addWidget(warning_label)
        layout.addLayout(button_layout)
        layout.addWidget(self.crypto_output, 1)
        return page
    def run_vault_operation(
        self,
        error_title: str,
        operation: Callable[[], Any],
    ) -> bool:
        succeeded, _result = run_ui_operation(self, error_title, operation)
        if succeeded:
            self.refresh_all()
        return succeeded
    def generate_crypto_wallet(self, *_args):
        self.clear_crypto_wallet_result()
        succeeded, wallet_bundle = run_ui_operation(
            self,
            "生成失败",
            lambda: run_with_progress(
                self,
                "正在生成加密货币钱包",
                "正在生成助记词、seed、BTC 和 ETH 密钥，请稍候……",
                lambda: generate_crypto_wallet_bundle(CRYPTO_ADDRESS_COUNT),
            ),
        )
        if not succeeded:
            return

        self.crypto_wallet_result = wallet_bundle
        self.crypto_output.setPlainText(format_crypto_wallet_bundle(wallet_bundle))
        self.crypto_save_button.setEnabled(True)
        self.crypto_status_label.setText(
            f"生成时间：{readable_time(wallet_bundle.get('generated_at', ''))}"
        )

    def save_crypto_wallet_to_password_manager(self, *_args):
        if not self.crypto_wallet_result:
            QMessageBox.information(self, "尚未生成", "请先生成一个加密货币钱包。")
            return
        # 助记词写入密码字段，完整派生信息和生成时间写入备注字段。
        item = build_crypto_password_item(self.crypto_wallet_result)
        saved = self.run_vault_operation(
            "保存失败",
            lambda: self.vault.upsert_item(item),
        )
        item.clear()
        if not saved:
            return
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText(
            self.crypto_status_label.text() + " · 已保存到密码管理器"
        )
        QMessageBox.information(
            self,
            "已保存",
            "钱包已保存到密码管理器；助记词位于密码字段，完整信息和生成时间位于备注字段。",
        )

    def clear_crypto_wallet_result(self, *_args):
        self.crypto_output.clear()
        if isinstance(self.crypto_wallet_result, dict):
            for value in self.crypto_wallet_result.values():
                if isinstance(value, list):
                    for entry in value:
                        if isinstance(entry, dict):
                            entry.clear()
                    value.clear()
            self.crypto_wallet_result.clear()
        self.crypto_wallet_result = None
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText("尚未生成钱包。")
    def setup_context_menus(self):
        self.password_table.customContextMenuRequested.connect(self.show_password_context_menu)
        self.note_table.customContextMenuRequested.connect(self.show_note_context_menu)
    def show_password_context_menu(self, position: QPoint):
        item = self.password_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("新增密码")
            action = menu.exec(self.password_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_password()
            return
        self.password_table.selectRow(item.row())
        add_action = menu.addAction("新增密码")
        edit_action = menu.addAction("编辑")
        delete_action = menu.addAction("删除")
        menu.addSeparator()
        copy_user_action = menu.addAction("复制用户名")
        copy_pass_action = menu.addAction("复制密码")
        action = menu.exec(self.password_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_password()
        elif action == edit_action:
            self.edit_password()
        elif action == delete_action:
            self.delete_password()
        elif action == copy_user_action:
            self.copy_username()
        elif action == copy_pass_action:
            self.copy_password()
    def show_note_context_menu(self, position: QPoint):
        item = self.note_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("新增笔记")
            action = menu.exec(self.note_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_note()
            return
        self.note_table.selectRow(item.row())
        add_action = menu.addAction("新增笔记")
        edit_action = menu.addAction("打开/编辑")
        delete_action = menu.addAction("删除")
        action = menu.exec(self.note_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_note()
        elif action == edit_action:
            self.edit_note()
        elif action == delete_action:
            self.delete_note()
    def refresh_all(self):
        self.password_items_all = sorted(
            self.vault.all_items("password"),
            key=self.password_sort_key,
        )
        self.note_items_all = sorted(
            self.vault.all_items("note"),
            key=self.note_sort_key,
        )
        self.apply_filter()
    def password_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        username_value = str(item.get("username", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, username_value, updated_value)
    def note_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, updated_value)
    def apply_filter(self, *_args):
        # 搜索始终使用完整字段，不受左侧表格预览截断影响。
        keyword = self.search_edit.text().strip()
        regex_mode = self.search_mode.currentIndex() == 1
        self.search_edit.setProperty("searchError", False)
        self.search_edit.style().unpolish(self.search_edit)
        self.search_edit.style().polish(self.search_edit)

        if not keyword:
            self.password_items_view = list(self.password_items_all)
            self.note_items_view = list(self.note_items_all)
        elif regex_mode:
            try:
                compiled_pattern = compile_search_regex(keyword)
            except ValueError as error:
                self.password_items_view = []
                self.note_items_view = []
                self.search_edit.setProperty("searchError", True)
                self.search_edit.style().unpolish(self.search_edit)
                self.search_edit.style().polish(self.search_edit)
                self.status_label.setText(str(error))
                self.refresh_password_table()
                self.refresh_note_table()
                self.hide_details()
                return

            def regex_matches(values: List[Any]) -> bool:
                searchable_text = "\n".join(
                    str(value or "") for value in values
                )[:MAX_SEARCH_TEXT_LENGTH]
                return compiled_pattern.search(searchable_text) is not None

            self.password_items_view = [
                item for item in self.password_items_all
                if regex_matches([
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if regex_matches(
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")]
                )
            ]
        else:
            self.password_items_view = [
                item for item in self.password_items_all
                if lcs_or_wildcard_item_match(keyword, [
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if lcs_or_wildcard_item_match(
                    keyword,
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")],
                )
            ]

        self.refresh_password_table()
        self.refresh_note_table()
        self.hide_details()
        mode_label = "正则" if regex_mode else "LCS/通配符"
        self.status_label.setText(
            f"密码 {len(self.password_items_view)}/{len(self.password_items_all)} · "
            f"笔记 {len(self.note_items_view)}/{len(self.note_items_all)} · "
            f"{mode_label}搜索 · 5 分钟自动锁定"
        )
    def hide_details(self):
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter.setSizes([1240, 0])
        self.note_splitter.setSizes([1240, 0])
    def refresh_password_table(self):
        self.password_table.setRowCount(0)
        for item in self.password_items_view:
            row = self.password_table.rowCount()
            self.password_table.insertRow(row)
            # 限制表格文字长度，避免 Qt 用超长备注撑大内容宽度。
            values = [
                table_text_preview(item.get("title", ""), 80),
                table_text_preview(item.get("username", ""), 80),
                table_text_preview(item.get("notes", "")),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.password_table.setItem(row, column, cell)
    def refresh_note_table(self):
        self.note_table.setRowCount(0)
        for item in self.note_items_view:
            row = self.note_table.rowCount()
            self.note_table.insertRow(row)
            values = [
                item.get("title", ""),
                str(len(item.get("comments", []))),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.note_table.setItem(row, column, cell)
    def selected_password(self) -> Optional[Dict[str, Any]]:
        row = self.password_table.currentRow()
        if row < 0 or row >= len(self.password_items_view):
            return None
        return self.password_items_view[row]
    def selected_note(self) -> Optional[Dict[str, Any]]:
        row = self.note_table.currentRow()
        if row < 0 or row >= len(self.note_items_view):
            return None
        return self.note_items_view[row]
    def show_clicked_password_detail(self, *_args):
        item = self.selected_password()
        if item:
            detail_was_hidden = self.password_detail.isHidden()
            self.password_detail.show_password_item(item)
            self.password_detail.show()
            # 只在首次展开时设置默认比例，之后保留用户拖动的位置。
            if detail_was_hidden:
                self.reveal_detail_panel(self.password_splitter)
    def show_clicked_note_detail(self, *_args):
        item = self.selected_note()
        if item:
            detail_was_hidden = self.note_detail.isHidden()
            self.note_detail.show_note_item(item)
            self.note_detail.show()
            if detail_was_hidden:
                self.reveal_detail_panel(self.note_splitter)
    @staticmethod
    def reveal_detail_panel(splitter: QSplitter) -> None:
        current_sizes = splitter.sizes()
        total_width = max(sum(current_sizes), splitter.width(), 800)
        detail_width = min(360, max(260, total_width // 3))
        splitter.setSizes([total_width - detail_width, detail_width])
    def require_password_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_password()
        if item is None:
            QMessageBox.information(self, "请选择记录", "请先选择一条密码记录。")
        return item
    def require_note_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_note()
        if item is None:
            QMessageBox.information(self, "请选择记录", "请先选择一条笔记。")
        return item
    def add_password(self):
        item = PasswordDialog(parent=self).get_item()
        if item:
            self.run_vault_operation(
                "保存失败",
                lambda: self.vault.upsert_item(item),
            )
    def edit_password(self, *_args):
        item = self.require_password_selection()
        if not item:
            return
        updated = PasswordDialog(item=item, parent=self).get_item()
        if updated:
            self.run_vault_operation(
                "保存失败",
                lambda: self.vault.upsert_item(updated),
            )
    def delete_password(self):
        item = self.require_password_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "确认删除", f"确定删除“{item.get('title', '')}”？")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "删除失败",
                lambda: self.vault.delete_item(item["id"]),
            )
    def copy_username(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("username", ""), "用户名已复制。")
    def copy_password(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("password", ""), "密码已复制，30 秒后自动清空剪贴板。", auto_clear=True)
    def copy_to_clipboard(self, text: str, message: str, auto_clear: bool = False):
        QApplication.clipboard().setText(text)
        expected_digest = hashlib.sha256(text.encode("utf-8")).digest()
        self.managed_clipboard_digest = expected_digest
        QMessageBox.information(self, "已复制", message)
        if auto_clear:
            # 定时器闭包中只保留摘要，不保留明文密码。
            def clear_clipboard(digest=expected_digest):
                current_text = QApplication.clipboard().text()
                current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
                if secrets.compare_digest(current_digest, digest):
                    QApplication.clipboard().clear()
                    if self.managed_clipboard_digest == digest:
                        self.managed_clipboard_digest = None
                current_text = ""
            QTimer.singleShot(30_000, clear_clipboard)

    def clear_managed_clipboard(self):
        digest = self.managed_clipboard_digest
        if digest is None:
            return
        current_text = QApplication.clipboard().text()
        current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
        if secrets.compare_digest(current_digest, digest):
            QApplication.clipboard().clear()
        current_text = ""
        self.managed_clipboard_digest = None

    def save_note_from_dialog(self, item: Dict[str, Any]):
        self.vault.upsert_item(item)
        self.refresh_all()

    def add_note(self):
        NoteDialog(
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()

    def edit_note(self, *_args):
        item = self.require_note_selection()
        if not item:
            return
        NoteDialog(
            item=item,
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()
    def delete_note(self):
        item = self.require_note_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "确认删除", f"确定删除“{item.get('title', '')}”？")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "删除失败",
                lambda: self.vault.delete_item(item["id"]),
            )
    def force_save(self):
        if self.run_vault_operation("保存失败", self.vault.save):
            QMessageBox.information(self, "已保存", "数据库已保存。")
    def change_master_password(self):
        new_password = MasterPasswordDialog(parent=self).get_password()
        if new_password:
            succeeded, _result = run_ui_operation(
                self,
                "修改失败",
                lambda: run_with_progress(
                    self,
                    "正在修改主密码",
                    "正在重新派生密钥并加密数据库，请稍候……",
                    lambda: self.vault.change_master_password(new_password),
                ),
            )
            new_password = ""
            if succeeded:
                QMessageBox.information(self, "已修改", "主密码已修改，数据库已用新密钥重新加密保存。")
    def clear_sensitive_ui(self):
        self.clear_crypto_wallet_result()
        self.password_items_all.clear()
        self.password_items_view.clear()
        self.note_items_all.clear()
        self.note_items_view.clear()
        self.password_table.clearContents()
        self.password_table.setRowCount(0)
        self.note_table.clearContents()
        self.note_table.setRowCount(0)
        self.password_detail.show_password_item(None)
        self.note_detail.show_note_item(None)
        self.password_detail.hide()
        self.note_detail.hide()
        self.search_edit.clear()
        self.clear_managed_clipboard()
    def closeEvent(self, event):
        try:
            self.auto_lock_timer.stop()
            application = QApplication.instance()
            if application is not None:
                application.removeEventFilter(self)
            self.clear_sensitive_ui()
            self.vault.lock()
        finally:
            super().closeEvent(event)
    def lock_and_exit(self, auto_locked: bool = False):
        if self._lock_in_progress:
            return
        self._lock_in_progress = True
        self.auto_lock_timer.stop()
        try:
            self.clear_sensitive_ui()
            self.vault.lock()
            self.hide()
            reopened_vault = bootstrap_vault(parent=None)
            if reopened_vault is None:
                self.close()
                return
            self.vault = reopened_vault
            self.setWindowTitle(f"{APP_NAME} - {self.vault.path}")
            self.refresh_all()
            if auto_locked:
                self.status_label.setText(
                    self.status_label.text() + " · 已完成自动锁定重新认证"
                )
            self.show()
            self.enable_windows_screen_capture_protection()
            self.auto_lock_timer.start()
        finally:
            self._lock_in_progress = False
    def show_database_info(self):
        message = (
            f"程序：{APP_NAME} {APP_VERSION}\n"
            f"文件：{self.vault.path}\n"
            f"算法：Argon2id + ChaCha20-Poly1305\n"
            f"Argon2id：iterations={self.vault.kdf_params.get('iterations')}，lanes={self.vault.kdf_params.get('lanes')}，memory={self.vault.kdf_params.get('memory_cost')} KiB\n"
            f"自动锁定：无操作 5 分钟\n"
            f"密码条目：{len(self.password_items_all)}\n"
            f"安全笔记：{len(self.note_items_all)}"
        )
        QMessageBox.information(self, "数据库信息", message)
    def show_donation(self):
        message = (
            f"如果这个项目对你有帮助，可以支持作者。\n\n"
            f"Bitcoin：{DONATION_BTC}\n"
            f"Ethereum：{DONATION_ETH}\n"
            f"BNB Smart Chain：{DONATION_BNB}"
        )
        QMessageBox.information(self, "赞助作者", message)
    def show_security_notes(self):
        message = (
            "CipherNote Vault 使用 Argon2id 从主密码派生 256-bit 密钥，并使用 ChaCha20-Poly1305 对整个数据库进行认证加密。\n\n"
            "密码条目和安全笔记都在同一个加密 payload 内，磁盘数据库文件只保存 salt、nonce、KDF 参数和密文。\n\n"
            "保存时使用独立临时文件、文件同步和原子替换；若检测到其他实例已经修改数据库，会取消保存以避免覆盖。\n\n"
            "无操作 5 分钟后自动锁定；存在尚未处理的模态编辑窗口时会延后重试。\n\n"
            "Windows 下主窗口和敏感对话框都会尝试启用 SetWindowDisplayAffinity 防普通截图/录屏捕获。\n\n"
            "导入的外部文本只有在点击保存成功后才会进入加密数据库。\n\n"
            "安全边界：本程序不能防御已经控制本机的恶意软件、手机拍照、管理员权限截屏、键盘记录、剪贴板监听或内存转储。建议配合系统磁盘加密使用。"
        )
        QMessageBox.information(self, "安全说明", message)
#------ 应用样式与启动 ------
def set_app_style(application: QApplication):
    application.setStyleSheet("""
        QWidget {
            font-family: "Microsoft YaHei", "Segoe UI", "PingFang SC", sans-serif;
            font-size: 16px;
            color: #FFF700;
            background-color: #8A1F00;
        }
        Q主工具栏Window, QDialog {
            background-color: #8A1F00;
        }
        QLineEdit, QPlainTextEdit, QTableWidget {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 10px;
            padding: 9px;
            selection-background-color: #FFD700;
            selection-color: #FF0000;
        }
        QLineEdit#主工具栏SearchInput {
            padding: 2px 8px;
            border-radius: 6px;
        }
        QLineEdit[searchError="true"] { border: 2px solid #FF0000; }
        QPlainTextEdit { line-height: 1.5em; }
        QTableWidget {
            gridline-color: #9A3400;
            alternate-background-color: #7C1D00;
            border-radius: 12px;
        }
        QTableWidget::item { padding: 8px; }
        QTableWidget::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QSplitter::handle:horizontal {
            background-color: #C86F00;
            margin: 3px 2px;
            border-radius: 3px;
        }
        QSplitter::handle:horizontal:hover,
        QSplitter::handle:horizontal:pressed {
            background-color: #FFD700;
        }
        QHeaderView::section {
            background-color: #5F1700;
            color: #FDE600;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #C86F00;
            font-weight: 700;
        }
        QRadioButton#ModeRadio:checked {
            background-color: rgb(0, 200, 0);
        }
        QPushButton {
            background-color: #E9C400;
            color: #4A1200;
            border: 1px solid #F6D900;
            border-radius: 10px;
            padding: 9px 14px;
            font-weight: 800;
        }
        QPushButton:hover { background-color: #F3D500; }
        QPushButton:pressed { background-color: #D9A400; }
        QPushButton:disabled {
            background-color: #9CA300;
            color: #5F1700;
        }
        QPushButton#PrimaryButton {
            background-color: #F1C900;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton {
            background-color: #D89C00;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton:hover { background-color: #E8B900; }
        QTabWidget::pane {
            border: 1px solid #C86F00;
            border-radius: 12px;
            top: -1px;
            background-color: #8A1F00;
        }
        QTabBar::tab {
            background-color: #6F1A00;
            color: #FDE600;
            padding: 7px 14px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-right: 1px;
            font-weight: 700;
        }
        QTabBar::tab:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QToolBar {
            background-color: #5A1500;
            border: none;
            spacing: 6px;
            padding: 6px;
        }
        QToolButton {
            color: #FDE600;
            background-color: #6F1A00;
            border-radius: 8px;
            padding: 7px 9px;
        }
        QToolButton:hover { background-color: #9A3400; }
        QMenu {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #E9C400;
            padding: 6px;
        }
        QMenu::item {
            padding: 8px 28px;
            border-radius: 6px;
        }
        QMenu::item:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QSlider::groove:horizontal {
            height: 6px;
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 3px;
        }
        QSlider::handle:horizontal {
            width: 16px;
            margin: -6px 0;
            border-radius: 8px;
            background-color: #E9C400;
            border: 1px solid #F6D900;
        }
        QSlider::sub-page:horizontal {
            background-color: #E9C400;
            border-radius: 3px;
        }
        QSpinBox, QCheckBox {
            color: #FFF700;
            background-color: #6F1A00;
        }
        QLabel#DialogTitle {
            font-size: 30px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#CardTitle {
            font-size: 22px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#SectionTitle {
            font-size: 18px;
            font-weight: 800;
            color: #FFF700;
        }
        QLabel#SubtleLabel { color: #FDE600; }
        QPlainTextEdit#BodyLabel {
            color: #FFF700;
            background-color: #6F1A00;
            border: none;
            border-radius: 10px;
            padding: 12px;
        }
        QLabel#SearchLabel {
            font-weight: 800;
            color: #FDE600;
        }
        QFrame#Card {
            background-color: #6F1A00;
            border: 1px solid #C86F00;
            border-radius: 16px;
            padding: 12px;
        }
        QFrame#TopCard {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 14px;
            padding: 8px;
        }
        QFrame#InlineSearch {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 10px;
        }
        QFrame#CommentsPanel {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 12px;
        }
        QListWidget#CommentList {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 8px;
            padding: 4px;
        }
        QListWidget#CommentList::item {
            padding: 8px;
            border-bottom: 1px solid #9A3400;
        }
        QListWidget#CommentList::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QMessageBox QLabel { color: #FFF700; }
    """)
def bootstrap_vault(parent=None) -> Optional[Vault]:
    for _ in range(3):
        dialog = StartupDialog(parent=parent)
        result = dialog.get_result()
        if result is None:
            return None
        vault = Vault(result["path"])
        master_password = result.pop("password")
        try:
            if result["mode"] == "create":
                operation = lambda: run_with_progress(
                    parent,
                    "正在创建数据库",
                    "正在派生加密密钥并创建数据库，请稍候……",
                    lambda: vault.create(master_password),
                )
            else:
                operation = lambda: run_with_progress(
                    parent,
                    "正在打开数据库",
                    "正在验证主密码并解密数据库，请稍候……",
                    lambda: vault.unlock(master_password),
                )
            succeeded, _result = run_ui_operation(
                parent,
                "数据库打开失败",
                operation,
            )
        finally:
            master_password = ""
            result.clear()
        if succeeded:
            return vault
    return None
def main():
    application = QApplication(sys.argv)
    application.setApplicationName(APP_NAME)
    set_app_style(application)
    vault = bootstrap_vault()
    if vault is None:
        return 1
    window = MainWindow(vault)
    window.show()
    window.enable_windows_screen_capture_protection()
    return application.exec()
if __name__ == "__main__":
    raise SystemExit(main())
