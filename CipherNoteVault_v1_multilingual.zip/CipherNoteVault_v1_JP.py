"""CipherNote Vault はローカルで動作する暗号化パスワード管理・セキュアノートアプリです。Argon2id で鍵を導出し、ChaCha20-Poly1305 でデータベース全体を認証暗号化します。データは既定で、ユーザーが選択したローカルデータベースファイルにのみ保存されます。"""
# SPDX-License-Identifier: GPL-3.0-only
# CipherNote Vault
# Copyright (C) 2026 Wang Yifan
#
# 本プログラムは自由ソフトウェアです。次のライセンス条件に従って再配布または変更できます：
# フリーソフトウェア財団が公開した GNU 一般公衆利用許諾書
# バージョン3を適用します。
import base64
import copy
import ctypes
import hashlib
import json
import os
import platform
import re
import secrets
import string
import sys
import uuid
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Pattern, Tuple
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from bip_utils import (
    Bip32Secp256k1,
    Bip39MnemonicGenerator,
    Bip39SeedGenerator,
    Bip39WordsNum,
    EthAddrEncoder,
    P2WPKHAddrEncoder,
    WifEncoder,
)
try:
    from charset_normalizer import from_bytes
except ImportError:  # テキストのインポートでは明確な案内を表示し、その他の機能は引き続き使用できます。
    from_bytes = None
from PyQt6.QtCore import QEvent, QPoint, QThread, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QKeySequence, QShortcut, QTextCursor, QTextOption
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QRadioButton,
    QPushButton,
    QPlainTextEdit,
    QProgressDialog,
    QSplitter,
    QSlider,
    QSizePolicy,
    QSpinBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)
#------ アプリ設定 ------
APP_NAME = "CipherNote Vault"
APP_VERSION = "1.0.0"
VAULT_FORMAT = "CipherNote Vault Database"
VAULT_VERSION = 1
DEFAULT_VAULT_DIR = Path.home() / ".ciphernote_vault"
DEFAULT_VAULT = DEFAULT_VAULT_DIR / "vault.cnvault"
ARGON2ID_PARAMS = {
    "name": "Argon2id",
    "length": 32,
    "iterations": 3,
    "lanes": 4,
    "memory_cost": 64 * 1024,
}
# 信頼できないデータベースのメタデータが無制限の処理を要求できないようにします。
MAX_VAULT_FILE_SIZE = 256 * 1024 * 1024
MAX_ARGON2_ITERATIONS = 8
MAX_ARGON2_LANES = 16
MAX_ARGON2_MEMORY_KIB = 512 * 1024
MIN_SALT_LENGTH = 16
MAX_SALT_LENGTH = 64
CHACHA20_POLY1305_NONCE_LENGTH = 12
POLY1305_TAG_LENGTH = 16
DEFAULT_GENERATED_PASSWORD_LENGTH = 32
MAX_GENERATED_PASSWORD_LENGTH = 4096
PASSWORD_SYMBOLS = "!@#$%^&*()-_=+[]{}:,.?"
CRYPTO_ADDRESS_COUNT = 5
CRYPTO_BIP39_PASSPHRASE = ""
AUTO_LOCK_TIMEOUT_MS = 5 * 60 * 1000
MAX_SEARCH_TEXT_LENGTH = 200_000
MAX_REGEX_PATTERN_LENGTH = 256
MAX_TEXT_IMPORT_SIZE = 16 * 1024 * 1024
MAX_ITEM_COUNT = 100_000
MAX_COMMENT_COUNT = 10_000
MAX_TEXT_FIELD_LENGTH = 32 * 1024 * 1024
DONATION_BTC = "bc1qxqfhumpqtnxrznkx9r4xsp8m6zsedtgusjns7p"
DONATION_ETH = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
DONATION_BNB = "0x2d92f9e4d8ac7effa9cd7cd5eccd364cac7c201b"
WINDOWS_DISPLAY_AFFINITY_NONE = 0x00000000
WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE = 0x00000011
WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY = 0x00000001
#------ 共通ユーティリティ ------
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
def readable_time(value: str) -> str:
    if not value:
        return ""
    return value.replace("T", " ").replace("+00:00", " UTC")

def table_text_preview(value: Any, maximum_length: int = 120) -> str:
    # 表には短いプレビューだけを表示し、検索と詳細表示では全文を使用します。
    preview = " ".join(str(value or "").split())
    if len(preview) <= maximum_length:
        return preview
    return preview[: maximum_length - 1].rstrip() + "…"

def remove_extra_blank_lines(text: str) -> str:
    """改行コードを統一し、行末の空白を削除して、連続する空行を1行にまとめます。"""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned_lines: List[str] = []
    previous_was_blank = True
    for raw_line in normalized.split("\n"):
        line = raw_line.rstrip()
        is_blank = not line.strip()
        if is_blank:
            if cleaned_lines and not previous_was_blank:
                cleaned_lines.append("")
        else:
            cleaned_lines.append(line)
        previous_was_blank = is_blank
    while cleaned_lines and cleaned_lines[-1] == "":
        cleaned_lines.pop()
    return "\n".join(cleaned_lines)

def python_index_to_qt_position(text: str, index: int) -> int:
    """Python の Unicode インデックスを QTextCursor が使用する UTF-16 位置に変換します。"""
    safe_index = min(max(index, 0), len(text))
    return len(text[:safe_index].encode("utf-16-le")) // 2

def qt_position_to_python_index(text: str, position: int) -> int:
    safe_position = max(position, 0) * 2
    prefix = text.encode("utf-16-le")[:safe_position]
    return len(prefix.decode("utf-16-le", errors="ignore"))

def text_readability_score(text: str) -> float:
    common_cjk = set(
        "\u7684\u4e00\u662f\u4e0d\u4e86\u4eba\u6211\u5728\u6709\u4ed6\u8fd9\u70ba\u4e3a\u4e4b\u5927\u6765\u4f86\u4ee5\u4e2a\u500b\u4e2d\u4e0a\u5011\u4eec\u5230\u8aaa\u8bf4\u570b\u56fd\u548c\u5730\u4e5f\u5b50\u6642\u65f6\u9053\u51fa"
        "\u800c\u8981\u65bc\u4e8e\u5c31\u4e0b\u5f97\u53ef\u4f60\u5e74\u751f\u81ea\u6703\u4f1a\u90a3\u5f8c\u540e\u80fd\u5c0d\u5bf9\u8457\u7740\u4e8b\u5176\u88e1\u91cc\u6240\u53bb\u884c\u904e\u8fc7\u5bb6\u5341\u7528\u767c\u53d1"
        "\u5929\u5982\u7136\u4f5c\u65b9\u6210\u8005\u591a\u65e5\u90fd\u4e09\u5c0f\u4e8c\u7121\u65e0\u540c\u7d93\u7ecf\u6cd5\u7576\u5f53\u8d77\u8207\u4e0e\u597d\u770b\u5b78\u5b66\u9032\u8fdb\u7a2e\u79cd\u5c07\u5c06\u9084\u8fd8"
        "\u5206\u6b64\u5fc3\u524d\u9762\u53c8\u5b9a\u898b\u89c1\u53ea\u4e3b\u6c92\u6ca1\u516c\u5f9e\u4ece\u660e\u554f\u95ee\u529b\u9593\u95f4\u610f\u5916\u6b63\u628a\u60c5\u6700\u91cd\u6587\u672c\u6e2c\u6d4b\u8bd5\u8a66"
        "\u4e2d\u6587\u7b46\u7b14\u8a18\u8bb0\u5bc6\u78bc\u5bc6\u7801\u5e33\u8d26\u53f7\u865f\u5c0e\u5bfc\u5165\u7de8\u7f16\u7801\u78bc\u5b89\u5168\u4fdd\u5b58\u641c\u7d22\u641c\u5c0b\u65e5\u672c\u8a9e"
    )
    score = 0.0
    for character in text:
        codepoint = ord(character)
        if character == "\ufffd" or (codepoint < 32 and character not in "\n\r\t"):
            score -= 12.0
        elif character in common_cjk:
            score += 2.0
        elif 0x3040 <= codepoint <= 0x30FF:
            score += 2.0
        elif 0x4E00 <= codepoint <= 0x9FFF:
            score += 0.15
        elif 0xFF61 <= codepoint <= 0xFF9F:
            score -= 0.8
        elif character.isprintable():
            score += 0.05
    return score

def decode_imported_text(data: bytes) -> Tuple[str, str, float]:
    """charset_normalizer.from_bytes で外部テキストの文字コードを自動判定します。"""
    if not data:
        return "", "utf-8", 100.0
    if from_bytes is None:
        raise RuntimeError("charset-normalizer がありません。先に次を実行してください：pip install charset-normalizer")
    matches = from_bytes(data)
    best_match = matches.best()
    if best_match is None:
        raise ValueError("テキストファイルの文字コードを判定できませんでした。")
    encoding = best_match.encoding or "unknown"
    coherence = float(getattr(best_match, "percent_coherence", 0.0) or 0.0)
    best_text = str(best_match)
    if coherence >= 10.0:
        return best_text, encoding, coherence

    # 非常に短い中国語・日本語・韓国語のテキストには、複数の有効な復号候補が存在する場合があります。
    # まず from_bytes を使用し、信頼度が低い場合は一般的な候補を少数比較して、短い GB18030 中国語を Big5 と誤判定しないようにします。
    candidates = {encoding: best_text}
    for candidate_encoding in ("utf-8-sig", "gb18030", "big5", "shift_jis"):
        with suppress(UnicodeDecodeError, LookupError):
            candidates[candidate_encoding] = data.decode(candidate_encoding)
    selected_encoding, selected_text = max(
        candidates.items(),
        key=lambda pair: (
            text_readability_score(pair[1]),
            pair[0] == encoding,
        ),
    )
    return selected_text, selected_encoding, coherence

def read_imported_text_file(path: Path) -> Tuple[str, str, float]:
    if path.stat().st_size > MAX_TEXT_IMPORT_SIZE:
        raise ValueError(
            f"テキストファイルの上限は {MAX_TEXT_IMPORT_SIZE // (1024 * 1024)} MiB。"
        )
    return decode_imported_text(path.read_bytes())

def longest_common_subsequence_score(first_text: str, second_text: Any) -> int:
    """ビット並列アルゴリズムで、大文字と小文字を区別しない最長共通部分列の長さを計算します。"""
    first = str(first_text or "").casefold()
    second = str(second_text or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    if not first or not second:
        return 0
    character_masks: Dict[str, int] = {}
    for index, character in enumerate(first):
        character_masks[character] = (
            character_masks.get(character, 0) | (1 << index)
        )
    lcs_row = 0
    for character in second:
        matches = character_masks.get(character, 0)
        combined = matches | lcs_row
        lcs_row = combined & ~(combined - ((lcs_row << 1) | 1))
    return lcs_row.bit_count()

def longest_common_subsequence_match(keyword: str, text_value: Any) -> bool:
    """keyword の全文字が LCS に含まれる場合に一致とみなします。"""
    folded_keyword = str(keyword or "").casefold()
    if not folded_keyword:
        return True
    return (
        longest_common_subsequence_score(folded_keyword, text_value)
        == len(folded_keyword)
    )

def wildcard_search_match(pattern: str, text_value: Any) -> bool:
    """アスタリスクは任意の長さの内容を表し、各テキスト断片は入力順に出現する必要があります。"""
    folded_pattern = str(pattern or "").casefold()
    text = str(text_value or "").casefold()[:MAX_SEARCH_TEXT_LENGTH]
    fragments = [fragment for fragment in folded_pattern.split("*") if fragment]
    if not fragments:
        return True
    search_position = 0
    for fragment in fragments:
        fragment_position = text.find(fragment, search_position)
        if fragment_position < 0:
            return False
        search_position = fragment_position + len(fragment)
    return True

def lcs_or_wildcard_item_match(keyword: str, values: List[Any]) -> bool:
    searchable_text = "\n".join(str(value or "") for value in values)
    if "*" in keyword:
        return wildcard_search_match(keyword, searchable_text)
    return longest_common_subsequence_match(keyword, searchable_text)

def compile_search_regex(pattern_text: str) -> Pattern[str]:
    if len(pattern_text) > MAX_REGEX_PATTERN_LENGTH:
        raise ValueError(f"正規表現の上限は {MAX_REGEX_PATTERN_LENGTH} 文字です。")
    try:
        return re.compile(pattern_text, re.IGNORECASE | re.UNICODE)
    except re.error as error:
        raise ValueError(f"正規表現が無効です：{error}") from error

def protect_widget_from_capture(widget: QWidget) -> None:
    if platform.system() != "Windows":
        return
    with suppress(Exception):
        window_handle = int(widget.winId())
        result = ctypes.windll.user32.SetWindowDisplayAffinity(
            window_handle,
            WINDOWS_DISPLAY_AFFINITY_EXCLUDE_FROM_CAPTURE,
        )
        if result == 0:
            ctypes.windll.user32.SetWindowDisplayAffinity(
                window_handle,
                WINDOWS_DISPLAY_AFFINITY_MONITOR_ONLY,
            )

def generate_secure_password(length: int, include_lowercase: bool = True, include_uppercase: bool = True, include_digits: bool = True, include_symbols: bool = True) -> str:
    if length < 1:
        raise ValueError("パスワードの長さは 0 より大きくしてください。")
    character_groups = []
    if include_lowercase:
        character_groups.append(string.ascii_lowercase)
    if include_uppercase:
        character_groups.append(string.ascii_uppercase)
    if include_digits:
        character_groups.append(string.digits)
    if include_symbols:
        character_groups.append(PASSWORD_SYMBOLS)
    if not character_groups:
        raise ValueError("文字種を1つ以上選択してください。")
    character_pool = "".join(character_groups)
    if length < len(character_groups):
        raise ValueError(f"パスワードの長さは、選択した文字種の数（{len(character_groups)}）。")
    password_characters = [secrets.choice(character_group) for character_group in character_groups]
    password_characters.extend(secrets.choice(character_pool) for _ in range(length - len(password_characters)))
    secrets.SystemRandom().shuffle(password_characters)
    return "".join(password_characters)

def generate_crypto_wallet_bundle(
    address_count: int = CRYPTO_ADDRESS_COUNT,
) -> Dict[str, Any]:
    if address_count < 1:
        raise ValueError("アドレス数は 0 より大きくしてください。")

    mnemonic_object = Bip39MnemonicGenerator().FromWordsNumber(
        Bip39WordsNum.WORDS_NUM_24
    )
    mnemonic = str(mnemonic_object)
    seed = Bip39SeedGenerator(mnemonic_object).Generate(CRYPTO_BIP39_PASSPHRASE)
    root = Bip32Secp256k1.FromSeed(seed)
    bitcoin_wallets: List[Dict[str, Any]] = []
    ethereum_wallets: List[Dict[str, Any]] = []

    # BTC はアドレスインデックスを強化した BIP84 形式のパスを使用します。
    for index in range(address_count):
        path = f"m/84'/0'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        private_key_bytes = private_key.Raw().ToBytes()
        bitcoin_wallets.append({
            "index": index,
            "path": path,
            "address": P2WPKHAddrEncoder.EncodeKey(
                public_key.RawCompressed().ToBytes(),
                hrp="bc",
            ),
            "private_key_decimal": int.from_bytes(private_key_bytes, "big"),
            "private_key_wif": WifEncoder.Encode(private_key_bytes),
            "public_key": public_key.RawCompressed().ToHex(),
        })

    # ETH はアドレスインデックスを強化した BIP44 形式のパスを使用します。
    for index in range(address_count):
        path = f"m/44'/60'/0'/0/{index}'"
        node = root.DerivePath(path)
        private_key = node.PrivateKey()
        public_key = node.PublicKey()
        ethereum_wallets.append({
            "index": index,
            "path": path,
            "address": EthAddrEncoder.EncodeKey(
                public_key.RawUncompressed().ToBytes()
            ),
            "private_key_decimal": int.from_bytes(
                private_key.Raw().ToBytes(),
                "big",
            ),
            "public_key": "0x" + public_key.RawUncompressed().ToHex(),
        })

    return {
        "generated_at": now_iso(),
        "mnemonic": mnemonic,
        "seed_hex": seed.hex(),
        "bitcoin": bitcoin_wallets,
        "ethereum": ethereum_wallets,
    }

def format_crypto_wallet_bundle(wallet_bundle: Dict[str, Any]) -> str:
    generated_at = readable_time(str(wallet_bundle.get("generated_at", "")))
    lines = [
        "=" * 80,
        "BIP39 24単語ニーモニック",
        "=" * 80,
        f"生成日時          : {generated_at}",
        f"ニーモニック      : {wallet_bundle.get('mnemonic', '')}",
        f"シード HEX        : {wallet_bundle.get('seed_hex', '')}",
        "BIP39 パスフレーズ：未設定",
        "復元時の注意     ：下記と完全に同じ強化導出パスを使用してください",
        "",
        "=" * 80,
        "BITCOIN - BIP84 形式、アドレスインデックス強化",
        "=" * 80,
    ]
    for wallet in wallet_bundle.get("bitcoin", []):
        lines.extend([
            "",
            f"BTC #{wallet.get('index', '')}",
            f"導出パス        ：{wallet.get('path', '')}",
            f"アドレス        ：{wallet.get('address', '')}",
            f"秘密鍵（10進数）：{wallet.get('private_key_decimal', '')}",
            f"秘密鍵（WIF）   ：{wallet.get('private_key_wif', '')}",
            f"公開鍵          ：{wallet.get('public_key', '')}",
        ])
    lines.extend([
        "",
        "=" * 80,
        "ETHEREUM - BIP44 形式、アドレスインデックス強化",
        "=" * 80,
    ])
    for wallet in wallet_bundle.get("ethereum", []):
        lines.extend([
            "",
            f"ETH #{wallet.get('index', '')}",
            f"導出パス        ：{wallet.get('path', '')}",
            f"アドレス        ：{wallet.get('address', '')}",
            f"秘密鍵（10進数）：{wallet.get('private_key_decimal', '')}",
            f"公開鍵          ：{wallet.get('public_key', '')}",
        ])
    return "\n".join(lines)

def build_crypto_password_item(wallet_bundle: Dict[str, Any]) -> Dict[str, Any]:
    generated_at = str(wallet_bundle.get("generated_at") or now_iso())
    bitcoin_wallets = wallet_bundle.get("bitcoin", [])
    ethereum_wallets = wallet_bundle.get("ethereum", [])
    first_bitcoin_address = (
        str(bitcoin_wallets[0].get("address", "")) if bitcoin_wallets else ""
    )
    first_ethereum_address = (
        str(ethereum_wallets[0].get("address", "")) if ethereum_wallets else ""
    )
    return {
        "id": str(uuid.uuid4()),
        "type": "password",
        "title": f"暗号資産ウォレット {readable_time(generated_at)}",
        "username": (
            f"BTC {first_bitcoin_address} | ETH {first_ethereum_address}"
        ),
        "password": str(wallet_bundle.get("mnemonic", "")),
        "notes": format_crypto_wallet_bundle(wallet_bundle),
        "created_at": generated_at,
        "updated_at": generated_at,
    }
#------ 暗号化とデータベースファイル ------
def encode_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")
def decode_base64(data: str) -> bytes:
    if not isinstance(data, str):
        raise ValueError("Base64 フィールドは文字列である必要があります。")
    try:
        return base64.b64decode(data.encode("ascii"), validate=True)
    except ValueError as error:
        raise ValueError("Base64 データが無効です。") from error
def secure_wipe(buffer: Optional[bytearray]) -> None:
    # 可能な範囲でのみ消去します。Python ではインタープリター内のすべてのコピーを消去できる保証はありません。
    if buffer is None:
        return
    for index in range(len(buffer)):
        buffer[index] = 0
def validate_kdf(kdf_params: Any) -> Dict[str, Any]:
    if not isinstance(kdf_params, dict) or kdf_params.get("name") != "Argon2id":
        raise VaultError("データベースの KDF パラメーターが無効です。")
    required = ("length", "iterations", "lanes", "memory_cost")
    for parameter_name in required:
        parameter_value = kdf_params.get(parameter_name)
        if isinstance(parameter_value, bool) or not isinstance(parameter_value, int):
            raise VaultError(f"データベースの KDF パラメーター {parameter_name} が無効です。")
    length = kdf_params["length"]
    iterations = kdf_params["iterations"]
    lanes = kdf_params["lanes"]
    memory_cost = kdf_params["memory_cost"]
    if length != 32:
        raise VaultError("データベースの KDF 出力長が無効です。")
    if not 1 <= iterations <= MAX_ARGON2_ITERATIONS:
        raise VaultError("データベースの Argon2id iterations が許容範囲外です。")
    if not 1 <= lanes <= MAX_ARGON2_LANES:
        raise VaultError("データベースの Argon2id lanes が許容範囲外です。")
    if memory_cost < 8 * lanes or memory_cost > MAX_ARGON2_MEMORY_KIB:
        raise VaultError("データベースの Argon2id memory_cost が許容範囲外です。")
    return dict(kdf_params)
def build_associated_data(kdf_params: Dict[str, Any], salt_base64: str) -> bytes:
    metadata = {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
    }
    return json.dumps(metadata, ensure_ascii=False, sort_keys=True).encode("utf-8")
def derive_key(master_password: str, salt: bytes, kdf_params: Dict[str, Any]) -> bytes:
    if not master_password:
        raise ValueError("マスターパスワードを空にすることはできません。")
    if kdf_params.get("name") != "Argon2id":
        raise ValueError("未対応の鍵導出アルゴリズムです。")
    return Argon2id(
        salt=salt,
        length=kdf_params["length"],
        iterations=kdf_params["iterations"],
        lanes=kdf_params["lanes"],
        memory_cost=kdf_params["memory_cost"],
        ad=None,
        secret=None,
    ).derive(master_password.encode("utf-8"))
def decode_vault_envelope(vault_envelope: Any):
    if not isinstance(vault_envelope, dict):
        raise VaultError("データベースファイルの形式が無効です。")
    if vault_envelope.get("format") != VAULT_FORMAT:
        raise VaultError("CipherNote Vault のデータベースファイルではありません。")
    if vault_envelope.get("version") != VAULT_VERSION:
        raise VaultError("未対応のデータベースバージョンです。")
    if vault_envelope.get("cipher") != "ChaCha20-Poly1305":
        raise VaultError("未対応の暗号化アルゴリズムです。")
    kdf_params = validate_kdf(vault_envelope.get("kdf"))
    try:
        salt_base64 = vault_envelope["salt"]
        salt = decode_base64(salt_base64)
        nonce = decode_base64(vault_envelope["nonce"])
        ciphertext = decode_base64(vault_envelope["ciphertext"])
    except (KeyError, TypeError, ValueError) as error:
        raise VaultError("データベースファイルが破損しているか、形式が正しくありません。") from error
    if not MIN_SALT_LENGTH <= len(salt) <= MAX_SALT_LENGTH:
        raise VaultError("データベースの salt 長が無効です。")
    if len(nonce) != CHACHA20_POLY1305_NONCE_LENGTH:
        raise VaultError("データベースの nonce 長が無効です。")
    if len(ciphertext) < POLY1305_TAG_LENGTH:
        raise VaultError("データベースの暗号文長が無効です。")
    return kdf_params, salt_base64, salt, nonce, ciphertext
def encrypt_payload(payload: Dict[str, Any], key: bytearray, salt: bytes, kdf_params: Dict[str, Any]) -> Dict[str, Any]:
    plaintext_json = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    plaintext_buffer = bytearray(plaintext_json.encode("utf-8"))
    plaintext_json = ""
    try:
        nonce = os.urandom(CHACHA20_POLY1305_NONCE_LENGTH)
        salt_base64 = encode_base64(salt)
        associated_data = build_associated_data(kdf_params, salt_base64)
        ciphertext = ChaCha20Poly1305(key).encrypt(nonce, plaintext_buffer, associated_data)
    finally:
        secure_wipe(plaintext_buffer)
    return {
        "format": VAULT_FORMAT,
        "version": VAULT_VERSION,
        "cipher": "ChaCha20-Poly1305",
        "kdf": kdf_params,
        "salt": salt_base64,
        "nonce": encode_base64(nonce),
        "ciphertext": encode_base64(ciphertext),
    }

def normalize_payload(payload: Any) -> Dict[str, Any]:
    """復号したデータを検証し、旧バージョンにないフラットな注釈フィールドを補います。"""
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise VaultError("データベース内容の形式が無効です。")
    raw_items = payload["items"]
    if len(raw_items) > MAX_ITEM_COUNT:
        raise VaultError("データベース項目数が許容範囲外です。")
    normalized_payload = dict(payload)
    normalized_items: List[Dict[str, Any]] = []
    seen_item_ids = set()
    for raw_item in raw_items:
        if not isinstance(raw_item, dict):
            raise VaultError("データベース項目の形式が無効です。")
        item_type = raw_item.get("type")
        if item_type not in ("password", "note"):
            raise VaultError("データベースに未対応の項目種別が含まれています。")
        item = dict(raw_item)
        item_id = item.get("id")
        # 旧項目の相互上書きを防ぐため、不足または重複した ID を修復します。
        if not isinstance(item_id, str) or not item_id or item_id in seen_item_ids:
            item_id = str(uuid.uuid4())
        item["id"] = item_id
        seen_item_ids.add(item_id)
        for timestamp_field in ("created_at", "updated_at"):
            timestamp_value = item.get(timestamp_field, "")
            item[timestamp_field] = (
                timestamp_value if isinstance(timestamp_value, str) else ""
            )
        text_fields = (
            ("title", "username", "password", "notes")
            if item_type == "password"
            else ("title", "content")
        )
        for field_name in text_fields:
            field_value = item.get(field_name, "")
            if not isinstance(field_value, str):
                raise VaultError(f"データベースフィールド {field_name} の型が無効です。")
            if len(field_value) > MAX_TEXT_FIELD_LENGTH:
                raise VaultError(f"データベースフィールド {field_name} が大きすぎます。")
            item[field_name] = field_value
        if item_type == "note":
            font_size = item.get("font_size", 20)
            if isinstance(font_size, bool) or not isinstance(font_size, int):
                font_size = 20
            item["font_size"] = min(max(font_size, 12), 36)
            raw_comments = item.get("comments", [])
            if not isinstance(raw_comments, list) or len(raw_comments) > MAX_COMMENT_COUNT:
                raise VaultError("ノート注釈の形式が無効か、数が多すぎます。")
            normalized_comments = []
            seen_comment_ids = set()
            for raw_comment in raw_comments:
                if not isinstance(raw_comment, dict):
                    raise VaultError("ノート注釈の形式が無効です。")
                comment_text = raw_comment.get("text", "")
                quote_text = raw_comment.get("quote", "")
                if not isinstance(comment_text, str) or not isinstance(quote_text, str):
                    raise VaultError("ノート注釈テキストの形式が無効です。")
                if len(comment_text) > MAX_TEXT_FIELD_LENGTH or len(quote_text) > MAX_TEXT_FIELD_LENGTH:
                    raise VaultError("ノート注釈の内容が大きすぎます。")
                comment_id = str(raw_comment.get("id") or uuid.uuid4())
                if comment_id in seen_comment_ids:
                    comment_id = str(uuid.uuid4())
                seen_comment_ids.add(comment_id)
                normalized_comments.append({
                    "id": comment_id,
                    "quote": quote_text,
                    "text": comment_text,
                    "created_at": str(raw_comment.get("created_at") or now_iso()),
                    "updated_at": str(raw_comment.get("updated_at") or now_iso()),
                })
            item["comments"] = normalized_comments
        normalized_items.append(item)
    normalized_payload["items"] = normalized_items
    return normalized_payload

def decrypt_payload(vault_envelope: Any, master_password: str):
    kdf_params, salt_base64, salt, nonce, ciphertext = decode_vault_envelope(vault_envelope)
    key_buffer: Optional[bytearray] = None
    plaintext_buffer: Optional[bytearray] = None
    decryption_succeeded = False
    try:
        try:
            key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        except MemoryError as error:
            raise VaultError("Argon2id のメモリ割り当てに失敗しました。") from error
        except (TypeError, ValueError) as error:
            raise VaultError("データベースの KDF パラメーターを処理できません。") from error
        associated_data = build_associated_data(kdf_params, salt_base64)
        try:
            plaintext_buffer = bytearray(ChaCha20Poly1305(key_buffer).decrypt(nonce, ciphertext, associated_data))
        except InvalidTag as error:
            raise VaultError("マスターパスワードが正しくないか、データベースファイルが改ざんされています。") from error
        try:
            payload = json.loads(plaintext_buffer.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
            raise VaultError("復号したデータベース内容が破損しています。") from error
        payload = normalize_payload(payload)
        decryption_succeeded = True
        return payload, key_buffer, salt, kdf_params
    finally:
        secure_wipe(plaintext_buffer)
        if not decryption_succeeded:
            secure_wipe(key_buffer)
class VaultFileLock:
    """複数のインスタンスによる相互上書きを防ぐため、ダイジェスト検査と組み合わせて使用するクロスプラットフォームの短時間ファイルロックです。"""

    def __init__(self, vault_path: Path):
        self.lock_path = vault_path.with_suffix(vault_path.suffix + ".lock")
        self.handle = None

    def __enter__(self):
        try:
            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            self.handle = self.lock_path.open("a+b")
            if self.lock_path.stat().st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                os.chmod(self.lock_path, 0o600)
        except OSError as error:
            if self.handle is not None:
                with suppress(OSError):
                    self.handle.close()
            self.handle = None
            raise VaultError(
                "データベースファイルのロックを取得できません。別のインスタンスが使用中か、現在のディレクトリに書き込めない可能性があります。"
            ) from error
        return self

    def __exit__(self, _exception_type, _exception, _traceback):
        if self.handle is None:
            return
        try:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None

def read_vault_file_snapshot(path: Path) -> Tuple[Dict[str, Any], str]:
    if not path.exists():
        raise VaultError("データベースファイルが存在しません。")
    try:
        if path.stat().st_size > MAX_VAULT_FILE_SIZE:
            raise VaultError("データベースファイルが大きすぎるため、読み込みを拒否しました。")
        with VaultFileLock(path):
            file_bytes = path.read_bytes()
        if len(file_bytes) > MAX_VAULT_FILE_SIZE:
            raise VaultError("データベースファイルが大きすぎるため、読み込みを拒否しました。")
        vault_envelope = json.loads(file_bytes.decode("utf-8"))
        disk_digest = hashlib.sha256(file_bytes).hexdigest()
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, RecursionError) as error:
        raise VaultError("データベースファイルが破損しているか、形式が正しくありません。") from error
    if not isinstance(vault_envelope, dict):
        raise VaultError("データベースファイルの形式が無効です。")
    return vault_envelope, disk_digest

def read_vault_file(path: Path) -> Dict[str, Any]:
    vault_envelope, _disk_digest = read_vault_file_snapshot(path)
    return vault_envelope

def current_vault_digest(path: Path) -> str:
    if not path.exists():
        return ""
    if path.stat().st_size > MAX_VAULT_FILE_SIZE:
        raise VaultError("データベースファイルが大きすぎるため、処理を拒否しました。")
    return hashlib.sha256(path.read_bytes()).hexdigest()

def move_existing_vault_to_backup(path: Path) -> Optional[Path]:
    """既存のデータベースを日付付きの .bak ファイルへ改名します。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with VaultFileLock(path):
        if not os.path.lexists(path):
            return None
        if not path.is_file():
            raise VaultError("既存のデータベースパスが通常ファイルではないため、自動バックアップできません。")

        date_text = datetime.now().strftime("%Y%m%d")
        stem, suffix = path.stem, path.suffix
        backup_path = path.with_name(f"{stem}_{date_text}.bak{suffix}")
        sequence = 1
        while os.path.lexists(backup_path):
            backup_path = path.with_name(
                f"{stem}_{date_text}_{sequence}.bak{suffix}"
            )
            sequence += 1
        try:
            path.rename(backup_path)
        except OSError as error:
            raise VaultError("既存データベースの改名とバックアップに失敗したため、新しいデータベースは作成されませんでした。") from error
        return backup_path

def fsync_directory(directory: Path) -> None:
    """ディレクトリのメタデータ同期を可能な範囲で試みます。正常に書き込まれたデータベースには影響しません。"""
    if os.name == "nt":
        return
    directory_descriptor = None
    with suppress(OSError):
        directory_descriptor = os.open(directory, os.O_RDONLY)
        os.fsync(directory_descriptor)
    if directory_descriptor is not None:
        with suppress(OSError):
            os.close(directory_descriptor)

def write_vault_file_atomic(
    path: Path,
    vault_envelope: Dict[str, Any],
    expected_disk_digest: Optional[str] = None,
) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized_envelope = json.dumps(vault_envelope, ensure_ascii=False, indent=2)
    serialized_bytes = serialized_envelope.encode("utf-8")
    temporary_path = path.with_name(
        f".{path.name}.{os.getpid()}.{secrets.token_hex(6)}.tmp"
    )
    # 独立した一時ファイルへ書き込んで同期し、その後データベースを原子的に置換します。
    try:
        with VaultFileLock(path):
            current_digest = current_vault_digest(path)
            if (
                expected_disk_digest is not None
                and current_digest != expected_disk_digest
            ):
                raise VaultError(
                    "データベースファイルが別のプログラムによって変更されました。新しいデータを上書きしないよう保存を中止しました。データベースを開き直してください。"
                )
            with temporary_path.open("xb") as file_handle:
                file_handle.write(serialized_bytes)
                file_handle.flush()
                os.fsync(file_handle.fileno())
            if os.name != "nt":
                os.chmod(temporary_path, 0o600)
            os.replace(temporary_path, path)
            fsync_directory(path.parent)
    finally:
        with suppress(OSError):
            temporary_path.unlink(missing_ok=True)
    return hashlib.sha256(serialized_bytes).hexdigest()
def empty_payload() -> Dict[str, Any]:
    timestamp = now_iso()
    return {"app": APP_NAME, "version": VAULT_VERSION, "created_at": timestamp, "updated_at": timestamp, "items": []}
def password_strength_label(password: str) -> str:
    score = 0
    if len(password) >= 12:
        score += 1
    if len(password) >= 18:
        score += 1
    if len(password) >= 24:
        score += 1
    if any(character.islower() for character in password):
        score += 1
    if any(character.isupper() for character in password):
        score += 1
    if any(character.isdigit() for character in password):
        score += 1
    if any(character in string.punctuation for character in password):
        score += 1
    if score <= 3:
        return "弱い"
    if score <= 5:
        return "普通"
    return "強い"
#------ データベース中核 ------
class VaultError(Exception):
    pass
class Vault:
    def __init__(self, path: Path):
        self.path = path
        self.key: Optional[bytearray] = None
        self.salt: Optional[bytes] = None
        self.kdf_params: Dict[str, Any] = dict(ARGON2ID_PARAMS)
        self.payload: Dict[str, Any] = empty_payload()
        self.disk_digest = ""
    def _require_unlocked(self) -> None:
        if self.key is None or self.salt is None:
            raise VaultError("データベースはロックされています。")
    def _set_unlocked_state(
        self,
        *,
        key_buffer: bytearray,
        salt: bytes,
        kdf_params: Dict[str, Any],
        payload: Dict[str, Any],
    ) -> None:
        self.key = key_buffer
        self.salt = salt
        self.kdf_params = kdf_params
        self.payload = payload

    def _commit_payload(self, candidate_payload: Dict[str, Any]) -> None:
        self._require_unlocked()
        normalized_candidate = normalize_payload(candidate_payload)
        normalized_candidate["updated_at"] = now_iso()
        vault_envelope = encrypt_payload(
            normalized_candidate,
            self.key,
            self.salt,
            self.kdf_params,
        )
        new_digest = write_vault_file_atomic(
            self.path,
            vault_envelope,
            expected_disk_digest=self.disk_digest,
        )
        self.payload = normalized_candidate
        self.disk_digest = new_digest

    def create(self, master_password: str) -> None:
        if not master_password:
            raise VaultError("新しいマスターパスワードを空にすることはできません。")
        salt = os.urandom(16)
        kdf_params = dict(ARGON2ID_PARAMS)
        key_buffer = bytearray(derive_key(master_password, salt, kdf_params))
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=empty_payload(),
        )
        backup_path: Optional[Path] = None
        try:
            # 対象が存在する場合は先にバックアップ名へ変更し、直接上書きしません。
            backup_path = move_existing_vault_to_backup(self.path)
            self.disk_digest = ""
            self.save()
        except Exception as error:
            self.lock()
            if backup_path is not None:
                raise VaultError(
                    f"新しいデータベースの作成に失敗しました。元のファイルは次の名前で安全に保持されています：{backup_path.name}。"
                ) from error
            raise
    def unlock(self, master_password: str) -> None:
        if self.key is not None:
            self.lock()
        vault_envelope, disk_digest = read_vault_file_snapshot(self.path)
        payload, key_buffer, salt, kdf_params = decrypt_payload(vault_envelope, master_password)
        self._set_unlocked_state(
            key_buffer=key_buffer,
            salt=salt,
            kdf_params=kdf_params,
            payload=payload,
        )
        self.disk_digest = disk_digest
    def save(self) -> None:
        self._commit_payload(copy.deepcopy(self.payload))
    def change_master_password(self, new_master_password: str) -> None:
        self._require_unlocked()
        if not new_master_password:
            raise VaultError("新しいマスターパスワードを空にすることはできません。")
        old_key = self.key
        new_salt = os.urandom(16)
        new_kdf_params = dict(ARGON2ID_PARAMS)
        new_key = bytearray(derive_key(new_master_password, new_salt, new_kdf_params))
        candidate_payload = normalize_payload(copy.deepcopy(self.payload))
        candidate_payload["updated_at"] = now_iso()
        try:
            vault_envelope = encrypt_payload(
                candidate_payload,
                new_key,
                new_salt,
                new_kdf_params,
            )
            new_digest = write_vault_file_atomic(
                self.path,
                vault_envelope,
                expected_disk_digest=self.disk_digest,
            )
        except Exception:
            secure_wipe(new_key)
            raise
        # 新しい暗号文が安全に保存された後でのみ、メモリ上の鍵を切り替えます。
        self._set_unlocked_state(
            key_buffer=new_key,
            salt=new_salt,
            kdf_params=new_kdf_params,
            payload=candidate_payload,
        )
        self.disk_digest = new_digest
        secure_wipe(old_key)
    def lock(self) -> None:
        secure_wipe(self.key)
        self.key = None
        self.salt = None
        items = self.payload.get("items")
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    item.clear()
            items.clear()
        self.payload.clear()
        self.payload = empty_payload()
        self.disk_digest = ""
    def all_items(self, item_type: Optional[str] = None) -> List[Dict[str, Any]]:
        items = self.payload.get("items", [])
        if item_type is None:
            return list(items)
        return [item for item in items if item.get("type") == item_type]
    def upsert_item(self, item: Dict[str, Any]) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        item_copy = copy.deepcopy(item)
        item_copy["updated_at"] = now_iso()
        for index, existing in enumerate(items):
            if existing.get("id") == item_copy.get("id"):
                items[index] = item_copy
                self._commit_payload(candidate_payload)
                return
        item_copy.setdefault("id", str(uuid.uuid4()))
        item_copy.setdefault("created_at", now_iso())
        items.append(item_copy)
        self._commit_payload(candidate_payload)
    def delete_item(self, item_id: str) -> None:
        self._require_unlocked()
        candidate_payload = copy.deepcopy(self.payload)
        items = candidate_payload.setdefault("items", [])
        candidate_payload["items"] = [
            item for item in items if item.get("id") != item_id
        ]
        if len(candidate_payload["items"]) == len(items):
            raise VaultError("削除対象の項目は既に存在しません。")
        self._commit_payload(candidate_payload)
#------ ダイアログ ------
class ProtectedDialog(QDialog):
    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, lambda: protect_widget_from_capture(self))

class FunctionThread(QThread):
    succeeded = pyqtSignal(object)
    failed = pyqtSignal(object)

    def __init__(self, operation: Callable[[], Any], parent=None):
        super().__init__(parent)
        self.operation = operation

    def run(self):
        try:
            result = self.operation()
        except Exception as error:
            self.failed.emit(error)
            return
        self.succeeded.emit(result)

class BlockingProgressDialog(QProgressDialog):
    def reject(self):
        # 鍵導出は安全に中断できないため、完了後にワーカースレッドがウィンドウを閉じます。
        return

def run_with_progress(
    parent,
    title: str,
    message: str,
    operation: Callable[[], Any],
) -> Any:
    dialog = BlockingProgressDialog(message, "", 0, 0, parent)
    dialog.setWindowTitle(title)
    dialog.setMinimumDuration(0)
    dialog.setAutoClose(False)
    dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
    dialog.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
    dialog.setMinimumWidth(480)
    result_holder: Dict[str, Any] = {}
    worker = FunctionThread(operation, dialog)

    def handle_success(result):
        result_holder["result"] = result
        dialog.done(QDialog.DialogCode.Accepted)

    def handle_failure(error):
        result_holder["error"] = error
        dialog.done(QDialog.DialogCode.Rejected)

    worker.succeeded.connect(handle_success)
    worker.failed.connect(handle_failure)
    worker.start()
    protect_widget_from_capture(dialog)
    dialog.exec()
    worker.wait()
    if "error" in result_holder:
        raise result_holder["error"]
    return result_holder.get("result")

def run_ui_operation(
    parent,
    error_title: str,
    operation: Callable[[], Any],
) -> Tuple[bool, Any]:
    """各ボタンで try/except を繰り返さないよう、UI 操作の例外を一元処理します。"""
    try:
        return True, operation()
    except Exception as error:
        QMessageBox.critical(parent, error_title, str(error))
        return False, None

class StartupDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "open"
        self.setWindowTitle(APP_NAME)
        self.resize(900, 460)
        self.setMinimumWidth(860)
        self.setStyleSheet("QWidget { font-size: 16px; } QLabel#DialogTitle { font-size: 34px; }")
        title_label = QLabel("CipherNote Vault")
        title_label.setObjectName("DialogTitle")
        subtitle_label = QLabel("ローカル暗号化パスワード管理・セキュアノートアプリです。データベースの全内容を Argon2id + ChaCha20-Poly1305 で暗号化して保存します。")
        subtitle_label.setObjectName("SubtleLabel")
        subtitle_label.setWordWrap(True)
        self.open_database_radio = QRadioButton("既存のデータベースを開く")
        self.create_database_radio = QRadioButton("新しいデータベースを作成")
        self.open_database_radio.setObjectName("ModeRadio")
        self.create_database_radio.setObjectName("ModeRadio")
        self.open_database_radio.setChecked(True)
        self.mode_button_group = QButtonGroup(self)
        self.mode_button_group.addButton(self.open_database_radio)
        self.mode_button_group.addButton(self.create_database_radio)
        self.mode_button_group.setExclusive(True)
        self.open_database_radio.toggled.connect(self.update_startup_mode)
        self.create_database_radio.toggled.connect(self.update_startup_mode)
        mode_frame = QFrame()
        mode_frame.setObjectName("ModeFrame")
        mode_layout = QHBoxLayout(mode_frame)
        mode_layout.setContentsMargins(12, 10, 12, 10)
        mode_layout.setSpacing(18)
        mode_layout.addWidget(self.open_database_radio)
        mode_layout.addWidget(self.create_database_radio)
        mode_layout.addStretch(1)
        self.path_edit = QLineEdit(str(DEFAULT_VAULT))
        self.path_edit.setPlaceholderText(".cnvault データベースファイルを選択")
        browse_button = QPushButton("参照")
        browse_button.clicked.connect(self.browse)
        path_layout = QHBoxLayout()
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(browse_button)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.generate_master_password_button = QPushButton("ランダム生成")
        self.generate_master_password_button.clicked.connect(self.generate_master_password)
        password_layout = QHBoxLayout()
        password_layout.addWidget(self.password_edit, 1)
        password_layout.addWidget(self.generate_master_password_button)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        self.status_label.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("操作：", mode_frame)
        form_layout.addRow("データベースファイル：", path_layout)
        form_layout.addRow("マスターパスワード：", password_layout)
        form_layout.addRow("マスターパスワードの確認：", self.confirm_edit)
        form_layout.addRow("", self.status_label)
        self.ok_button = QPushButton("データベースを開く")
        self.cancel_button = QPushButton("キャンセル")
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(title_label)
        dialog_layout.addWidget(subtitle_label)
        dialog_layout.addSpacing(10)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
        self.update_startup_mode()
    def update_startup_mode(self):
        if self.create_database_radio.isChecked():
            self.mode = "create"
            self.setWindowTitle("新しいデータベースを作成 - CipherNote Vault")
            self.ok_button.setText("データベースを作成")
            self.confirm_edit.setEnabled(True)
            self.generate_master_password_button.setEnabled(True)
            self.status_label.setText("現在の操作：新しいデータベースの作成。強力な暗号化パラメーターでローカルデータベースを作成します。")
        else:
            self.mode = "open"
            self.setWindowTitle("データベースを開く - CipherNote Vault")
            self.ok_button.setText("データベースを開く")
            self.confirm_edit.setEnabled(False)
            self.generate_master_password_button.setEnabled(False)
            self.status_label.setText("現在の操作：既存のデータベースを開く。既存の .cnvault データベースを選択し、マスターパスワードを入力してください。")
    def generate_master_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def browse(self):
        if self.mode == "create":
            selected_filename, _selected_filter = QFileDialog.getSaveFileName(
                self,
                "CipherNote Vault データベースを作成",
                self.path_edit.text() or str(DEFAULT_VAULT),
                "CipherNote Vault (*.cnvault);;JSON ファイル (*.json);;すべてのファイル (*)",
            )
        else:
            selected_filename, _selected_filter = QFileDialog.getOpenFileName(
                self,
                "CipherNote Vault データベースを開く",
                self.path_edit.text() or str(DEFAULT_VAULT_DIR),
                "CipherNote Vault (*.cnvault);;JSON ファイル (*.json);;すべてのファイル (*)",
            )
        if selected_filename:
            self.path_edit.setText(selected_filename)
    def get_result(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            raw_path = self.path_edit.text().strip()
            master_password = self.password_edit.text()
            if not raw_path:
                QMessageBox.warning(self, "パスがありません", "データベースファイルのパスを選択してください。")
                continue
            database_path = Path(raw_path).expanduser()
            if not master_password:
                QMessageBox.warning(self, "マスターパスワードがありません", "マスターパスワードを入力してください。")
                continue
            if self.mode == "create":
                if master_password != self.confirm_edit.text():
                    QMessageBox.warning(self, "パスワードが一致しません", "入力したマスターパスワードが一致しません。")
                    continue
                if database_path.exists():
                    if database_path.is_dir():
                        QMessageBox.warning(self, "パスが無効です", "データベースのパスにフォルダーは指定できません。")
                        continue
                    answer = QMessageBox.question(
                        self,
                        "ファイルは既に存在します",
                        "このファイルは既に存在します。続行すると、元のファイルは上書きされず、日付と .bak を付けたバックアップ名へ自動的に変更されます。\n\n新しいデータベースを作成しますか？",
                    )
                    if answer != QMessageBox.StandardButton.Yes:
                        continue
                result = {"mode": "create", "path": database_path, "password": master_password}
                self.password_edit.clear()
                self.confirm_edit.clear()
                return result
            if not database_path.is_file():
                QMessageBox.warning(self, "ファイルが存在しません", "既存のデータベースファイルを選択してください。")
                continue
            result = {"mode": "open", "path": database_path, "password": master_password}
            self.password_edit.clear()
            self.confirm_edit.clear()
            return result
class PasswordGeneratorDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.generated_password = ""
        self.setWindowTitle("ランダムパスワードを生成")
        self.resize(720, 520)
        self.setMinimumSize(680, 500)
        self.setModal(True)
        self.setStyleSheet("""
            QDialog {
                background-color: #241000;
            }
            QLabel {
                color: #F7D000;
                font-size: 17px;
            }
            QLabel#GeneratorTitle {
                color: #FFF000;
                font-size: 30px;
                font-weight: 700;
            }
            QLabel#GeneratorSubtitle {
                color: #D9A400;
                font-size: 15px;
            }
            QLabel#SectionTitle {
                color: #FFF000;
                font-size: 18px;
                font-weight: 700;
            }
            QLabel#StatusLabel {
                color: #D9A400;
                font-size: 14px;
            }
            QFrame#PasswordPreviewCard,
            QFrame#OptionsCard {
                background-color: #351100;
                border: 1px solid #7C1D00;
                border-radius: 12px;
            }
            QLineEdit#PasswordPreview {
                background-color: #170800;
                color: #FFF000;
                border: 2px solid #E9C400;
                border-radius: 9px;
                padding: 12px 14px;
                font-size: 21px;
                font-family: Consolas, "Courier New", monospace;
                selection-background-color: #FFD700;
                selection-color: #FF0000;
            }
            QSpinBox {
                min-height: 38px;
                min-width: 120px;
                padding: 0 10px;
                color: #FFF000;
                background-color: #170800;
                border: 1px solid #8A1F00;
                border-radius: 7px;
                font-size: 18px;
            }
            QCheckBox {
                color: #F7D000;
                font-size: 17px;
                spacing: 10px;
                min-height: 34px;
            }
            QPushButton {
                min-height: 42px;
                padding: 0 18px;
                color: #241000;
                background-color: #E9C400;
                border: 1px solid #F1C900;
                border-radius: 8px;
                font-size: 17px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #F3D500;
            }
            QPushButton:pressed {
                background-color: #D89C00;
            }
            QPushButton#SecondaryButton {
                color: #F7D000;
                background-color: #5F1700;
                border-color: #9A3400;
            }
            QPushButton#SecondaryButton:hover {
                background-color: #7C1D00;
            }
            QPushButton#CancelButton {
                color: #F7D000;
                background-color: #351100;
                border-color: #7C1D00;
            }
            QPushButton#CancelButton:hover {
                background-color: #5F1700;
            }
        """)
        self.build_interface()
        self.connect_signals()
        self.refresh_password()

    def build_interface(self):
        title_label = QLabel("ランダムパスワード生成")
        title_label.setObjectName("GeneratorTitle")
        subtitle_label = QLabel("パスワードの長さと文字種を選択してください。システムの安全な乱数でパスワードを生成します。")
        subtitle_label.setObjectName("GeneratorSubtitle")
        subtitle_label.setWordWrap(True)

        self.password_preview = QLineEdit()
        self.password_preview.setObjectName("PasswordPreview")
        self.password_preview.setReadOnly(True)
        self.password_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.password_preview.setMinimumHeight(58)

        preview_title = QLabel("生成結果")
        preview_title.setObjectName("SectionTitle")
        preview_card = QFrame()
        preview_card.setObjectName("PasswordPreviewCard")
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(18, 16, 18, 18)
        preview_layout.setSpacing(10)
        preview_layout.addWidget(preview_title)
        preview_layout.addWidget(self.password_preview)

        length_label = QLabel("パスワードの長さ")
        length_label.setObjectName("SectionTitle")
        self.password_length_spinbox = QSpinBox()
        self.password_length_spinbox.setRange(1, MAX_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setValue(DEFAULT_GENERATED_PASSWORD_LENGTH)
        self.password_length_spinbox.setSuffix(" 文字")
        length_row = QHBoxLayout()
        length_row.setSpacing(14)
        length_row.addWidget(length_label)
        length_row.addStretch(1)
        length_row.addWidget(self.password_length_spinbox)

        character_label = QLabel("使用する文字")
        character_label.setObjectName("SectionTitle")
        self.include_lowercase_checkbox = QCheckBox("小文字  a-z")
        self.include_uppercase_checkbox = QCheckBox("大文字  A-Z")
        self.include_digits_checkbox = QCheckBox("数字  0-9")
        self.include_symbols_checkbox = QCheckBox("記号  !@#$...")
        for checkbox in (
            self.include_lowercase_checkbox,
            self.include_uppercase_checkbox,
            self.include_digits_checkbox,
            self.include_symbols_checkbox,
        ):
            checkbox.setChecked(True)

        checkbox_row_1 = QHBoxLayout()
        checkbox_row_1.setSpacing(24)
        checkbox_row_1.addWidget(self.include_lowercase_checkbox, 1)
        checkbox_row_1.addWidget(self.include_uppercase_checkbox, 1)
        checkbox_row_2 = QHBoxLayout()
        checkbox_row_2.setSpacing(24)
        checkbox_row_2.addWidget(self.include_digits_checkbox, 1)
        checkbox_row_2.addWidget(self.include_symbols_checkbox, 1)

        self.status_label = QLabel("既定では32文字のパスワードを生成します。")
        self.status_label.setObjectName("StatusLabel")
        self.status_label.setWordWrap(True)

        options_card = QFrame()
        options_card.setObjectName("OptionsCard")
        options_layout = QVBoxLayout(options_card)
        options_layout.setContentsMargins(18, 16, 18, 16)
        options_layout.setSpacing(12)
        options_layout.addLayout(length_row)
        options_layout.addSpacing(4)
        options_layout.addWidget(character_label)
        options_layout.addLayout(checkbox_row_1)
        options_layout.addLayout(checkbox_row_2)
        options_layout.addWidget(self.status_label)

        self.regenerate_button = QPushButton("再生成")
        self.regenerate_button.setObjectName("SecondaryButton")
        self.use_password_button = QPushButton("このパスワードを使用")
        self.cancel_button = QPushButton("キャンセル")
        self.cancel_button.setObjectName("CancelButton")

        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)
        button_layout.addWidget(self.regenerate_button)
        button_layout.addStretch(1)
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.use_password_button)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 22, 24, 22)
        main_layout.setSpacing(16)
        main_layout.addWidget(title_label)
        main_layout.addWidget(subtitle_label)
        main_layout.addWidget(preview_card)
        main_layout.addWidget(options_card)
        main_layout.addStretch(1)
        main_layout.addLayout(button_layout)

    def connect_signals(self):
        self.regenerate_button.clicked.connect(self.refresh_password)
        self.use_password_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        self.password_length_spinbox.valueChanged.connect(self.refresh_password)
        self.include_lowercase_checkbox.toggled.connect(self.refresh_password)
        self.include_uppercase_checkbox.toggled.connect(self.refresh_password)
        self.include_digits_checkbox.toggled.connect(self.refresh_password)
        self.include_symbols_checkbox.toggled.connect(self.refresh_password)

    def refresh_password(self):
        try:
            self.generated_password = generate_secure_password(
                length=self.password_length_spinbox.value(),
                include_lowercase=self.include_lowercase_checkbox.isChecked(),
                include_uppercase=self.include_uppercase_checkbox.isChecked(),
                include_digits=self.include_digits_checkbox.isChecked(),
                include_symbols=self.include_symbols_checkbox.isChecked(),
            )
        except ValueError as error:
            self.generated_password = ""
            self.password_preview.clear()
            self.status_label.setText(str(error))
            self.use_password_button.setEnabled(False)
            return
        self.password_preview.setText(self.generated_password)
        self.password_preview.setCursorPosition(0)
        enabled_types = sum((
            self.include_lowercase_checkbox.isChecked(),
            self.include_uppercase_checkbox.isChecked(),
            self.include_digits_checkbox.isChecked(),
            self.include_symbols_checkbox.isChecked(),
        ))
        self.status_label.setText(
            f"長さ：{self.password_length_spinbox.value()} 文字    "
            f"文字種：{enabled_types} 種"
        )
        self.use_password_button.setEnabled(True)

    def generate(self) -> Optional[str]:
        if self.exec() != QDialog.DialogCode.Accepted:
            self.generated_password = ""
            self.password_preview.clear()
            return None
        password = self.generated_password
        self.generated_password = ""
        self.password_preview.clear()
        return password
class PasswordDialog(ProtectedDialog):
    def __init__(self, item: Optional[Dict[str, Any]] = None, parent=None):
        super().__init__(parent)
        self.item = item or {}
        self.setWindowTitle("パスワード項目")
        self.resize(940, 680)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.username_edit = QLineEdit(self.item.get("username", ""))
        self.password_edit = QLineEdit(self.item.get("password", ""))
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.notes_edit = QPlainTextEdit(self.item.get("notes", ""))
        self.strength_label = QLabel("")
        self.strength_label.setObjectName("SubtleLabel")
        self.password_edit.textChanged.connect(self.update_strength)
        self.update_strength()
        show_password_button = QPushButton("表示／非表示")
        generate_password_button = QPushButton("ランダム生成")
        show_password_button.clicked.connect(self.toggle_password_visibility)
        generate_password_button.clicked.connect(self.generate_password)
        password_row = QHBoxLayout()
        password_row.addWidget(self.password_edit, 1)
        password_row.addWidget(show_password_button)
        password_row.addWidget(generate_password_button)
        form_layout = QFormLayout()
        form_layout.addRow("タイトル：", self.title_edit)
        form_layout.addRow("ユーザー名：", self.username_edit)
        form_layout.addRow("パスワード：", password_row)
        form_layout.addRow("", self.strength_label)
        form_layout.addRow("備考：", self.notes_edit)
        save_button = QPushButton("保存")
        cancel_button = QPushButton("キャンセル")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def update_strength(self):
        password_value = self.password_edit.text()
        self.strength_label.setText(
            "パスワード強度：未入力"
            if not password_value
            else f"パスワード強度：{password_strength_label(password_value)}"
        )
    def toggle_password_visibility(self):
        if self.password_edit.echoMode() == QLineEdit.EchoMode.Password:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
        else:
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def clear_sensitive_fields(self) -> None:
        self.password_edit.clear()
        self.notes_edit.clear()
        self.username_edit.clear()
        self.title_edit.clear()
        self.item = {}
    def build_password_item(self) -> Optional[Dict[str, Any]]:
        title_value = self.title_edit.text().strip()
        if not title_value:
            QMessageBox.warning(self, "タイトルがありません", "タイトルを空にすることはできません。")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "password",
            "title": title_value,
            "username": self.username_edit.text().strip(),
            "password": self.password_edit.text(),
            "notes": self.notes_edit.toPlainText(),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }
    def get_item(self) -> Optional[Dict[str, Any]]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.clear_sensitive_fields()
                return None
            result = self.build_password_item()
            if result is None:
                continue
            self.clear_sensitive_fields()
            return result
class NoteDialog(ProtectedDialog):
    def __init__(
        self,
        item: Optional[Dict[str, Any]] = None,
        parent=None,
        on_save: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        super().__init__(parent)
        self.item = copy.deepcopy(item or {})
        self.comments: List[Dict[str, Any]] = copy.deepcopy(
            self.item.get("comments", [])
        )
        self.on_save = on_save
        self.saved_item: Optional[Dict[str, Any]] = None
        self.is_dirty = False
        self._suppress_dirty = True
        self._last_note_match = None
        self.setWindowTitle("セキュアノート")
        self.resize(1320, 860)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.title_edit = QLineEdit(self.item.get("title", ""))
        self.title_edit.setPlaceholderText("ノートのタイトル")
        self.content_edit = QPlainTextEdit(self.item.get("content", ""))
        self.content_edit.setObjectName("NoteContentEditor")
        self.content_edit.setPlaceholderText("重要なノートをここに入力してください……")
        self.note_font_slider = QSlider(Qt.Orientation.Horizontal)
        self.note_font_slider.setRange(12, 36)
        self.note_font_slider.setValue(int(self.item.get("font_size", 20) or 20))
        self.note_font_slider.setFixedWidth(180)
        self.note_font_slider.valueChanged.connect(self.apply_note_font_size)
        self.note_font_size_label = QLabel(f"フォント {self.note_font_slider.value()}")
        self.note_font_size_label.setObjectName("SubtleLabel")
        self.save_status_label = QLabel("Ctrl+S でウィンドウを閉じずに保存")
        self.save_status_label.setObjectName("SubtleLabel")
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(8)
        title_label = QLabel("タイトル")
        title_label.setObjectName("SearchLabel")
        title_label.setFixedWidth(44)
        title_layout.addWidget(title_label)
        title_layout.addWidget(self.title_edit, 1)
        import_button = QPushButton("テキストをインポート")
        cleanup_button = QPushButton("空行を整理")
        import_button.clicked.connect(self.import_text_file)
        cleanup_button.clicked.connect(self.cleanup_blank_lines)
        title_layout.addWidget(import_button)
        title_layout.addWidget(cleanup_button)

        self.note_find_edit = QLineEdit()
        self.note_find_edit.setPlaceholderText("検索する文字列")
        self.note_replace_edit = QLineEdit()
        self.note_replace_edit.setPlaceholderText("置換後の文字列")
        self.note_regex_checkbox = QCheckBox("正規表現")
        self.note_search_status = QLabel("")
        self.note_search_status.setObjectName("SubtleLabel")
        find_next_button = QPushButton("次を検索")
        replace_button = QPushButton("現在の一致を置換")
        replace_all_button = QPushButton("すべて置換")
        find_next_button.clicked.connect(self.find_next_in_note)
        replace_button.clicked.connect(self.replace_current_match)
        replace_all_button.clicked.connect(self.replace_all_matches)
        self.note_find_edit.returnPressed.connect(self.find_next_in_note)
        find_shortcut = QShortcut(QKeySequence.StandardKey.Find, self)
        find_shortcut.activated.connect(self.focus_note_search)
        search_frame = QFrame()
        search_frame.setObjectName("InlineSearch")
        search_layout = QHBoxLayout(search_frame)
        search_layout.setContentsMargins(8, 6, 8, 6)
        search_layout.setSpacing(6)
        search_layout.addWidget(QLabel("検索"))
        search_layout.addWidget(self.note_find_edit, 2)
        search_layout.addWidget(QLabel("置換"))
        search_layout.addWidget(self.note_replace_edit, 2)
        search_layout.addWidget(self.note_regex_checkbox)
        search_layout.addWidget(find_next_button)
        search_layout.addWidget(replace_button)
        search_layout.addWidget(replace_all_button)
        search_layout.addWidget(self.note_search_status, 1)

        self.comment_list = QListWidget()
        self.comment_list.setObjectName("CommentList")
        self.comment_list.setAlternatingRowColors(True)
        self.comment_list.currentItemChanged.connect(self.show_selected_comment)
        self.comment_preview = QPlainTextEdit()
        self.comment_preview.setObjectName("CommentPreview")
        self.comment_preview.setReadOnly(True)
        self.comment_preview.setPlaceholderText("内容を表示する注釈を選択してください")
        self.comment_preview.setMaximumHeight(180)
        add_comment_button = QPushButton("注釈を追加")
        edit_comment_button = QPushButton("編集")
        delete_comment_button = QPushButton("削除")
        add_comment_button.clicked.connect(self.add_comment)
        edit_comment_button.clicked.connect(self.edit_comment)
        delete_comment_button.clicked.connect(self.delete_comment)
        comment_button_layout = QHBoxLayout()
        comment_button_layout.setSpacing(6)
        comment_button_layout.addWidget(add_comment_button)
        comment_button_layout.addWidget(edit_comment_button)
        comment_button_layout.addWidget(delete_comment_button)
        comments_title = QLabel("右側の注釈（フラット、入れ子なし）")
        comments_title.setObjectName("SectionTitle")
        comments_panel = QFrame()
        comments_panel.setObjectName("CommentsPanel")
        comments_layout = QVBoxLayout(comments_panel)
        comments_layout.setContentsMargins(10, 10, 10, 10)
        comments_layout.setSpacing(8)
        comments_layout.addWidget(comments_title)
        comments_layout.addWidget(self.comment_list, 1)
        comments_layout.addWidget(self.comment_preview)
        comments_layout.addLayout(comment_button_layout)

        editor_splitter = QSplitter(Qt.Orientation.Horizontal)
        editor_splitter.addWidget(self.content_edit)
        editor_splitter.addWidget(comments_panel)
        editor_splitter.setStretchFactor(0, 4)
        editor_splitter.setStretchFactor(1, 1)
        editor_splitter.setSizes([980, 320])

        save_button = QPushButton("保存")
        close_button = QPushButton("閉じる")
        save_button.clicked.connect(self.save_without_closing)
        close_button.clicked.connect(self.close)
        save_shortcut = QShortcut(QKeySequence.StandardKey.Save, self)
        save_shortcut.activated.connect(self.save_without_closing)
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 6, 0, 0)
        bottom_layout.setSpacing(8)
        bottom_layout.addWidget(QLabel("フォント"))
        bottom_layout.addWidget(self.note_font_slider)
        bottom_layout.addWidget(self.note_font_size_label)
        bottom_layout.addSpacing(14)
        bottom_layout.addWidget(self.save_status_label)
        bottom_layout.addStretch(1)
        bottom_layout.addWidget(save_button)
        bottom_layout.addWidget(close_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.setContentsMargins(10, 10, 10, 10)
        dialog_layout.setSpacing(6)
        dialog_layout.addLayout(title_layout)
        dialog_layout.addWidget(search_frame)
        dialog_layout.addWidget(editor_splitter, 1)
        dialog_layout.addLayout(bottom_layout)
        self.apply_note_font_size()
        self.refresh_comment_list()
        self.title_edit.textChanged.connect(self.mark_dirty)
        self.content_edit.textChanged.connect(self.mark_dirty)
        self.note_font_slider.valueChanged.connect(self.mark_dirty)
        self._suppress_dirty = False

    def mark_dirty(self, *_args):
        if self._suppress_dirty:
            return
        self._last_note_match = None
        self.is_dirty = True
        self.save_status_label.setText("未保存 · Ctrl+S で保存")

    def apply_note_font_size(self):
        note_font = QFont("Yu Gothic UI")
        note_font.setPointSize(self.note_font_slider.value())
        self.content_edit.setFont(note_font)
        self.note_font_size_label.setText(f"フォント {self.note_font_slider.value()}")

    def focus_note_search(self):
        self.note_find_edit.setFocus()
        self.note_find_edit.selectAll()

    def build_note_search_pattern(self) -> Optional[Pattern[str]]:
        pattern_text = self.note_find_edit.text()
        if not pattern_text:
            self.note_search_status.setText("検索する文字列を入力してください")
            return None
        try:
            if self.note_regex_checkbox.isChecked():
                return compile_search_regex(pattern_text)
            return re.compile(re.escape(pattern_text), re.IGNORECASE | re.UNICODE)
        except ValueError as error:
            self.note_search_status.setText(str(error))
            return None

    def find_next_in_note(self) -> bool:
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return False
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        start_position = qt_position_to_python_index(
            source_text,
            cursor.selectionEnd() if cursor.hasSelection() else cursor.position(),
        )
        if self._last_note_match is not None:
            previous_match = self._last_note_match[0]
            if previous_match.start() == previous_match.end():
                start_position = min(len(source_text), start_position + 1)
        match = compiled_pattern.search(source_text, start_position)
        wrapped = False
        if match is None and start_position > 0:
            match = compiled_pattern.search(source_text, 0, start_position)
            wrapped = match is not None
        if match is None:
            self._last_note_match = None
            self.note_search_status.setText("見つかりません")
            return False
        selection_cursor = self.content_edit.textCursor()
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.start())
        )
        selection_cursor.setPosition(
            python_index_to_qt_position(source_text, match.end()),
            QTextCursor.MoveMode.KeepAnchor,
        )
        self.content_edit.setTextCursor(selection_cursor)
        self.content_edit.ensureCursorVisible()
        self.content_edit.setFocus()
        self._last_note_match = (
            match,
            self.note_regex_checkbox.isChecked(),
        )
        self.note_search_status.setText("先頭から検索を続行しました" if wrapped else "見つかりました")
        return True

    def replace_current_match(self):
        if self._last_note_match is None and not self.find_next_in_note():
            return
        source_text = self.content_edit.toPlainText()
        cursor = self.content_edit.textCursor()
        match, regex_mode = self._last_note_match
        selected_start = qt_position_to_python_index(
            source_text, cursor.selectionStart()
        )
        selected_end = qt_position_to_python_index(
            source_text, cursor.selectionEnd()
        )
        if (selected_start, selected_end) != (match.start(), match.end()):
            self._last_note_match = None
            if not self.find_next_in_note():
                return
            cursor = self.content_edit.textCursor()
            match, regex_mode = self._last_note_match
        replacement_text = self.note_replace_edit.text()
        try:
            replacement_value = (
                match.expand(replacement_text) if regex_mode else replacement_text
            )
        except re.error as error:
            self.note_search_status.setText(f"置換式が無効です：{error}")
            return
        cursor.insertText(replacement_value)
        self.content_edit.setTextCursor(cursor)
        self.note_search_status.setText("1か所置換しました")

    def replace_all_matches(self):
        compiled_pattern = self.build_note_search_pattern()
        if compiled_pattern is None:
            return
        source_text = self.content_edit.toPlainText()
        replacement_text = self.note_replace_edit.text()
        try:
            if self.note_regex_checkbox.isChecked():
                replaced_text, replacement_count = compiled_pattern.subn(
                    replacement_text,
                    source_text,
                )
            else:
                replaced_text, replacement_count = compiled_pattern.subn(
                    lambda _match: replacement_text,
                    source_text,
                )
        except re.error as error:
            self.note_search_status.setText(f"置換式が無効です：{error}")
            return
        if replacement_count == 0:
            self.note_search_status.setText("置換できる内容が見つかりません")
            return
        self.replace_editor_text(replaced_text)
        self.mark_dirty()
        self.note_search_status.setText(f"置換：{replacement_count}か所 · 元に戻せます")

    def replace_editor_text(self, new_text: str):
        cursor = self.content_edit.textCursor()
        cursor.beginEditBlock()
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.insertText(new_text)
        cursor.endEditBlock()
        self.content_edit.setTextCursor(cursor)

    def import_text_file(self):
        selected_filename, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "テキストファイルをインポート",
            "",
            "テキストファイル (*.txt *.md *.log *.csv *.json *.xml *.html);;すべてのファイル (*)",
        )
        if not selected_filename:
            return
        source_path = Path(selected_filename)
        succeeded, import_result = run_ui_operation(
            self,
            "インポートに失敗しました",
            lambda: read_imported_text_file(source_path),
        )
        if not succeeded:
            return
        imported_text, encoding, coherence = import_result

        choice_box = QMessageBox(self)
        choice_box.setWindowTitle("インポート方法")
        choice_box.setText(
            f"判定した文字コード：{encoding}（信頼度 {coherence:.1f}%）\n\n"
            "現在の本文を置き換えるか、本文の末尾に追加するかを選択してください。"
        )
        replace_button = choice_box.addButton(
            "本文を置換", QMessageBox.ButtonRole.AcceptRole
        )
        append_button = choice_box.addButton(
            "本文に追加", QMessageBox.ButtonRole.ActionRole
        )
        choice_box.addButton("キャンセル", QMessageBox.ButtonRole.RejectRole)
        choice_box.exec()
        clicked_button = choice_box.clickedButton()
        if clicked_button == replace_button:
            self.replace_editor_text(imported_text)
        elif clicked_button == append_button:
            current_text = self.content_edit.toPlainText()
            separator = "\n" if current_text and not current_text.endswith("\n") else ""
            self.replace_editor_text(current_text + separator + imported_text)
        else:
            return
        self.mark_dirty()
        self.save_status_label.setText(
            f"インポート済み：{source_path.name} · 文字コード {encoding} · 未保存"
        )

    def cleanup_blank_lines(self):
        original_text = self.content_edit.toPlainText()
        cleaned_text = remove_extra_blank_lines(original_text)
        if cleaned_text == original_text:
            self.save_status_label.setText("余分な空行はありません")
            return
        self.replace_editor_text(cleaned_text)
        self.mark_dirty()
        self.save_status_label.setText("余分な空行を整理しました · 未保存 · 元に戻せます")

    def refresh_comment_list(self, select_id: Optional[str] = None):
        self.comment_list.clear()
        selected_row = -1
        for index, comment in enumerate(self.comments):
            quote = str(comment.get("quote", "")).strip().replace("\n", " ")
            body = str(comment.get("text", "")).strip().replace("\n", " ")
            anchor_label = f"“{quote[:34]}”" if quote else "ノート全体"
            display_text = f"{anchor_label}\n{body[:72]}"
            list_item = QListWidgetItem(display_text)
            list_item.setData(Qt.ItemDataRole.UserRole, comment.get("id"))
            list_item.setToolTip(body)
            self.comment_list.addItem(list_item)
            if select_id and comment.get("id") == select_id:
                selected_row = index
        if selected_row >= 0:
            self.comment_list.setCurrentRow(selected_row)
        elif self.comments:
            self.comment_list.setCurrentRow(0)
        else:
            self.comment_preview.clear()

    def selected_comment(self) -> Optional[Dict[str, Any]]:
        list_item = self.comment_list.currentItem()
        if list_item is None:
            return None
        comment_id = list_item.data(Qt.ItemDataRole.UserRole)
        return next(
            (comment for comment in self.comments if comment.get("id") == comment_id),
            None,
        )

    def show_selected_comment(self, *_args):
        comment = self.selected_comment()
        if comment is None:
            self.comment_preview.clear()
            return
        quote = str(comment.get("quote", ""))
        body = str(comment.get("text", ""))
        preview = f"引用：\n{quote}\n\n注釈：\n{body}" if quote else f"注釈：\n{body}"
        self.comment_preview.setPlainText(preview)
        if quote:
            found_cursor = self.content_edit.document().find(quote)
            if not found_cursor.isNull():
                self.content_edit.setTextCursor(found_cursor)
                self.content_edit.ensureCursorVisible()

    def add_comment(self):
        selected_quote = self.content_edit.textCursor().selectedText()
        selected_quote = selected_quote.replace("\u2029", "\n").strip()
        comment_text, accepted = QInputDialog.getMultiLineText(
            self,
            "注釈を追加",
            "注釈内容：",
        )
        comment_text = comment_text.strip()
        if not accepted or not comment_text:
            return
        timestamp = now_iso()
        comment = {
            "id": str(uuid.uuid4()),
            "quote": selected_quote,
            "text": comment_text,
            "created_at": timestamp,
            "updated_at": timestamp,
        }
        self.comments.append(comment)
        self.refresh_comment_list(comment["id"])
        self.mark_dirty()

    def edit_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "注釈を選択", "先に注釈を選択してください。")
            return
        updated_text, accepted = QInputDialog.getMultiLineText(
            self,
            "注釈を編集",
            "注釈内容：",
            str(comment.get("text", "")),
        )
        updated_text = updated_text.strip()
        if not accepted or not updated_text:
            return
        comment["text"] = updated_text
        comment["updated_at"] = now_iso()
        self.refresh_comment_list(str(comment.get("id", "")))
        self.mark_dirty()

    def delete_comment(self):
        comment = self.selected_comment()
        if comment is None:
            QMessageBox.information(self, "注釈を選択", "先に注釈を選択してください。")
            return
        answer = QMessageBox.question(self, "削除の確認", "この注釈を削除しますか？")
        if answer != QMessageBox.StandardButton.Yes:
            return
        comment_id = comment.get("id")
        self.comments = [
            existing for existing in self.comments
            if existing.get("id") != comment_id
        ]
        self.refresh_comment_list()
        self.mark_dirty()

    def build_note_item(self) -> Optional[Dict[str, Any]]:
        note_title = self.title_edit.text().strip()
        if not note_title:
            QMessageBox.warning(self, "タイトルがありません", "タイトルを空にすることはできません。")
            return None
        return {
            "id": self.item.get("id", str(uuid.uuid4())),
            "type": "note",
            "title": note_title,
            "content": self.content_edit.toPlainText(),
            "font_size": self.note_font_slider.value(),
            "comments": copy.deepcopy(self.comments),
            "created_at": self.item.get("created_at", now_iso()),
            "updated_at": now_iso(),
        }

    def save_without_closing(self) -> bool:
        note_item = self.build_note_item()
        if note_item is None:
            return False
        if self.on_save is not None:
            succeeded, _result = run_ui_operation(
                self,
                "保存に失敗しました",
                lambda: self.on_save(copy.deepcopy(note_item)),
            )
            if not succeeded:
                self.save_status_label.setText("保存に失敗しました。内容は編集ウィンドウに保持されています")
                return False
        self.item = copy.deepcopy(note_item)
        self.saved_item = copy.deepcopy(note_item)
        self.is_dirty = False
        self.save_status_label.setText(f"保存済み：{readable_time(note_item.get('updated_at', ''))}")
        return True

    def get_item(self) -> Optional[Dict[str, Any]]:
        self.exec()
        return copy.deepcopy(self.saved_item)

    def clear_sensitive_fields(self):
        self._suppress_dirty = True
        self.title_edit.clear()
        self.content_edit.clear()
        self.note_find_edit.clear()
        self.note_replace_edit.clear()
        self.comment_preview.clear()
        self.comment_list.clear()
        self.comments.clear()
        self.item.clear()
        self._last_note_match = None

    def closeEvent(self, event):
        if self.is_dirty:
            message_box = QMessageBox(self)
            message_box.setWindowTitle("未保存")
            message_box.setText("ノートに未保存の変更があります。")
            save_button = message_box.addButton(
                "保存して閉じる", QMessageBox.ButtonRole.AcceptRole
            )
            discard_button = message_box.addButton(
                "変更を破棄", QMessageBox.ButtonRole.DestructiveRole
            )
            message_box.addButton("キャンセル", QMessageBox.ButtonRole.RejectRole)
            message_box.exec()
            clicked_button = message_box.clickedButton()
            if clicked_button == save_button:
                if not self.save_without_closing():
                    event.ignore()
                    return
            elif clicked_button != discard_button:
                event.ignore()
                return
        self.clear_sensitive_fields()
        event.accept()

class MasterPasswordDialog(ProtectedDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("マスターパスワードを変更")
        self.resize(650, 320)
        self.setMinimumWidth(620)
        self.setStyleSheet("QWidget { font-size: 16px; }")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_edit = QLineEdit()
        self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Password)
        hint = QLabel("マスターパスワードを変更すると新しい salt が生成され、新しい Argon2id 導出鍵でデータベースが再暗号化されます。")
        hint.setObjectName("SubtleLabel")
        hint.setWordWrap(True)
        form_layout = QFormLayout()
        form_layout.addRow("新しいマスターパスワード：", self.password_edit)
        form_layout.addRow("マスターパスワードの確認：", self.confirm_edit)
        generate_password_button = QPushButton("ランダム生成")
        generate_password_button.clicked.connect(self.generate_password)
        save_button = QPushButton("変更")
        cancel_button = QPushButton("キャンセル")
        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout = QHBoxLayout()
        button_layout.addWidget(generate_password_button)
        button_layout.addStretch(1)
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(hint)
        dialog_layout.addLayout(form_layout)
        dialog_layout.addLayout(button_layout)
    def generate_password(self):
        generated_password = PasswordGeneratorDialog(parent=self).generate()
        if generated_password:
            self.password_edit.setText(generated_password)
            self.confirm_edit.setText(generated_password)
            self.password_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.confirm_edit.setEchoMode(QLineEdit.EchoMode.Normal)
    def get_password(self) -> Optional[str]:
        while True:
            if self.exec() != QDialog.DialogCode.Accepted:
                self.password_edit.clear()
                self.confirm_edit.clear()
                return None
            master_password = self.password_edit.text()
            if not master_password:
                QMessageBox.warning(self, "マスターパスワードがありません", "新しいマスターパスワードを入力してください。")
                continue
            if master_password != self.confirm_edit.text():
                QMessageBox.warning(self, "パスワードが一致しません", "入力したマスターパスワードが一致しません。")
                continue
            self.password_edit.clear()
            self.confirm_edit.clear()
            return master_password
#------ メイン画面の部品 ------
class DetailCard(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self.title = QLabel("項目を選択してください")
        self.title.setObjectName("CardTitle")
        self.title.setWordWrap(True)
        self.meta = QLabel("")
        self.meta.setObjectName("SubtleLabel")
        self.meta.setWordWrap(True)
        self.body = QPlainTextEdit("")
        self.body.setObjectName("BodyLabel")
        self.body.setReadOnly(True)
        self.body.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.body.setWordWrapMode(
            QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere
        )
        self.body.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.body.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.addWidget(self.title)
        layout.addWidget(self.meta)
        layout.addSpacing(10)
        layout.addWidget(self.body, 1)
    def show_password_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("パスワード項目を選択してください")
            self.meta.setText("")
            self.body.setPlainText("左側の一覧で検索できます。項目をダブルクリックすると編集できます。")
            return
        masked = "•" * min(max(len(item.get("password", "")), 8), 24)
        self.title.setText(item.get("title", ""))
        self.meta.setText(f"更新日時：{readable_time(item.get('updated_at', ''))}")
        self.body.setPlainText(
            f"ユーザー名：{item.get('username', '')}\n"
            f"パスワード：{masked}\n\n"
            f"備考：\n{item.get('notes', '')}"
        )
    def show_note_item(self, item: Optional[Dict[str, Any]]):
        if not item:
            self.title.setText("セキュアノートを選択してください")
            self.meta.setText("")
            self.body.setPlainText("左側の一覧で検索できます。項目をダブルクリックすると編集画面が開きます。")
            return
        self.title.setText(item.get("title", ""))
        comment_count = len(item.get("comments", []))
        self.meta.setText(
            f"更新日時：{readable_time(item.get('updated_at', ''))} · "
            f"注釈：{comment_count}件"
        )
        self.body.setPlainText(item.get("content", ""))
#------ メインウィンドウ ------
class MainWindow(QMainWindow):
    def __init__(self, vault: Vault):
        super().__init__()
        self.vault = vault
        self.setWindowTitle(f"{APP_NAME} - {vault.path}")
        self.resize(1240, 790)
        self.password_items_all: List[Dict[str, Any]] = []
        self.password_items_view: List[Dict[str, Any]] = []
        self.note_items_all: List[Dict[str, Any]] = []
        self.note_items_view: List[Dict[str, Any]] = []
        self.crypto_wallet_result: Optional[Dict[str, Any]] = None
        self._lock_in_progress = False
        self.managed_clipboard_digest: Optional[bytes] = None
        self.search_edit = QLineEdit()
        self.search_edit.setObjectName("メインツールバーSearchInput")
        self.search_edit.setFixedHeight(32)
        self.search_edit.setPlaceholderText(
            "最長共通部分列検索（大文字・小文字を区別しない）。* はワイルドカードです。例：先頭*末尾"
        )
        self.search_mode = QComboBox()
        self.search_mode.addItems(["LCS／ワイルドカード", "正規表現"])
        self.search_mode.setMinimumWidth(130)
        self.search_mode.setFixedHeight(32)
        self.search_edit.textChanged.connect(self.apply_filter)
        self.search_edit.returnPressed.connect(self.apply_filter)
        self.search_mode.currentIndexChanged.connect(self.search_mode_changed)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.password_table = self.make_table(["タイトル", "ユーザー名", "備考", "更新日時"])
        self.note_table = self.make_table(["タイトル", "注釈", "更新日時"])
        self.password_detail = DetailCard()
        self.note_detail = DetailCard()
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.note_splitter = QSplitter(Qt.Orientation.Horizontal)
        # 長い備考で分割バーの移動範囲が制限されないよう、内容の幅ヒントを無視します。
        for splitter, table, detail in (
            (self.password_splitter, self.password_table, self.password_detail),
            (self.note_splitter, self.note_table, self.note_detail),
        ):
            splitter.setHandleWidth(10)
            splitter.setOpaqueResize(True)
            splitter.setStretchFactor(0, 3)
            splitter.setStretchFactor(1, 2)
            splitter.setCollapsible(0, False)
            splitter.setCollapsible(1, True)
            table.setMinimumWidth(320)
            table.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
            detail.setMinimumWidth(0)
            detail.setSizePolicy(
                QSizePolicy.Policy.Ignored,
                QSizePolicy.Policy.Expanding,
            )
        self.tabs.addTab(self.make_password_tab(), "パスワード管理")
        self.tabs.addTab(self.make_note_tab(), "セキュアノート")
        self.tabs.addTab(self.make_crypto_tab(), "暗号資産")
        self.make_toolbar()
        self.setup_context_menus()
        main = QWidget()
        layout = QVBoxLayout(main)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        top_card = QFrame()
        top_card.setObjectName("TopCard")
        top_layout = QHBoxLayout(top_card)
        top_layout.setContentsMargins(10, 8, 10, 8)
        top_layout.setSpacing(8)
        search_label = QLabel("検索")
        search_label.setObjectName("SearchLabel")
        search_label.setMinimumWidth(86)
        search_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        top_layout.addWidget(search_label)
        top_layout.addWidget(self.search_mode)
        top_layout.addWidget(self.search_edit, 1)
        self.status_label = QLabel("")
        self.status_label.setObjectName("SubtleLabel")
        top_layout.addWidget(self.status_label)
        layout.addWidget(top_card)
        layout.addWidget(self.tabs, 1)
        self.setCentralWidget(main)
        self.password_table.itemClicked.connect(self.show_clicked_password_detail)
        self.note_table.itemClicked.connect(self.show_clicked_note_detail)
        self.password_table.doubleClicked.connect(self.edit_password)
        self.note_table.doubleClicked.connect(self.edit_note)
        self.auto_lock_timer = QTimer(self)
        self.auto_lock_timer.setSingleShot(True)
        self.auto_lock_timer.setInterval(AUTO_LOCK_TIMEOUT_MS)
        self.auto_lock_timer.timeout.connect(self.handle_auto_lock)
        application = QApplication.instance()
        if application is not None:
            application.installEventFilter(self)
        self.auto_lock_timer.start()
        self.refresh_all()

    def eventFilter(self, watched, event):
        activity_events = {
            QEvent.Type.KeyPress,
            QEvent.Type.MouseButtonPress,
            QEvent.Type.MouseButtonDblClick,
            QEvent.Type.Wheel,
            QEvent.Type.TouchBegin,
        }
        if (
            event.type() in activity_events
            and self.isVisible()
            and not self._lock_in_progress
        ):
            self.auto_lock_timer.start()
        return super().eventFilter(watched, event)

    def search_mode_changed(self, *_args):
        if self.search_mode.currentIndex() == 1:
            self.search_edit.setPlaceholderText("正規表現検索、例：アカウント|メール")
        else:
            self.search_edit.setPlaceholderText(
                "最長共通部分列検索（大文字・小文字を区別しない）。* はワイルドカードです。例：先頭*末尾"
            )
        self.apply_filter()

    def handle_auto_lock(self):
        active_modal = QApplication.activeModalWidget()
        if active_modal is not None:
            # 未保存のモーダル編集ウィンドウを強制的にロックせず、1分後に再試行します。
            self.auto_lock_timer.start(60_000)
            return
        self.lock_and_exit(auto_locked=True)

    def enable_windows_screen_capture_protection(self):
        protect_widget_from_capture(self)
    def make_toolbar(self):
        toolbar = QToolBar("メインツールバー")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        save_action = QAction("保存", self)
        save_action.triggered.connect(self.force_save)
        toolbar.addAction(save_action)
        change_master_action = QAction("マスターパスワードを変更", self)
        change_master_action.triggered.connect(self.change_master_password)
        toolbar.addAction(change_master_action)
        lock_action = QAction("ロックして終了", self)
        lock_action.triggered.connect(self.lock_and_exit)
        toolbar.addAction(lock_action)
        toolbar.addSeparator()
        info_action = QAction("情報", self)
        info_action.triggered.connect(self.show_database_info)
        toolbar.addAction(info_action)
        donate_action = QAction("支援", self)
        donate_action.triggered.connect(self.show_donation)
        toolbar.addAction(donate_action)
        security_action = QAction("セキュリティ", self)
        security_action.triggered.connect(self.show_security_notes)
        toolbar.addAction(security_action)
    def make_table(self, headers: List[str]) -> QTableWidget:
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.setAlternatingRowColors(True)
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        return table
    def make_password_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.password_splitter.addWidget(self.password_table)
        self.password_splitter.addWidget(self.password_detail)
        self.password_splitter.setSizes([1240, 0])
        layout.addWidget(self.password_splitter, 1)
        return page
    def make_note_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        self.note_splitter.addWidget(self.note_table)
        self.note_splitter.addWidget(self.note_detail)
        self.note_splitter.setSizes([1240, 0])
        layout.addWidget(self.note_splitter, 1)
        return page
    def make_crypto_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        title_label = QLabel("暗号資産ウォレットの生成と保存")
        title_label.setObjectName("CardTitle")
        description_label = QLabel(
            "BIP39 24単語ニーモニック、BTC BIP84 アドレス5件、および "
            "指定ルールに従った ETH BIP44 アドレス5件を生成します。すべてのアドレスインデックスは強化されています。"
        )
        description_label.setObjectName("SubtleLabel")
        description_label.setWordWrap(True)

        warning_label = QLabel(
            "ニーモニック、seed、秘密鍵はすべて機密情報です。保存をクリックすると、現在の暗号化データベースにパスワード項目として書き込まれます。"
            "強化アドレスインデックスを使用しているため、ウォレット復元時は結果に記録されたパスを正確に使用してください。"
        )
        warning_label.setWordWrap(True)

        self.crypto_generate_button = QPushButton("新しいウォレットを生成")
        self.crypto_generate_button.setObjectName("PrimaryButton")
        self.crypto_save_button = QPushButton("パスワード管理に保存")
        self.crypto_save_button.setObjectName("SecondaryButton")
        self.crypto_save_button.setEnabled(False)
        self.crypto_clear_button = QPushButton("結果を消去")
        self.crypto_generate_button.clicked.connect(self.generate_crypto_wallet)
        self.crypto_save_button.clicked.connect(
            self.save_crypto_wallet_to_password_manager
        )
        self.crypto_clear_button.clicked.connect(self.clear_crypto_wallet_result)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        button_layout.addWidget(self.crypto_generate_button)
        button_layout.addWidget(self.crypto_save_button)
        button_layout.addWidget(self.crypto_clear_button)
        button_layout.addStretch(1)

        self.crypto_status_label = QLabel("ウォレットはまだ生成されていません。")
        self.crypto_status_label.setObjectName("SubtleLabel")
        button_layout.addWidget(self.crypto_status_label)

        self.crypto_output = QPlainTextEdit()
        self.crypto_output.setReadOnly(True)
        self.crypto_output.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.crypto_output.setPlaceholderText("生成結果がここに表示されます。")
        crypto_font = QFont("Consolas")
        crypto_font.setStyleHint(QFont.StyleHint.Monospace)
        self.crypto_output.setFont(crypto_font)

        layout.addWidget(title_label)
        layout.addWidget(description_label)
        layout.addWidget(warning_label)
        layout.addLayout(button_layout)
        layout.addWidget(self.crypto_output, 1)
        return page
    def run_vault_operation(
        self,
        error_title: str,
        operation: Callable[[], Any],
    ) -> bool:
        succeeded, _result = run_ui_operation(self, error_title, operation)
        if succeeded:
            self.refresh_all()
        return succeeded
    def generate_crypto_wallet(self, *_args):
        self.clear_crypto_wallet_result()
        succeeded, wallet_bundle = run_ui_operation(
            self,
            "生成に失敗しました",
            lambda: run_with_progress(
                self,
                "暗号資産ウォレットを生成中",
                "ニーモニック、seed、BTC 鍵、ETH 鍵を生成しています。しばらくお待ちください……",
                lambda: generate_crypto_wallet_bundle(CRYPTO_ADDRESS_COUNT),
            ),
        )
        if not succeeded:
            return

        self.crypto_wallet_result = wallet_bundle
        self.crypto_output.setPlainText(format_crypto_wallet_bundle(wallet_bundle))
        self.crypto_save_button.setEnabled(True)
        self.crypto_status_label.setText(
            f"生成日時：{readable_time(wallet_bundle.get('generated_at', ''))}"
        )

    def save_crypto_wallet_to_password_manager(self, *_args):
        if not self.crypto_wallet_result:
            QMessageBox.information(self, "未生成", "先に暗号資産ウォレットを生成してください。")
            return
        # ニーモニックはパスワード欄に、完全な導出情報と生成日時は備考欄に保存します。
        item = build_crypto_password_item(self.crypto_wallet_result)
        saved = self.run_vault_operation(
            "保存に失敗しました",
            lambda: self.vault.upsert_item(item),
        )
        item.clear()
        if not saved:
            return
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText(
            self.crypto_status_label.text() + " · パスワード管理に保存済み"
        )
        QMessageBox.information(
            self,
            "保存済み",
            "ウォレットをパスワード管理に保存しました。ニーモニックはパスワード欄に、完全な情報と生成日時は備考欄にあります。",
        )

    def clear_crypto_wallet_result(self, *_args):
        self.crypto_output.clear()
        if isinstance(self.crypto_wallet_result, dict):
            for value in self.crypto_wallet_result.values():
                if isinstance(value, list):
                    for entry in value:
                        if isinstance(entry, dict):
                            entry.clear()
                    value.clear()
            self.crypto_wallet_result.clear()
        self.crypto_wallet_result = None
        self.crypto_save_button.setEnabled(False)
        self.crypto_status_label.setText("ウォレットはまだ生成されていません。")
    def setup_context_menus(self):
        self.password_table.customContextMenuRequested.connect(self.show_password_context_menu)
        self.note_table.customContextMenuRequested.connect(self.show_note_context_menu)
    def show_password_context_menu(self, position: QPoint):
        item = self.password_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("パスワードを追加")
            action = menu.exec(self.password_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_password()
            return
        self.password_table.selectRow(item.row())
        add_action = menu.addAction("パスワードを追加")
        edit_action = menu.addAction("編集")
        delete_action = menu.addAction("削除")
        menu.addSeparator()
        copy_user_action = menu.addAction("ユーザー名をコピー")
        copy_pass_action = menu.addAction("パスワードをコピー")
        action = menu.exec(self.password_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_password()
        elif action == edit_action:
            self.edit_password()
        elif action == delete_action:
            self.delete_password()
        elif action == copy_user_action:
            self.copy_username()
        elif action == copy_pass_action:
            self.copy_password()
    def show_note_context_menu(self, position: QPoint):
        item = self.note_table.itemAt(position)
        menu = QMenu(self)
        if item is None:
            add_action = menu.addAction("ノートを追加")
            action = menu.exec(self.note_table.viewport().mapToGlobal(position))
            if action == add_action:
                self.add_note()
            return
        self.note_table.selectRow(item.row())
        add_action = menu.addAction("ノートを追加")
        edit_action = menu.addAction("開く／編集")
        delete_action = menu.addAction("削除")
        action = menu.exec(self.note_table.viewport().mapToGlobal(position))
        if action == add_action:
            self.add_note()
        elif action == edit_action:
            self.edit_note()
        elif action == delete_action:
            self.delete_note()
    def refresh_all(self):
        self.password_items_all = sorted(
            self.vault.all_items("password"),
            key=self.password_sort_key,
        )
        self.note_items_all = sorted(
            self.vault.all_items("note"),
            key=self.note_sort_key,
        )
        self.apply_filter()
    def password_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        username_value = str(item.get("username", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, username_value, updated_value)
    def note_sort_key(self, item: Dict[str, Any]):
        title_value = str(item.get("title", "")).casefold()
        updated_value = str(item.get("updated_at", ""))
        return (title_value, updated_value)
    def apply_filter(self, *_args):
        # 左側の短縮プレビューとは無関係に、各フィールドの全文を検索します。
        keyword = self.search_edit.text().strip()
        regex_mode = self.search_mode.currentIndex() == 1
        self.search_edit.setProperty("searchError", False)
        self.search_edit.style().unpolish(self.search_edit)
        self.search_edit.style().polish(self.search_edit)

        if not keyword:
            self.password_items_view = list(self.password_items_all)
            self.note_items_view = list(self.note_items_all)
        elif regex_mode:
            try:
                compiled_pattern = compile_search_regex(keyword)
            except ValueError as error:
                self.password_items_view = []
                self.note_items_view = []
                self.search_edit.setProperty("searchError", True)
                self.search_edit.style().unpolish(self.search_edit)
                self.search_edit.style().polish(self.search_edit)
                self.status_label.setText(str(error))
                self.refresh_password_table()
                self.refresh_note_table()
                self.hide_details()
                return

            def regex_matches(values: List[Any]) -> bool:
                searchable_text = "\n".join(
                    str(value or "") for value in values
                )[:MAX_SEARCH_TEXT_LENGTH]
                return compiled_pattern.search(searchable_text) is not None

            self.password_items_view = [
                item for item in self.password_items_all
                if regex_matches([
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if regex_matches(
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")]
                )
            ]
        else:
            self.password_items_view = [
                item for item in self.password_items_all
                if lcs_or_wildcard_item_match(keyword, [
                    item.get("title", ""),
                    item.get("username", ""),
                    item.get("notes", ""),
                ])
            ]
            self.note_items_view = [
                item for item in self.note_items_all
                if lcs_or_wildcard_item_match(
                    keyword,
                    [item.get("title", "")]
                    + [
                        f"{comment.get('quote', '')}\n{comment.get('text', '')}"
                        for comment in item.get("comments", [])
                        if isinstance(comment, dict)
                    ]
                    + [item.get("content", "")],
                )
            ]

        self.refresh_password_table()
        self.refresh_note_table()
        self.hide_details()
        mode_label = "正規表現" if regex_mode else "LCS／ワイルドカード"
        self.status_label.setText(
            f"パスワード {len(self.password_items_view)}/{len(self.password_items_all)} · "
            f"ノート {len(self.note_items_view)}/{len(self.note_items_all)} · "
            f"{mode_label}検索 · 5分後に自動ロック"
        )
    def hide_details(self):
        self.password_detail.hide()
        self.note_detail.hide()
        self.password_splitter.setSizes([1240, 0])
        self.note_splitter.setSizes([1240, 0])
    def refresh_password_table(self):
        self.password_table.setRowCount(0)
        for item in self.password_items_view:
            row = self.password_table.rowCount()
            self.password_table.insertRow(row)
            # Qt が長い備考から過大な内容幅を算出しないよう、表の文字数を制限します。
            values = [
                table_text_preview(item.get("title", ""), 80),
                table_text_preview(item.get("username", ""), 80),
                table_text_preview(item.get("notes", "")),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.password_table.setItem(row, column, cell)
    def refresh_note_table(self):
        self.note_table.setRowCount(0)
        for item in self.note_items_view:
            row = self.note_table.rowCount()
            self.note_table.insertRow(row)
            values = [
                item.get("title", ""),
                str(len(item.get("comments", []))),
                readable_time(item.get("updated_at", "")),
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.ItemDataRole.UserRole, item.get("id"))
                self.note_table.setItem(row, column, cell)
    def selected_password(self) -> Optional[Dict[str, Any]]:
        row = self.password_table.currentRow()
        if row < 0 or row >= len(self.password_items_view):
            return None
        return self.password_items_view[row]
    def selected_note(self) -> Optional[Dict[str, Any]]:
        row = self.note_table.currentRow()
        if row < 0 or row >= len(self.note_items_view):
            return None
        return self.note_items_view[row]
    def show_clicked_password_detail(self, *_args):
        item = self.selected_password()
        if item:
            detail_was_hidden = self.password_detail.isHidden()
            self.password_detail.show_password_item(item)
            self.password_detail.show()
            # 初回表示時だけ既定比率を設定し、その後はユーザーの位置を維持します。
            if detail_was_hidden:
                self.reveal_detail_panel(self.password_splitter)
    def show_clicked_note_detail(self, *_args):
        item = self.selected_note()
        if item:
            detail_was_hidden = self.note_detail.isHidden()
            self.note_detail.show_note_item(item)
            self.note_detail.show()
            if detail_was_hidden:
                self.reveal_detail_panel(self.note_splitter)
    @staticmethod
    def reveal_detail_panel(splitter: QSplitter) -> None:
        current_sizes = splitter.sizes()
        total_width = max(sum(current_sizes), splitter.width(), 800)
        detail_width = min(360, max(260, total_width // 3))
        splitter.setSizes([total_width - detail_width, detail_width])
    def require_password_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_password()
        if item is None:
            QMessageBox.information(self, "項目を選択", "先にパスワード項目を選択してください。")
        return item
    def require_note_selection(self) -> Optional[Dict[str, Any]]:
        item = self.selected_note()
        if item is None:
            QMessageBox.information(self, "項目を選択", "先にノートを選択してください。")
        return item
    def add_password(self):
        item = PasswordDialog(parent=self).get_item()
        if item:
            self.run_vault_operation(
                "保存に失敗しました",
                lambda: self.vault.upsert_item(item),
            )
    def edit_password(self, *_args):
        item = self.require_password_selection()
        if not item:
            return
        updated = PasswordDialog(item=item, parent=self).get_item()
        if updated:
            self.run_vault_operation(
                "保存に失敗しました",
                lambda: self.vault.upsert_item(updated),
            )
    def delete_password(self):
        item = self.require_password_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "削除の確認", f"削除しますか：「{item.get('title', '')}」？")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "削除に失敗しました",
                lambda: self.vault.delete_item(item["id"]),
            )
    def copy_username(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("username", ""), "ユーザー名をコピーしました。")
    def copy_password(self):
        item = self.require_password_selection()
        if item:
            self.copy_to_clipboard(item.get("password", ""), "パスワードをコピーしました。30秒後にクリップボードを自動消去します。", auto_clear=True)
    def copy_to_clipboard(self, text: str, message: str, auto_clear: bool = False):
        QApplication.clipboard().setText(text)
        expected_digest = hashlib.sha256(text.encode("utf-8")).digest()
        self.managed_clipboard_digest = expected_digest
        QMessageBox.information(self, "コピー済み", message)
        if auto_clear:
            # タイマーのクロージャには平文パスワードではなく、ダイジェストだけを保持します。
            def clear_clipboard(digest=expected_digest):
                current_text = QApplication.clipboard().text()
                current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
                if secrets.compare_digest(current_digest, digest):
                    QApplication.clipboard().clear()
                    if self.managed_clipboard_digest == digest:
                        self.managed_clipboard_digest = None
                current_text = ""
            QTimer.singleShot(30_000, clear_clipboard)

    def clear_managed_clipboard(self):
        digest = self.managed_clipboard_digest
        if digest is None:
            return
        current_text = QApplication.clipboard().text()
        current_digest = hashlib.sha256(current_text.encode("utf-8")).digest()
        if secrets.compare_digest(current_digest, digest):
            QApplication.clipboard().clear()
        current_text = ""
        self.managed_clipboard_digest = None

    def save_note_from_dialog(self, item: Dict[str, Any]):
        self.vault.upsert_item(item)
        self.refresh_all()

    def add_note(self):
        NoteDialog(
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()

    def edit_note(self, *_args):
        item = self.require_note_selection()
        if not item:
            return
        NoteDialog(
            item=item,
            parent=self,
            on_save=self.save_note_from_dialog,
        ).exec()
    def delete_note(self):
        item = self.require_note_selection()
        if not item:
            return
        answer = QMessageBox.question(self, "削除の確認", f"削除しますか：「{item.get('title', '')}」？")
        if answer == QMessageBox.StandardButton.Yes:
            self.run_vault_operation(
                "削除に失敗しました",
                lambda: self.vault.delete_item(item["id"]),
            )
    def force_save(self):
        if self.run_vault_operation("保存に失敗しました", self.vault.save):
            QMessageBox.information(self, "保存済み", "データベースを保存しました。")
    def change_master_password(self):
        new_password = MasterPasswordDialog(parent=self).get_password()
        if new_password:
            succeeded, _result = run_ui_operation(
                self,
                "変更に失敗しました",
                lambda: run_with_progress(
                    self,
                    "マスターパスワードを変更中",
                    "新しい鍵を導出してデータベースを暗号化しています。しばらくお待ちください……",
                    lambda: self.vault.change_master_password(new_password),
                ),
            )
            new_password = ""
            if succeeded:
                QMessageBox.information(self, "変更済み", "マスターパスワードを変更し、データベースを新しい鍵で再暗号化して保存しました。")
    def clear_sensitive_ui(self):
        self.clear_crypto_wallet_result()
        self.password_items_all.clear()
        self.password_items_view.clear()
        self.note_items_all.clear()
        self.note_items_view.clear()
        self.password_table.clearContents()
        self.password_table.setRowCount(0)
        self.note_table.clearContents()
        self.note_table.setRowCount(0)
        self.password_detail.show_password_item(None)
        self.note_detail.show_note_item(None)
        self.password_detail.hide()
        self.note_detail.hide()
        self.search_edit.clear()
        self.clear_managed_clipboard()
    def closeEvent(self, event):
        try:
            self.auto_lock_timer.stop()
            application = QApplication.instance()
            if application is not None:
                application.removeEventFilter(self)
            self.clear_sensitive_ui()
            self.vault.lock()
        finally:
            super().closeEvent(event)
    def lock_and_exit(self, auto_locked: bool = False):
        if self._lock_in_progress:
            return
        self._lock_in_progress = True
        self.auto_lock_timer.stop()
        try:
            self.clear_sensitive_ui()
            self.vault.lock()
            self.hide()
            reopened_vault = bootstrap_vault(parent=None)
            if reopened_vault is None:
                self.close()
                return
            self.vault = reopened_vault
            self.setWindowTitle(f"{APP_NAME} - {self.vault.path}")
            self.refresh_all()
            if auto_locked:
                self.status_label.setText(
                    self.status_label.text() + " · 自動ロックの再認証が完了"
                )
            self.show()
            self.enable_windows_screen_capture_protection()
            self.auto_lock_timer.start()
        finally:
            self._lock_in_progress = False
    def show_database_info(self):
        message = (
            f"アプリ：{APP_NAME} {APP_VERSION}\n"
            f"ファイル：{self.vault.path}\n"
            f"アルゴリズム：Argon2id + ChaCha20-Poly1305\n"
            f"Argon2id：iterations={self.vault.kdf_params.get('iterations')}，lanes={self.vault.kdf_params.get('lanes')}，memory={self.vault.kdf_params.get('memory_cost')} KiB\n"
            f"自動ロック：5分間操作がない場合\n"
            f"パスワード項目：{len(self.password_items_all)}\n"
            f"セキュアノート：{len(self.note_items_all)}"
        )
        QMessageBox.information(self, "データベース情報", message)
    def show_donation(self):
        message = (
            f"このプロジェクトが役に立った場合は、作者を支援できます。\n\n"
            f"Bitcoin：{DONATION_BTC}\n"
            f"Ethereum：{DONATION_ETH}\n"
            f"BNB Smart Chain：{DONATION_BNB}"
        )
        QMessageBox.information(self, "作者を支援", message)
    def show_security_notes(self):
        message = (
            "CipherNote Vault は Argon2id でマスターパスワードから 256-bit 鍵を導出し、ChaCha20-Poly1305 でデータベース全体を認証暗号化します。\n\n"
            "パスワード項目とセキュアノートは同じ暗号化 payload に格納されます。ディスク上のデータベースファイルに保存されるのは salt、nonce、KDF パラメーター、暗号文だけです。\n\n"
            "保存には独立した一時ファイル、ファイル同期、アトミック置換を使用します。別のインスタンスによる変更を検出した場合は、上書きを防ぐため保存を中止します。\n\n"
            "5分間操作がないと自動的にロックします。未処理のモーダル編集ウィンドウがある場合は、ロックを延期して再試行します。\n\n"
            "Windows では、通常のスクリーンショットや画面録画による取得を防ぐため、メインウィンドウと機密ダイアログで SetWindowDisplayAffinity の有効化を試みます。\n\n"
            "インポートした外部テキストは、保存が正常に完了した後にのみ暗号化データベースへ格納されます。\n\n"
            "セキュリティ境界：本アプリは、既に端末を制御しているマルウェア、画面の写真撮影、管理者権限でのスクリーンショット、キーロガー、クリップボード監視、メモリダンプを防御できません。システムのディスク暗号化との併用を推奨します。"
        )
        QMessageBox.information(self, "セキュリティ情報", message)
#------ アプリのスタイルと起動 ------
def set_app_style(application: QApplication):
    application.setStyleSheet("""
        QWidget {
            font-family: "Yu Gothic UI", Meiryo, "Noto Sans CJK JP", sans-serif;
            font-size: 16px;
            color: #FFF700;
            background-color: #8A1F00;
        }
        QメインツールバーWindow, QDialog {
            background-color: #8A1F00;
        }
        QLineEdit, QPlainTextEdit, QTableWidget {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 10px;
            padding: 9px;
            selection-background-color: #FFD700;
            selection-color: #FF0000;
        }
        QLineEdit#メインツールバーSearchInput {
            padding: 2px 8px;
            border-radius: 6px;
        }
        QLineEdit[searchError="true"] { border: 2px solid #FF0000; }
        QPlainTextEdit { line-height: 1.5em; }
        QTableWidget {
            gridline-color: #9A3400;
            alternate-background-color: #7C1D00;
            border-radius: 12px;
        }
        QTableWidget::item { padding: 8px; }
        QTableWidget::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QSplitter::handle:horizontal {
            background-color: #C86F00;
            margin: 3px 2px;
            border-radius: 3px;
        }
        QSplitter::handle:horizontal:hover,
        QSplitter::handle:horizontal:pressed {
            background-color: #FFD700;
        }
        QHeaderView::section {
            background-color: #5F1700;
            color: #FDE600;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #C86F00;
            font-weight: 700;
        }
        QRadioButton#ModeRadio:checked {
            background-color: rgb(0, 200, 0);
        }
        QPushButton {
            background-color: #E9C400;
            color: #4A1200;
            border: 1px solid #F6D900;
            border-radius: 10px;
            padding: 9px 14px;
            font-weight: 800;
        }
        QPushButton:hover { background-color: #F3D500; }
        QPushButton:pressed { background-color: #D9A400; }
        QPushButton:disabled {
            background-color: #9CA300;
            color: #5F1700;
        }
        QPushButton#PrimaryButton {
            background-color: #F1C900;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton {
            background-color: #D89C00;
            padding: 18px;
            font-size: 16px;
        }
        QPushButton#SecondaryButton:hover { background-color: #E8B900; }
        QTabWidget::pane {
            border: 1px solid #C86F00;
            border-radius: 12px;
            top: -1px;
            background-color: #8A1F00;
        }
        QTabBar::tab {
            background-color: #6F1A00;
            color: #FDE600;
            padding: 7px 14px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-right: 1px;
            font-weight: 700;
        }
        QTabBar::tab:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QToolBar {
            background-color: #5A1500;
            border: none;
            spacing: 6px;
            padding: 6px;
        }
        QToolButton {
            color: #FDE600;
            background-color: #6F1A00;
            border-radius: 8px;
            padding: 7px 9px;
        }
        QToolButton:hover { background-color: #9A3400; }
        QMenu {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #E9C400;
            padding: 6px;
        }
        QMenu::item {
            padding: 8px 28px;
            border-radius: 6px;
        }
        QMenu::item:selected {
            background-color: #E9C400;
            color: #4A1200;
        }
        QSlider::groove:horizontal {
            height: 6px;
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 3px;
        }
        QSlider::handle:horizontal {
            width: 16px;
            margin: -6px 0;
            border-radius: 8px;
            background-color: #E9C400;
            border: 1px solid #F6D900;
        }
        QSlider::sub-page:horizontal {
            background-color: #E9C400;
            border-radius: 3px;
        }
        QSpinBox, QCheckBox {
            color: #FFF700;
            background-color: #6F1A00;
        }
        QLabel#DialogTitle {
            font-size: 30px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#CardTitle {
            font-size: 22px;
            font-weight: 900;
            color: #FFF700;
        }
        QLabel#SectionTitle {
            font-size: 18px;
            font-weight: 800;
            color: #FFF700;
        }
        QLabel#SubtleLabel { color: #FDE600; }
        QPlainTextEdit#BodyLabel {
            color: #FFF700;
            background-color: #6F1A00;
            border: none;
            border-radius: 10px;
            padding: 12px;
        }
        QLabel#SearchLabel {
            font-weight: 800;
            color: #FDE600;
        }
        QFrame#Card {
            background-color: #6F1A00;
            border: 1px solid #C86F00;
            border-radius: 16px;
            padding: 12px;
        }
        QFrame#TopCard {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 14px;
            padding: 8px;
        }
        QFrame#InlineSearch {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 10px;
        }
        QFrame#CommentsPanel {
            background-color: #5F1700;
            border: 1px solid #C86F00;
            border-radius: 12px;
        }
        QListWidget#CommentList {
            background-color: #6F1A00;
            color: #FFF700;
            border: 1px solid #C86F00;
            border-radius: 8px;
            padding: 4px;
        }
        QListWidget#CommentList::item {
            padding: 8px;
            border-bottom: 1px solid #9A3400;
        }
        QListWidget#CommentList::item:selected {
            background-color: #FFD700;
            color: #FF0000;
        }
        QMessageBox QLabel { color: #FFF700; }
    """)
def bootstrap_vault(parent=None) -> Optional[Vault]:
    for _ in range(3):
        dialog = StartupDialog(parent=parent)
        result = dialog.get_result()
        if result is None:
            return None
        vault = Vault(result["path"])
        master_password = result.pop("password")
        try:
            if result["mode"] == "create":
                operation = lambda: run_with_progress(
                    parent,
                    "データベースを作成中",
                    "暗号鍵を導出してデータベースを作成しています。しばらくお待ちください……",
                    lambda: vault.create(master_password),
                )
            else:
                operation = lambda: run_with_progress(
                    parent,
                    "データベースを開いています",
                    "マスターパスワードを確認してデータベースを復号しています。しばらくお待ちください……",
                    lambda: vault.unlock(master_password),
                )
            succeeded, _result = run_ui_operation(
                parent,
                "データベースを開けませんでした",
                operation,
            )
        finally:
            master_password = ""
            result.clear()
        if succeeded:
            return vault
    return None
def main():
    application = QApplication(sys.argv)
    application.setApplicationName(APP_NAME)
    set_app_style(application)
    vault = bootstrap_vault()
    if vault is None:
        return 1
    window = MainWindow(vault)
    window.show()
    window.enable_windows_screen_capture_protection()
    return application.exec()
if __name__ == "__main__":
    raise SystemExit(main())
